package bean;

public class BasketDTO {
	private String id; //제품의 id
	private String logId; //주문한 사람의 id
	private int price;	// 제품 가격
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLogId() {
		return logId;
	}
	public void setLogId(String logId) {
		this.logId = logId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	@Override
	public String toString() {
		return "BasketDTO [id=" + id + ", logId=" + logId + ", price=" + price + "]";
	}
	
	
	
}

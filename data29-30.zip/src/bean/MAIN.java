package bean;

public class MAIN {

	public static void main(String[] args) {
		MemberDAO dao = new MemberDAO();
		MemberDTO dto = new MemberDTO();
		dto.setId("apple");
		dto.setPw("apple");
		System.out.println(dao.idCheck(dto));
		
		
		
		
	}

}

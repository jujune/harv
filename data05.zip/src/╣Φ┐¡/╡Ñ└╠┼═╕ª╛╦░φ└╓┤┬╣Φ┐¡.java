package �迭;

public class �����͸��˰��ִ¹迭 {

	public static void main(String[] args) {
		String[] names = {"ȫ�浿", "��浿", "�۱浿", "�ڱ浿", "���浿"};
		for (int i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
		
		//�ƴ� ������� ���� (int): for, foreach
		int[] age = {27, 28, 29, 30, 31};
		for (int i = 0; i < age.length; i++) {
			System.out.println(age[i]);
		}
		for (int c : age) {
			System.out.println(c);
		}
		//����(char)
		char[] gender = {'m', 'm', 'w', 'm', 'w'};
			for (int i = 0; i < gender.length; i++) {
				System.out.println(gender[i]);
			}
			for (char c : gender) {
				System.out.println(c);
			}
			
		//�÷�(double)
		double[] sight = {2.0, 1.0, 1.5, 1.2, 0.8};
		
	}

}

package �迭;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;

public class �׷����׽�Ʈ_�������� {
	static int java;
	static int jsp;
	static int spring;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] subject = new String[3];

		JFrame f = new JFrame();
		f.setSize(500, 100);
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);

		// �ڵ� �ڵ� ����
		// ��Ʈ�� + ����Ʈ + o(�ڵ�import)
		for (int i = 0; i < 3; i++) {
			System.out.print("��û�� ������ �Է��ϼ���.>> ");
			subject[i] = sc.next();
			JButton b = new JButton(subject[i]);
			f.add(b);
			String b1 = b.getText();
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (b1.equals("�ڹ�")) {
						java++;
					} else if (b1.equals("jsp")) {
						jsp++;
					} else {
						spring++;
					}
				f.setTitle("java: " + java + ", jsp: " + jsp + ", spring: " + spring);
				}// action
			});// addaction
		} // for
		f.setVisible(true);
	}// main
}// class

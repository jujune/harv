package �迭;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;

public class �׷����׽�Ʈ_��������2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] subject = new String[3];
		
		
	
		
		JFrame f = new JFrame();
		f.setSize(353,544);
		
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		
		JButton btnNewButton = new JButton("\uBE68\uAC15\uC2E0\uD638");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel l = new JLabel("");
				ImageIcon icon = new ImageIcon("red.jpg");
				f.add(l);
				l.setIcon(icon);
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 18));
		btnNewButton.setBounds(0, 0, 337, 64);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uB178\uB791\uC2E0\uD638");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel l = new JLabel("");
				ImageIcon icon = new ImageIcon("yellow.jpg");
				f.add(l);
				l.setIcon(icon);
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(Color.ORANGE);
		btnNewButton_1.setFont(new Font("���� ����", Font.BOLD, 18));
		btnNewButton_1.setBounds(0, 64, 337, 64);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uD30C\uB791\uC2E0\uD638");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel l = new JLabel("");
				ImageIcon icon = new ImageIcon("green.jpg");
				f.add(l);
				l.setIcon(icon);
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setBackground(Color.BLUE);
		btnNewButton_2.setFont(new Font("���� ����", Font.BOLD, 18));
		btnNewButton_2.setBounds(0, 128, 337, 64);
		f.getContentPane().add(btnNewButton_2);
		
		
		
		
	
		
		
		f.setVisible(true);
	}// main
}// class

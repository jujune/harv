package �迭;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class ��ư�迭 {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500, 500);
		//add�� ������� ���ʴ�� ��ġ
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		JButton[] list = new JButton[500];
		for (int i = 0; i < list.length; i++) {
			list[i] = new JButton("��ư" + i);
		}
		System.out.println(list[0]); //�ּ�

//		for (int i = 0; i < 500; i++) {
//			JButton b1 = new JButton("��ư" + i);
//			f.add(b1);
//		}
		
		
//		JButton b1 = new JButton("��ư1");
//		JButton b2 = new JButton("��ư2");
//		f.add(b1);
//		f.add(b2);
		
		f.setVisible(true);
	}

}

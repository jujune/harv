

yesterday = ['홍길동', '박길동', '김길동']
today = ['홍길동', '정길동', '이길동']

y = set(yesterday)
t = set(today)

#1
print(yesterday)
print(today)

#2
print(y.intersection(t))
print(t.intersection(y))

#3
print(y.union(t))

#4
print(len(y.union(t)))

#-----------------------------

a = input("문장을 입력>> ")
b = a.split(" ")

count = 0
for x in b:
    count = count + len(x)
print("전체 글자 수 : " + str(count))
print("전체 단어 수 : " + str(len(b)))
for x in b:
    print(str(x) + " " + str(len(x)) + "글자")

#-------------------------------
print("인기투표 시스템")
print("---------------")
print("1)아이유 2)BTS 3)유재석")
print("---------------")

data = {'아이유':0, 'BTS':0, '유재석':0}

while True:
    c = input("입력")
    if c == '1':
        data['아이유'] += 1
    elif c == '2':
        data['BTS'] += 1
    elif c == '3':
        data['유재석'] += 1
    else:
        print("입력을 종료합니다")
        break

print(data)
for x in data:
    print(x + " : " + str(data[x]) + "표")



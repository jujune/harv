from 연습.MemberDAO import *

# insert = Insert("1","asd","asd","ads")
# print(insert)

list1 = []

a = input("id를 입력하세요")
b = input("pw를 입력하세요")
c = input("name를 입력하세요")
d = input("tel를 입력하세요")
# e = input("1)insert 2)delete")

list1.append(a)
list1.append(b)
list1.append(c)
list1.append(d)

print(list1)

dao = MemberDAO()
dao.insert(list1)
result = dao.select(list1)
print(result)
dao.delete(list1)
dao.update(list1)





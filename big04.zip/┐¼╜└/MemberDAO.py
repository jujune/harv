import pymysql

class MemberDAO: # 멤버함수일 때 self를 쓴다

    def insert(self, person):
        conn = pymysql.connect(host='localhost', port=3708, user='root', password="1234", db='big', charset='utf8')
        curs = conn.cursor() # rs.next와 같은 기능

        sql = "insert into member values (%s, %s, %s, %s)"
        curs.execute(sql, person)
        conn.commit()  # db에 변경된 내용을 저장. 확정!

        conn.close()
        print("insert 완료")


    def select(self, person):
        conn = pymysql.connect(host='localhost',     port=3708, user='root', password="1234", db='big', charset='utf8')
        curs = conn.cursor()  # rs.next와 같은 기능

        sql4 = "select * from member where id=%s"
        curs.execute(sql4, person[0])
        result = curs.fetchall()
        # result = curs.fetchone() # 1개 결과 선택

        conn.close()
        return result
        print("select 완료")


    def delete(self, person):
        conn = pymysql.connect(host='localhost', port=3708, user='root', password="1234", db='big', charset='utf8')
        curs = conn.cursor()  # rs.next와 같은 기능

        sql3 = "delete from member where id=%s"
        curs.execute(sql3, person[0])
        conn.commit()

        conn.close()
        print("delete 완료")

    def update(self, person):
        conn = pymysql.connect(host='localhost', port=3708, user='root', password="1234", db='big', charset='utf8')
        curs = conn.cursor()  # rs.next와 같은 기능

        sql2 = "update member set pw=%s where id=%s"
        curs.execute(sql2, (person[1], person[0]))
        conn.commit()

        conn.close()
        print("update 완료")


class Insert: #잘못 만들었지만 파라메터 생성자로 돌아감

    a = ""
    b = ""
    c = ""
    d = ""

    def __init__(self, a,b,c,d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        data = (self.a, self.b, self.c, self.d)

        sql = "insert into member values (%s, %s, %s, %s)"
        curs.execute(sql, data)
        conn.commit()
        conn.close()
        print("db연동 완료")



    def __str__(self):
        return self.a + self.b + self.c + self.d



from tkinter import *

def file_write():
    # 파일로 저장하는 처리
    date_data = date_input.get()
    title_data = title_input.get()
    content_data = content_input.get()

    file1 = open(date_data +'.txt', 'w')
    file1.write(date_data + '\n')
    file1.write(title_data + '\n')
    file1.write(content_data + '\n')

    date_input.delete(0, END)
    title_input.delete(0, END)
    content_input.delete(0, END)

    date_input.insert(0, '날짜입력')

def file_read():
    # date_input에 입력한 값을 가진 파일을
    # 한줄씩 읽어서, Entry에 텍스트로 집어 넣는다.
    # date_input.insert(0, '한줄읽어온 내용')
    date_data = date_input.get()
    file = open(date_data + ".txt", 'r')

    date_input.delete(0, END)
    title_input.delete(0, END)
    content_input.delete(0, END)

    date_line = file.readline().strip('\n')
    title_line = file.readline().strip('\n')
    content_line = file.readline().strip('\n')
    # 파일에서 읽어온 문자열에서 \n 삭제하여 출력

    date_input.insert(0, date_line)
    title_input.insert(0, title_line)
    content_input.insert(0, content_line)


w = Tk()
w.geometry("500x800")

icon = PhotoImage(file="001.png")
label1 = Label(w, image=icon)

date_label = Label(w, text="날짜:", font=('궁서',30))
title_label = Label(w, text="제목:", font=('궁서',30))
content_label = Label(w, text="내용:", font=('궁서',30))

date_input = Entry(w, font=('궁서',30), bg="yellow")
title_input = Entry(w, font=('궁서',30), bg="yellow")
content_input = Entry(w, font=('궁서',30), bg="yellow")

write_button = Button(w, text='파일로 저장', command=file_write, font=('궁서',30), bg='lime')
read_button = Button(w, text='파일 읽기', command=file_read, font=('궁서',30), bg='lime')



label1.pack()
date_label.pack()
date_input.pack()
title_label.pack()
title_input.pack()
content_label.pack()
content_input.pack()
write_button.pack()
read_button.pack()


w.mainloop()
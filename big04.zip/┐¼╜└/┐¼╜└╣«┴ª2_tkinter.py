from tkinter import *

fruit=["apple",'banana','melon']

def file_write():
    file1 = open('fruit.txt', 'w')
    for x in fruit:
        file1.write(x + " ")

def file_read():
    file2 = open('fruit.txt', 'r')
    row = file2.readline()
    print(row)

w = Tk()
w.geometry('500x700')
w.config(bg="yellow")


icon = PhotoImage(file="fruit.png")
label1 = Label(w, image=icon)
button1 = Button(w, text="과일 리스트를 파일에 저장", command=file_write)
button2 = Button(w, text="과일 리스트를 읽어오기", command=file_read)

label1.pack()
button1.pack()
button2.pack()

w.mainloop()
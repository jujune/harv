import pymysql

conn = pymysql.connect(host='localhost', port=3708, user='root', password="1234", db='big', charset='utf8')
curs = conn.cursor() # rs.next와 같은 기능

# insert

sql = "insert into member values (%s, %s, %s, %s)"
curs.execute(sql, ('ljy', 'qwer', 'lee', '010'))
conn.commit() # db에 변경된 내용을 저장. 확정!

# insert 복수

data = (('asd2', 'titlee', 'contentt', 'contentt'), ('lkm2', 'titlee', 'contentt', 'contentt'), ('iu2', 'titlee', 'contentt', 'contentt'))
sql1 = """insert into member
      values (%s, %s, %s, %s)"""
curs.executemany(sql1, data)
conn.commit()

# update

sql2 = "update member set pw=%s where id=%s"
curs.execute(sql2, ('qwer1','ljy'))
conn.commit()

# delete

sql3 = "delete from member where id=%s"
curs.execute(sql3, 'ljy')
conn.commit()

# select

sql4 = "select * from member where id='q'"
curs.execute(sql4)
# result = curs.fetchall()
result1 = curs.fetchone()
# print(result)
print(result1)

conn.close()

print('실행 완료')


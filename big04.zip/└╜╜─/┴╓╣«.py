class 커피:
    brand = ''
    madein = ''

    def __init__(self, brd, mdi):
        self.brand = brd
        self.madein = mdi

    def roast(self):
        print("커피를 볶다")

    def americano(self):
        print("얼죽아")

    def __str__(self):
        return "브랜드는 " + self.brand + " 원산지는 " + self.madein


class 케익:
    flavor = ""
    size = ""

    def __init__(self, fla, sz):
        self.flavor = fla
        self.size = sz

    def celeb(self):
        print("축하하다")

    def cream(self):
        print("크림을 묻히다")

    def __str__(self):
        return "맛은 " + self.flavor + " 사이즈는 " + self.size



if __name__ == '__main__':
    coffee = 커피("스타벅스", "과테말라")
    coffee.roast()
    coffee.americano()
    print(coffee)

    cake = 케익("초코", "패밀리")
    cake.celeb()
    cake.cream()
    print(cake)

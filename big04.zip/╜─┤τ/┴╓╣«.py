from 음식.주문 import *

coffee = 커피("스벅", "콜롬비아")
coffee.americano()
coffee.roast()
print(coffee)

cake = 케익("초코", "패밀리")
cake.cream()
cake.celeb()
print(cake)
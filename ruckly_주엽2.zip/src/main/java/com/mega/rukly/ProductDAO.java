package com.mega.rukly;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductDAO {
	
	@Autowired
	SqlSessionTemplate my;

	public List<ProductDTO> all(){
		List<ProductDTO> all = my.selectList("product.all");
		return all;
	}
	
	public ProductDTO one(ProductDTO dto) {
		ProductDTO dto2 = my.selectOne("product.one", dto);
		return dto2;
	}
}





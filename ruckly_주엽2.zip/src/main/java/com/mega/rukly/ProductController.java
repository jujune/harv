package com.mega.rukly;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProductController {

	@Autowired
	ProductDAO dao;
	
	
	//내가 추가한 부분
	@RequestMapping("best.do")
	public void select(Model model) {
		List<ProductDTO> list = dao.all();
		model.addAttribute("list", list);
	}
	
	
	
	
	
	@RequestMapping("all.do")
	public void all(Model model) {
		List<ProductDTO> all = dao.all();
		model.addAttribute("all", all);
	}
	
	@RequestMapping("one.do")
	public void one(ProductDTO productDTO, Model model) {
	ProductDTO dto = dao.one(productDTO);
	model.addAttribute("dto", dto);
	}
}

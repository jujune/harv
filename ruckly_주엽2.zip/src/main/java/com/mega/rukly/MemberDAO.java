package com.mega.rukly;



import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MemberDAO {

	@Autowired
	SqlSessionTemplate my;
	
	public int login(MemberDTO dto) {
		System.out.println("입력된 dto는" + dto);
		Object dto2 = my.selectOne("member.select", dto);
		System.out.println("select해온 dto2는 " + dto2);
		int result = 0;
		
		if (dto2 != null) {
			result = 1;
		} 
		return result;
	}
	
	public void insert(MemberDTO dto) {
		my.insert("member.insert", dto);
	}
}

package com.mega.rukly;

public class ProductDTO { //VO(Value Object)
	
	private String product_img1;
	private String product_img2;
	private String product_img3;
	private int product_no;
	private int price;
	private int discount;
	private String title;
	private String content;
	
	public String getProduct_img1() {
		return product_img1;
	}
	public void setProduct_img1(String product_img1) {
		this.product_img1 = product_img1;
	}
	public String getProduct_img2() {
		return product_img2;
	}
	public void setProduct_img2(String product_img2) {
		this.product_img2 = product_img2;
	}
	public String getProduct_img3() {
		return product_img3;
	}
	public void setProduct_img3(String product_img3) {
		this.product_img3 = product_img3;
	}
	public int getProduct_no() {
		return product_no;
	}
	public void setProduct_no(int product_no) {
		this.product_no = product_no;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	@Override
	public String toString() {
		return "ProductDTO [product_img1=" + product_img1 + ", product_img2=" + product_img2 + ", product_img3="
				+ product_img3 + ", product_no=" + product_no + ", price=" + price + ", discount=" + discount
				+ ", title=" + title + ", content=" + content + "]";
	}	
}

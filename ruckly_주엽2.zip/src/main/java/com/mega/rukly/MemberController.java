package com.mega.rukly;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {

	@Autowired
	MemberDAO dao;

	@RequestMapping("login.do")
	public String login(MemberDTO memberDTO, Model model, HttpSession session) {
		int result = dao.login(memberDTO);
		String page = "";

		if (result == 1) {
			page = "login";
			session.setAttribute("id", memberDTO.getId());
			model.addAttribute("id", memberDTO.getId());
			System.out.println(session.getAttribute("id"));
		} else {
			page = "fail";
		}
		return page;
	}

	@RequestMapping("signup.do")
	public void signup(MemberDTO memberDTO) {
		dao.insert(memberDTO);
	}
}

package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class PinDAO {
	Connection con;
	DBConnectionMgr mgr;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public PinDAO() {
		 mgr = DBConnectionMgr.getInstance();
		
	}
	
	//회원가입
	public boolean addMember(MemberDTO dto) {

		try {
			con = mgr.getConnection();
			
			String sql = "insert into member(id, pw, nickName) values(?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getNickName());
			pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			mgr.freeConnection(con);
		}
		return true;
}
	
	//로그인
	public boolean login(String id, String pw) {
	
		boolean result = false;
		System.out.println("login불림");
		System.out.println("아이디: " + id);
		System.out.println("비번: " + pw);
		try {
			con = mgr.getConnection();
			
			String sql = "select id, pw from member where id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);		
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				if(rs.getString("pw").equals(pw))
				result=true;
			}
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		finally {
			mgr.freeConnection(con);
		}
		return result;			
	}			
	
//	public MemberDTO select(MemberDTO dto) {
//	
//		MemberDTO dto2 = null;
//		
//		try {
//			con = mgr.getConnection();
//			String sql = "select * from member where id = ?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, dto.getId());
//			rs = pstmt.executeQuery();
//			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
//				System.out.println("검색 결과가 있어요.!!");
//				dto2 = new MemberDTO();
//				String id = rs.getString(1);
//				String pw = rs.getString(2);
//				String name = rs.getString(3);
//				String tel = rs.getString(4);
//				dto2.setId(id);
//				dto2.setPw(pw);
//				dto2.setName(name);
//				dto2.setTel(tel);
//
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		finally {
//			mgr.freeConnection(con);
//		}
//		return dto2;
//}	
	
//	public int loginCheck(MemberDTO dto) {
//		int result = 0;
//		
//		try {
//			con = mgr.getConnection();
//			String sql = "select * from member where email = ? and pw = ?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setString(1, dto.getEmail());
//			pstmt.setString(2, dto.getPw());
//			rs = pstmt.executeQuery();
//			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
//				result =  1;
//
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		finally {
//			mgr.freeConnection(con);
//		}
//		return result;
//}	
//	
//	public bbsDTO selectbbs(bbsDTO dto) {
//		
//		bbsDTO dto2 = null;
//
//		try {
//			con = mgr.getConnection();
//			
//			String sql = "select * from bbs where no = ?";
//			pstmt = con.prepareStatement(sql);
//			pstmt.setInt(1, dto.getNo());
//			rs = pstmt.executeQuery();
//			if (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
//				System.out.println("검색 결과가 있어요.!!");
//				dto2 = new bbsDTO();
//				int no = rs.getInt(1);
//				String title = rs.getString(2);
//				String content = rs.getString(3);
//				String writer = rs.getString(4);
//				dto2.setNo(no);
//				dto2.setTitle(title);
//				dto2.setContent(content);
//				dto2.setWriter(writer);
//
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		finally {
//			mgr.freeConnection(con);
//		}
//		return dto2;
//}	
	
	//관심사 불러오기
	public ArrayList<interestDTO> inSelect(String id){
		interestDTO dto2 = null;
		ArrayList<interestDTO> list = new ArrayList<>();
		try {
		
			con = mgr.getConnection();
			String sql = "select id, cNo from interest where id = ? "; 
	
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				dto2 = new interestDTO();
				System.out.println("검색 결과가 있어요.!!");
				String inId = rs.getString(1);
				int cNo = rs.getInt(2);
				System.out.println(inId);
				System.out.println(cNo);
				
				dto2.setId(inId);
				dto2.setcNo(cNo);
				list.add(dto2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			mgr.freeConnection(con);
		}
		return list;
		
	}
	
	//타이틀 불러오기
	public ArrayList<String> titleSelect(ArrayList<imageDTO> dto){
		ArrayList<String> list = new ArrayList<>();
		System.out.println("dto 사이즈: " + dto.size());
		try {
			con = mgr.getConnection();
			for (int i = 0; i < dto.size(); i++) {
							
			String sql = "select title from category where cNo = ? "; 
	
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, dto.get(i).getcNo());
			
			rs = pstmt.executeQuery();
			while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				String title = rs.getString(1);				
				list.add(title);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			mgr.freeConnection(con);
		}
		return list;
		
	}
	

	
	//메인 이미지	
	public ArrayList<imageDTO> mainList(ArrayList<interestDTO> dto) {
		imageDTO dto2 = null;
		ArrayList<imageDTO> list = new ArrayList<>();
	
	
		try {
		
			con = mgr.getConnection();
			for(int i=0; i < 5; i ++) {
	
				String sql = "select imgUrl from image where cNo = ? ORDER BY RAND() LIMIT 6"; 
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, dto.get(i).getcNo());
				System.out.println("여기까지 실행됨 " + dto.get(i).getcNo());
				rs = pstmt.executeQuery();
				while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
					System.out.println("검색 결과가 있어요.!!");
	
					String url = rs.getString(1);
					dto2 = new imageDTO();
					dto2.setcNo(dto.get(i).getcNo());
					dto2.setImgUrl(url);
					System.out.println("번호: " + dto2.getcNo());
					list.add(dto2);
					}
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			mgr.freeConnection(con);
		}
		return list;
}	

	
	//타이틀 불러오기
		public ArrayList<categoryDTO> searchSelect(String search){
			categoryDTO dto2 = null;
			ArrayList<categoryDTO> list = new ArrayList<>();
		
			try {
				con = mgr.getConnection();
											
				String sql = "select cNo from category where title = ? "; 
		
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, search);
				
				rs = pstmt.executeQuery();
				while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
					System.out.println("검색 결과가 있어요.!!");
					dto2 = new categoryDTO();
					int no = rs.getInt(1);		
					dto2.setcNo(no);				
					}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				mgr.freeConnection(con);
			}
			return list;
			
		}	
//		//검색후 화면에 출력
//		public ArrayList<imageDTO> search(String select) {
//			imageDTO dto2 = null;
//			ArrayList<imageDTO> list = new ArrayList<>();
//		
//		
//			try {
//			
//				con = mgr.getConnection();
//				for(int i=0; i < 5; i ++) {
//		
//					String sql = "select imgUrl from image where cNo = ? LIEK '' ORDER BY RAND() LIMIT 6"; 
//					pstmt = con.prepareStatement(sql);
//					pstmt.setInt(1, dto.get(i).getcNo());
//					System.out.println("여기까지 실행됨 " + dto.get(i).getcNo());
//					rs = pstmt.executeQuery();
//					while (rs.next()) { // 검색 결과가 있는지 체크해주는 메서드
//						System.out.println("검색 결과가 있어요.!!");
//		
//						String url = rs.getString(1);
//						dto2 = new imageDTO();
//						dto2.setcNo(dto.get(i).getcNo());
//						dto2.setImgUrl(url);
//						System.out.println("번호: " + dto2.getcNo());
//						list.add(dto2);
//						}
//					}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			finally {
//				mgr.freeConnection(con);
//			}
//			return list;
//	}	
//	

//	public int update(bbsDTO dto) {
//		int result = 0;
//		try {
//			con = mgr.getConnection();
//			// 3) sql�� ����
//			String sql = "update bbs set title =?," 
//					+ "content = ?"
//					+ "where no = ?";
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, dto.getTitle());
//			ps.setString(2, dto.getContent());
//			ps.setInt(3, dto.getNo());			
//			System.out.println("3. SQL�� ���� OK");
//			// 4) sql�� ����
//			result = ps.executeUpdate();
//			System.out.println("4. SQL�� ���� OK");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}finally {
//			mgr.freeConnection(con);			
//		}
//		return result;
//	}
	
//	public int delete(MemberDTO dto) {
//		
//		int result = 0;
//		try {
//			con = mgr.getConnection();
//
//		
//			String sql = "delete from member where id = ?";
//			PreparedStatement ps = con.prepareStatement(sql);
//			ps.setString(1, dto.getId());
//
//			
//			result = ps.executeUpdate();
//			System.out.println("���� ��û ����� " + result);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		finally {
//			mgr.freeConnection(con);
//		}
//		return result;
//	}

}

package ��ǰ�����;

public class MyRoom2 {

	public static void main(String[] args) {
		Phone fPhone = new Phone();
		fPhone.product = "iphoneX";
		fPhone.camera = 2;
		fPhone.button = 3;
		
		Phone mPhone = new Phone();
		mPhone.product = "galaxy";
		mPhone.camera = 3;
		mPhone.button = 3;
		
		fPhone.ring();
		fPhone.message();
		fPhone.shot();
		
		mPhone.ring();
		mPhone.message();
		mPhone.shot();
		
		
	}

}

package db����;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ȸ������ {

	public static void main(String[] args) {
		JFrame f = new JFrame()	;
		f.setSize(500, 500);
		
		JButton btnNewButton = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//ȸ������ ó��
				dbó�� db = new dbó��();
				db.insert();
			}
		});
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 73));
		f.getContentPane().add(btnNewButton, BorderLayout.NORTH);
		
		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uD0C8\uD1F4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbó�� db = new dbó��();
				db.delete();
			}
		});
		btnNewButton_1.setFont(new Font("���� ����", Font.PLAIN, 73));
		f.getContentPane().add(btnNewButton_1, BorderLayout.SOUTH);
		
		JButton btnNewButton_2 = new JButton("DB\uC5F0\uACB0");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbó�� db = new dbó��();
				db.connect();
			}
		});
		btnNewButton_2.setFont(new Font("���� ����", Font.PLAIN, 48));
		f.getContentPane().add(btnNewButton_2, BorderLayout.CENTER);
		
		JButton btnNewButton_3 = new JButton("\uD68C\uC6D0\uC218\uC815");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbó�� db = new dbó��();
				db.update();
			}
		});
		btnNewButton_3.setFont(new Font("���� ����", Font.PLAIN, 48));
		f.getContentPane().add(btnNewButton_3, BorderLayout.EAST);
		
		
		
		
		
		
		f.setVisible(true);
	}

}

package db����;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ����â {
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void signIn() { // ȸ������ â �߰� �ϱ�
		JFrame f = new JFrame();
		f.getContentPane().setBackground(new Color(0, 255, 0));
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);
		
		JLabel t1 = new JLabel("\uC544\uC774\uB514");
		t1.setFont(new Font("���� ����", Font.PLAIN, 24));
		t1.setBounds(56, 37, 97, 62);
		f.getContentPane().add(t1);
		
		JLabel t2 = new JLabel("\uD328\uC2A4\uC6CC\uB4DC");
		t2.setFont(new Font("���� ����", Font.PLAIN, 24));
		t2.setBounds(56, 109, 97, 62);
		f.getContentPane().add(t2);
		
		textField = new JTextField();
		textField.setForeground(new Color(0, 0, 0));
		textField.setBounds(207, 49, 205, 51);
		f.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setForeground(new Color(0, 0, 0));
		textField_1.setColumns(10);
		textField_1.setBounds(207, 121, 205, 51);
		f.getContentPane().add(textField_1);
		
		JLabel t3 = new JLabel("\uC774\uB984");
		t3.setFont(new Font("���� ����", Font.PLAIN, 24));
		t3.setBounds(56, 181, 97, 62);
		f.getContentPane().add(t3);
		
		textField_2 = new JTextField();
		textField_2.setForeground(new Color(0, 0, 0));
		textField_2.setColumns(10);
		textField_2.setBounds(207, 264, 205, 51);
		f.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setForeground(new Color(0, 0, 0));
		textField_3.setColumns(10);
		textField_3.setBounds(207, 192, 205, 51);
		f.getContentPane().add(textField_3);
		
		JLabel t4 = new JLabel("\uC804\uD654\uBC88\uD638");
		t4.setFont(new Font("���� ����", Font.PLAIN, 24));
		t4.setBounds(56, 253, 97, 62);
		f.getContentPane().add(t4);
		
		JButton btnNewButton = new JButton("\uD68C\uC6D0\uAC00\uC785\uCC98\uB9AC");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				String pw = t2.getText();
				String name = t3.getText();
				String tel = t4.getText();
				
				dbó�� db = new dbó��();
				db.insert(id, pw, name, tel);
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 0));
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 54));
		btnNewButton.setBounds(52, 338, 360, 75);
		f.getContentPane().add(btnNewButton);
		
		
		f.setVisible(true);
		
		
	}
}

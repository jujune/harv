from django.db import models

# Create your models here.

class MemBer(models.Model):
    id = models.CharField(max_length=100, primary_key=True)
    pw = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    blog = models.URLField('site URL!!!!!')

    def __str__(self):
        return 'id : ' + self.id + ', pw : ' + self.pw + ', name : ' \
               + self.name + ', blog : ' + self.blog
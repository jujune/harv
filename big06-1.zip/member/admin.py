from django.contrib import admin

# Register your models here.
from member.models import MemBer

admin.site.register(MemBer)

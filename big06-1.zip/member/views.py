from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
from django.views.generic import ListView

from member.models import MemBer


class MemberListView(ListView):
    model = MemBer

def index(request):
    return HttpResponse('Welcome Django!!!')

def index2(request):
    site = ('<a href=/admin>관리자 모드로</a><br>' 
             '<a href=/member>멤버로!</a>')
    return  HttpResponse(site)



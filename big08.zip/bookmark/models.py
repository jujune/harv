from django.db import models

# Create your models here.
# ORM (언어의 변수와 RDB테이블 항목들과의 mapping)
# DTO/VO는 만들지 않음. 장고가 알아서해요.
from django.urls import reverse


class BookMark(models.Model): # model 상속을 통해 간단히 맵핑시킴!
    #파이썬의 변수, DB테이블의 컬럼
    site_name = models.CharField(max_length=100)
    url = models.URLField('site url 등 뭘 써도됨')

    def __str__(self):
        return "사이트명 : " + self.site_name + \
                ' / 인터넷 주소 : ' + self.url

    def get_absolute_url(self):
        return reverse('detail', args=[str(self.id)])

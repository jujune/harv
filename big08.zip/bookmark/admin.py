from django.contrib import admin
from bookmark.models import BookMark

# Register your models here.
# 관리자모드로 관리하고 싶은 테이블을 resgister

admin.site.register(BookMark)
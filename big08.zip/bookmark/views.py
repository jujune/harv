from django.http import HttpResponse

# controller역할
# Create your views here.
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from bookmark.models import BookMark

#selectlist, selectall? 의 기능을(arraylist같은) 상속받음. CRUD각각의 역할을 수행하는 view가 따로 있음.

class BookDetail(DetailView):
    model = BookMark
    # detail과 list만 디폴트인 템플릿 이름이 정해져 있어서 따로 suffix 안정해줘도 됨
class BookDelete(DeleteView):
    model = BookMark
    success_url = reverse_lazy('list')
    # delete의 suffixd인 _confirm_delete를 쓰고 싶지 않으면 따로 지정해주기
    # template_name = 'bookmark/delete.html'

class BookUpdate(UpdateView):
    model = BookMark
    fields = ['site_name', 'url']
    template_name_suffix = '_update'
    # detail과 list를 제외한 다른 view들은 최상위 클래스?의 suffix인 _form을 받아오므로 따로 suffix를 정해줘야함.
    # 그렇지 않으면 create도 update도 다 _form의 suffix를 찾아가게됨.
    success_url = reverse_lazy('list')

class BookCreate(CreateView):
    model = BookMark
    fields = ['site_name', 'url']
    # 입력하는 template 필요, 지정
    template_name_suffix = '_create'

    # 성공했으면 어느 페이지로 연결할지 설정
    # 호출했던 페이지의 위치에 상관없이 list라고 명명된 페이지를 호출해준다.
    success_url = reverse_lazy('list') # list로 '렌더링'함


def index(request, id, name):
    return HttpResponse('received id: ' + id + '<br>' + \
                        'received name:' + name)


class BookList(ListView):
    model = BookMark
    # template_name = ''
    # ListView에는 model이라는 멤버변수가 있음. 이 위에 나의 것으로 만듦 멤버변수 override함.
    # templates 파일명 : 모델명(소문자)_list.html
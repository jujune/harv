"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from bookmark import views
from bookmark.views import BookList, BookCreate, BookDelete, BookUpdate, BookDetail
from member.views import MemberList, MemberCreate

urlpatterns = [
    path('admin/', admin.site.urls),
    path('booklist/', BookList.as_view(), name='list'), # /booklist를 부르고 싶으면 list를 사용해주면 된다?
                                                        # 코드에서 url불러올때 list란 이름으로 대신 사용
    path('member/', MemberList.as_view(), name='list1'),
    #path('<id>/<name>/', views.index), # <id>와 <name>은 각각 주소에 직접 입력한 값
    path('bookcreate/', BookCreate.as_view(), name='create'),
    path('membercreate/', MemberCreate.as_view(), name="create1"),
    path('bookdelete/<int:pk>', BookDelete.as_view(), name="delete"),
    path('bookupdate/<int:pk>', BookUpdate.as_view(), name="update"),
    path('bookdetail/<int:pk>', BookDetail.as_view(), name="detail")
]

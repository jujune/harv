from django.db import models

# Create your models here.

class Member(models.Model):
    id = models.CharField(max_length=100, primary_key=True)
    pw = models.CharField(max_length=100)
    name = models.CharField(max_length=100)

    def __str__(self):
        return "이름 : " + self.id + " / 비밀번호 : " + self.pw + " / 이름 : " + self.name

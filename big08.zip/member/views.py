from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView

from member.models import Member

class MemberList(ListView):
    model = Member


class MemberCreate(CreateView):
    model = Member
    fields = ['id', 'pw', 'name']
    template_name_suffix = "_create"
    success_url = reverse_lazy("list1")
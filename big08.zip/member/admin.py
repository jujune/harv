from django.contrib import admin

# Register your models here.
from member.models import Member

admin.site.register(Member)
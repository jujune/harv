package com.mega.mvc04;

public class BananaCar implements Car {

	@Override
	public void run() {
		System.out.println("달려라 바나나!");
	}

	@Override
	public void speedUp() {
		System.out.println("속도를 올려라 바나나!");
	}


}

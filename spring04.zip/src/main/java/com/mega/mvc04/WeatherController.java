package com.mega.mvc04;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WeatherController {
	
	@Autowired
	WeatherDAO dao;
	
	@RequestMapping("weather.do")
	public String weather(String date, Model model) {
		System.out.println("맵핑됨");
		WeatherDTO dto = dao.weather(date);
		model.addAttribute("dto", dto);
		
		String weather = "weather2";
		
		return weather;
	}

}

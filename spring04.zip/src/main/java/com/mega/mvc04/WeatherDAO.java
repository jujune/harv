package com.mega.mvc04;

import java.util.ArrayList;

public class WeatherDAO {
	
	public WeatherDTO weather(String date) {
		WeatherDTO dto = new WeatherDTO();
		System.out.println("dto생성됨");
		
		if (date.equals("1")) {
			dto.setDate(date);
			dto.setWeather("비/천둥번개");;
			dto.setMicrodust("나쁨");
			dto.setRainfall("100mm");
			dto.setTemperature("18'c");
			
		} else if (date.equals("2")) {
			dto.setDate(date);
			dto.setWeather("맑음");
			dto.setMicrodust("좋음");
			dto.setRainfall("0mm");
			dto.setTemperature("12'c");
		}
		return dto;
	}
}

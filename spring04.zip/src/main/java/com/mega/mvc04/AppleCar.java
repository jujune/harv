package com.mega.mvc04;

public class AppleCar implements Car {

	public void run() {
		System.out.println("빨리 달리다");
	}

	public void speedUp() {
		System.out.println("한 번에 속도를 100km/h로 올리다!");
	}

}

package com.mega.mvc04;

public class CarUse {

	public static void main(String[] args) {
		System.out.println("코드 변경함");
		
		AppleCar apple = new AppleCar();
		apple.run();
		apple.speedUp();
		
		BananaCar banana = new BananaCar();
		banana.run();
		banana.speedUp();
		
	}

}

package com.mega.mvc04;

//인터페이스로는 객체생성 불가 (new불가)
//인터페이스 내의 메소드는 불완전함 (추상적, abstract). abstract method라고 부름
//인터페이스 내의 메소드는 추상메소드만 써야함
public interface Car { //자동차가 되기 위한 규격이 들어감
	//인터페이스에는 일반 변수가 없음
	
	public abstract void run(); //달리는 기능이 있어야함 (기능에 대해 정의만 함)
	void speedUp(); //스피드up 기능이 있어야함 //public, abstract 안써줘도 됨. default가 public
	
	
	
	
}

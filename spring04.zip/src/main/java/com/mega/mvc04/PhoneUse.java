package com.mega.mvc04;

public class PhoneUse {

	public static void main(String[] args) {

		ApplePhone apple = new ApplePhone();
		apple.ring();
		apple.vibrate();
	}

}

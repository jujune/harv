package com.mega.mvc04;

public class ApplePhone implements Phone {

	@Override
	public void ring() {
		System.out.println("띠리링");
	}

	@Override
	public void vibrate() {
		System.out.println("지이잉");

	}

}

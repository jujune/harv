package com.mega.mvc04;

public class ProductDAO {

	public void insert(ProductDTO dto) {
		System.out.println("dao에서 받은 dto내용\n" + dto); // \n 엔터 넣기
	}
}

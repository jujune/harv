package com.mega.mvc04;

public interface Phone {
	
	public abstract void ring();
	void vibrate();
	
}

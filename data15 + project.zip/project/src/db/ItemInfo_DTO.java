package db;

public class ItemInfo_DTO {
	String nick_name;
	String date;
	String content;
	String album_id;

	
	
	

	

}

package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ProjectDAO {
	String url = "jdbc:mysql://localhost:3708/project?characterEncoding=utf8&serverTimezone=UTC";
	String user = "root";
	String password = "1234";
	
	//1. cart에 있는 곡 불러오기
	public ArrayList<Cart_DTO> all() { //전체 검색하기, DTO에 담아내는 과정, 리스트가 반환됨
		ArrayList<Cart_DTO> list = new ArrayList<>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select song_id, song_title, artist, album_cover from cart";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery(); 
			
			while (rs.next()) {
				Cart_DTO dto = new Cart_DTO();
				
				int song_id = rs.getInt(1);
				String song_title = rs.getString(2);
				String artist = rs.getString(3);
				String album_cover = rs.getString(4);
				
				dto.setSong_id(song_id);
				dto.setSong_title(song_title);
				dto.setArtist(artist);
				dto.setAlbum_cover(album_cover);
				
				list.add(dto);  //DTO에 데이터에 각 행을 담음
			}
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//2. 결제정보 DB에 저장 (pay)
	public void insert_pay (Pay_DTO dto) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "insert into pay values (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setInt(2, dto.getPay_id());
			ps.setString(3, dto.getDate());
			ps.setInt(4, dto.getTrack_count());
			ps.setInt(5, dto.getTotal_price());
			ps.setString(6, dto.getPay_way());
			ps.setString(7, dto.getPay_company());
					
			ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	
	//3. cart에 있는 DB my_song으로 옮기기
	public void insert_my_song (Cart_DTO dto) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "insert into pay values (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			ps.setInt(2, dto.getPay_id()); 
			ps.setString(3, dto.getDate());
			ps.setInt(4, dto.getCount());
			ps.setInt(5, dto.getTotal_price());
			ps.setString(6, dto.getPay_way());
			ps.setString(7, dto.getPay_company());
					
			ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	

}

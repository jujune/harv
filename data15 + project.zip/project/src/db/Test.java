package db;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Test {

	public static void main(String[] args) {
		ProjectDAO dao = new ProjectDAO();
		dao.all(); //
		
		Date today = new Date();
		SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(s.format(today));
	}
	

}

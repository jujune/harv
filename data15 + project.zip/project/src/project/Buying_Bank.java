package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import db.Cart_DTO;
import db.Pay_DTO;
import db.ProjectDAO;

public class Buying_Bank {
	private static JPasswordField passwordField;
	static int bankpay_count = 0;
	
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(1000,800);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("구매 곡 정보");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(12, 32, 406, 57);
		f.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(34, 88, 387, 555);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("커버");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 10, 43, 42);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("커버");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(12, 63, 43, 42);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2.setBounds(67, 10, 210, 42);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2_1.setBounds(67, 63, 210, 42);
		panel.add(lblNewLabel_2_1);
		
		JLabel l3 = new JLabel("총 10곡 X 800원 = 합계 8,000원");
		l3.setOpaque(true); //Opaque값을 true로 미리 설정해 주어야 배경색이 적용된다.
		l3.setBackground(Color.WHITE);
		l3.setHorizontalAlignment(SwingConstants.CENTER);
		l3.setBounds(34, 668, 384, 57);
		f.getContentPane().add(l3);
		
		
		JLabel lblNewLabel_4 = new JLabel("결제방식");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(465, 32, 142, 86);
		f.getContentPane().add(lblNewLabel_4);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(478, 159, 462, 379);
		panel_1.setLayout(null);

		f.getContentPane().add(panel_1);
		
		JButton btnNewButton = new JButton("카드");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(630, 32, 142, 86);
		f.getContentPane().add(btnNewButton);
		
		
		
		
		JButton btnNewButton_1 = new JButton("무통장 입금");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(798, 32, 142, 86);
		f.getContentPane().add(btnNewButton_1);
		
		/////////////////////////////
		
		panel_1.removeAll(); 
		
		JLabel lblNewLabel_7 = new JLabel("은행 선택");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(12, 10, 102, 29);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_7_2 = new JLabel("입금자 성명");
		lblNewLabel_7_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_2.setBounds(12, 49, 102, 29);
		panel_1.add(lblNewLabel_7_2);
		
		
		JTextField input_name = new JTextField();
		input_name.setColumns(10);
		input_name.setBounds(137, 53, 65, 21);
		panel_1.add(input_name);
		
		
		String bank[] = {"은행선택", "기업은행", "외환은행", "국민은행", "농협중앙회", "우리은행", "SC제일은행", "씨티은행", "대구은행", "우체국", "KEB하나은행"};
		JComboBox bank_choice = new JComboBox(bank);
		bank_choice.setBounds(137, 14, 142, 23);
		panel_1.add(bank_choice);
		
		
		JButton btnNewButton_3 = new JButton("개인용 가상계좌 생성");
		btnNewButton_3.setBounds(12, 281, 438, 88);
		panel_1.add(btnNewButton_3);
		
		JTextArea ta1 = new JTextArea();
		ta1.setForeground(Color.BLACK);
		ta1.setFont(new Font("맑은 고딕", Font.BOLD, 15));
		ta1.setBounds(39, 123, 394, 105);
		panel_1.add(ta1);
		
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				if ((bank_choice.getSelectedItem().equals("은행선택")) || (input_name.getText().equals(""))) {
				//비교연산자는 기본형에 대해서만 쓸 수 있음. 주소값은 .equals 사용해야.
					JOptionPane.showMessageDialog(null, "결제 정보를 입력해주세요");
				} else {
//					double randomValue = Math.random(); //왜죠-.-
//					int r1 = (int)(randomValue * 999999) + 100000; //(int)(Math.random() * 최대값) + 최소값
//					int r2 = (int)(randomValue * 99) + 10; 
//					int r3 = (int)(randomValue * 999998) + 100000;
//					System.out.println(r1);
//					System.out.println(r2);
//					System.out.println(r3);
					
					Random r = new Random();
					int r1 = r.nextInt(999999);
					int r2 = r.nextInt(999);
					int r3 = r.nextInt(99999);
					
					ta1.setText(
							"성명  :  " + input_name.getText() + "\n" +		
									"은행  :  " + bank_choice.getSelectedItem() + "\n" +
									"계좌번호 : " + r1 + " - " + r2 + " - " + r3 + "\n" +
									"금액  :  " + "ㅇㅇ원" + "\n" + "\n" +
									"입금자 성명과 금액을 확인해주세요." // Jtextarea로 바꿔야함. Panel은 1줄만 가능
							);	
					bankpay_count++;
					}
			}
		});
		panel_1.revalidate();
		panel_1.repaint();
		
		JLabel l6 = new JLabel("결제 결과");
		l6.setOpaque(true);
		l6.setBackground(Color.WHITE);
		l6.setHorizontalAlignment(SwingConstants.CENTER);
		l6.setBounds(478, 668, 462, 57);
		f.getContentPane().add(l6);
		
		
		JButton btnNewButton_2 = new JButton("결제 시도");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (bankpay_count == 0) {
					JOptionPane.showMessageDialog(null, "개인 가상계좌를 먼저 생성해주세요.");
				} else {
					//1. 결제정보 DB에 저장하기
					Pay_DTO dto = new Pay_DTO(); //가방을 만들고 
					dto.setId("ㅋㅋㅋ"); //***********static id 입력받기 나중에  //가방에 넣음
					dto.setPay_id(0); //auto increment는, db에서 primary key지정하고 변수값 0 넣어두면 알아서 적용됨
					SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date today = new Date();
					String date = s.format(today);
					dto.setDate(String.valueOf(date));
					dto.setTrack_count(123456789); //1개 추가될 때마다 카운트 올라가게
					dto.setTotal_price(123456789); //올라간 카운트 x price
					dto.setPay_way("무통장입금");
					dto.setPay_company(String.valueOf(bank_choice.getSelectedItem()));
					ProjectDAO dao = new ProjectDAO();
					dao.insert_pay(dto);
					
					//2. 구매한 곡들 my_song으로 옮기기
//					ArrayList<Cart_DTO> list = dao.all();
//					for (int i = 0; i < list.size(); i++) { //반환받은 사이즈?
//						Cart_DTO dto2 = new Cart_DTO();
//						dto2 = list.get(i);
//						
//						dao.insert
		
						
					
					
					
					l6.setText("결제가 완료되었습니다.");
					ta1.setText("");
					input_name.setText("");
					bank_choice.setSelectedItem("은행선택");
					}
				}
//			}
		});
		btnNewButton_2.setBounds(478, 575, 462, 68);
		f.getContentPane().add(btnNewButton_2);
		
		
		
		
		f.setVisible(true);
		
	}
}

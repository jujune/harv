package project;

import java.awt.GridBagLayout;

import javax.swing.JFrame;

public class 그리드백_GridBuying extends JFrame { //JFrame의 함수를 다 쓸 수 있게 함. 상속
	GridBagLayout gbl; //그리드백 레이아웃을 사용하기 위한 변수 선언
	
}

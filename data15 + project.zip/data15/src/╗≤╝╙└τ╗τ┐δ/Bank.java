package 상속재사용;

public class Bank {
	public double getInterestRate() {
		return 0; 
	}

double interest;

}

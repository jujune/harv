package 상속재사용;

public class SuperManUser {

	public static void main(String[] args) {
		SuperMan s = new SuperMan();
		s.cloth = "빨강"; //superman
		s.power = 100; //man
		s.name = "클라크"; //person
		s.age = 300; //person
		
		System.out.println(s); //참조형은 원래 주소가 찍혀야하지만 toString을 부품에 설정해놔서 자동으로 toString 메소드가 호출됨.

		s.fly(); //superman
		s.wild(); //man
		s.talk(); //person
		s.think(); //person
		
	}

}

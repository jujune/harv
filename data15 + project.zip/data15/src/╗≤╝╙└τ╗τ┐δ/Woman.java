package 상속재사용;

public class Woman extends Person {
	int eq;
	
	public void soft() {
		System.out.println("부드럽다.");
	}
}

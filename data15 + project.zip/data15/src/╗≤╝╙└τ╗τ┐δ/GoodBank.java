package 상속재사용;

public class GoodBank extends Bank {
	
	@Override //표시(Annotation), 생략가능
	public double getInterestRate() {
		return 3	;
	}
	
	double interest;
	
	@Override
	public String toString() {
		return "GoodBank [interest=" + interest + "]";
	}


}

package 상속재사용;

public class Student {
	public void study() {
		System.out.println("ㅇㅇ");
	}
	
	
}

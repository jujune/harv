package 상속재사용;

public class Test {

}

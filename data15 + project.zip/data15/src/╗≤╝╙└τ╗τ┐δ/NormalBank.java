package 상속재사용;

public class NormalBank extends Bank {
	
	@Override //표시(Annotation), 생략가능
	public double getInterestRate() {
		return 5	;
	} 
		
	double interest;
	
	@Override
	public String toString() {
		return "NormalBank [interest=" + interest + "]";
	}


}

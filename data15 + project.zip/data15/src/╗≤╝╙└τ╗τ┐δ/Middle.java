package 상속재사용;

public class Middle extends Student {
	public void study() {
		System.out.println("단소 공부하다.");
	}
}

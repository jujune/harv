package 상속재사용;

//모든 클래스는 Object을 상속받음!
public class PersonUser { //클래스가 가지는 기본적인 성질을 object가 가지고 옴.

	public static void main(String[] args) {
		Person p = new Person();
		p.name = "은정";
		p.age = 20;
		
		System.out.println(p);
		
		p.talk();
		p.think();
	}

}

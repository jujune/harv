package 상속재사용;

public class WonderWomanUser {

	public static void main(String[] args) {
		WonderWoman w = new WonderWoman();
		
		w.age = 20;
		w.eq = 20;
		w.name = "원더";
		w.weapon = "rope";

		System.out.println(w);
		
		w.rope();

	}

}

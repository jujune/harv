package 상속재사용;

public class SuperMan extends Man { //public final class라고 쓰면 종단 클래스가 됨. (더 이상 상속이 불가능)
	//성질(3), 동작(3)
	
	String cloth;
	
	public void fly() {
		System.out.println("하늘을 날다.");
	}

	@Override
	public String toString() {
		return "SuperMan [cloth=" + cloth + ", power=" + power + ", name=" + name + ", age=" + age + "]";
	}

	
	
}

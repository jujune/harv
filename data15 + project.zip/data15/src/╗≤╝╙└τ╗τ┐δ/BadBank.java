package 상속재사용;

public class BadBank extends Bank {
	//ljy910604@naver.com //at ~에
	
	@Override //표시(Annotation), 생략가능
	public double getInterestRate() {
		return 10	;
	}
	
	double interest;

	@Override
	public String toString() {
		return "BadBank [interest=" + interest + "]";
	}


	
}

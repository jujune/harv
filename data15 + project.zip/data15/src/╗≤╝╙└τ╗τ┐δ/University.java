package 상속재사용;

public class University extends Student {
	public void study() {
		System.out.println("토익 공부하다.");
	}
}

package 상속재사용;

public class BankUser {

	public static void main(String[] args) {
		BadBank b = new BadBank();
		NormalBank n = new NormalBank();
		GoodBank g = new GoodBank();
		
		System.out.println("BadBank rates: " + b.getInterestRate());
		System.out.println("NomalBank rates: " + n.getInterestRate());
		System.out.println("GoodBank rates: " + g.getInterestRate());
		
		b.interest = 10.0;
		n.interest = 5.0;
		g.interest = 3.0;
		
		System.out.println(b);
		System.out.println(n);
		System.out.println(g);
	}

}

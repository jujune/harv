package 상속재사용;

public class WonderWoman extends Woman {
	String weapon;
	
	public void rope() {
		System.out.println("밧줄을 사용하다.");
	}

	@Override
	public String toString() {
		return "WonderWoman [weapon=" + weapon + ", eq=" + eq + ", name=" + name + ", age=" + age + "]";
	}
	
	
	
	
}

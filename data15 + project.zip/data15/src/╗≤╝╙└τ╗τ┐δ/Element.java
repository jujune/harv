package 상속재사용;

public class Element extends Student {
	public void study() {
		System.out.println("줄넘기 공부하다.");
	}
}

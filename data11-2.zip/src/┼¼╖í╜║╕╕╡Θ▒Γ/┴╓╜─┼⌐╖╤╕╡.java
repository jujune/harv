package 클래스만들기;

import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JTextField;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class 주식크롤링 { //ctrl + shift + p 닫는 괄호 찾기
	Elements list = null; //전역변수, 전체 표 크롤링 결과
	
	//전체 표 크롤링
	public String[] enter() {
		String[] company = new String[5];
		try {
			Connection con = Jsoup.connect("https://finance.naver.com/sise/lastsearch2.nhn"); //페이지 불러오기
			Document doc = con.get(); 
			list = doc.select("tr td"); // 순위 정보, 주식 정보를 포함한 모든 정보 크롤링
			
//			Elements list = doc.select("tr td"); 			

			int start = 32; //32번줄 부터 삼성전자 1위 시작
			int j = 0; // 배열의 index값 지정

			for (int i = 32; i < start + 60; i = i + 12) {
				company[j] = list.get(i).text(); // company배열에 회사명 top5 회사명을 추출
				j++;
			}
//			for (String s : company) {
//				System.out.println(s);
//			}

		} catch (Exception e) {
		}
		return company; //top5 회사 배열을 return
	}

	
	public String[] info(int index) { //회사 인덱스 값을 입력해줘야 실행되는 되는 부품
		String[] result = new String[5]; //결과 담아 보내줄 배열.
		int j = 0; //result배열의 index값 설정
		
		for (int i = index + 1; i < index + 6; i++) { //입력된 인덱스값 +1 부터 +5까지 정보들 호출
			result[j] = list.get(i).text(); // 배열에 입력
			j++;
		}		
		return result;
	}
	
	public void file() {
		try {
			String[] contents = new String[35]; //
			
			FileWriter file = new FileWriter("stock.txt"); //왜 4개 밖에 정보가 안들어가지..?
			
			int k = 0;
			for (int j = 0; j < 5; j++) {
				for (int i = 0; i < 6; i++) {
					contents[k] = list.get(12*j + 32 + i).text();				
					k++;
			}
				}
			
			for (int i = 0; i < 30; i++) {
				file.write(contents[i] + "\n");
			}

			file.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	
	}
}

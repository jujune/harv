package 클래스로전달;

public class Bag3 {
	public String code;
	public String name;
	public String content;
	public int price;
	public String company;
	
//	Bag3 bag3 = new Bag3(); //6개의 변수가 생성됨.
//	bag3에는 주소
//	code, name, content, company에는 null, price에는 0
	
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	
	
	
}

package 클래스로전달;

public class Bag {
	//여러개의 데이터를 한 번에 묶어서 전송하려고!
	//Data Transfer Object (DTO) 혹은 Value Object (VO)
	public String id;
	public String pw;
	public String name;
	public int age;
	
	//Source -> Generate Getters and Setters
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}


	
	
	
//	public void setId(String id)	{
//		//id = id; //지역변수와 전역변수가 같으면 가까운 아이를 가져다 쓴다. 이 코드는 나는 나다 라고 하는 것.
//		this.id = id; //this는 이 클래스를 말한다. 충돌이 날 것 같을 때 this를 서줌
//	}
	

	
}

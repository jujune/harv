package 클래스로전달;

public class Bag2 {
	public int no;
	public String title;
	public String
	
}

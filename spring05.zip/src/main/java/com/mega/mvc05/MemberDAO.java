package com.mega.mvc05;
//평범한 자바 차일 : POJO(Plain Old Java Object)

import java.util.ArrayList;

import org.springframework.stereotype.Component;

@Component //@Repository도 같은 기능을 하지만, DAO에만 사용 가능.
public class MemberDAO {
	
	public ArrayList<String> select(String find) {
		ArrayList<String> list = new ArrayList<String>();
		if(find.equals("자동차")) { 
			list.add("BENZ");
			list.add("BMW");
			list.add("SORENTO");
		} else {
			list.add("BOING747");
			list.add("CONGCODE");
		}
		return list;
	}
	
	public int login(MemberDTO dto) {
		int result = 0; //login이 안되는 상황, id pw 불일치
		String id = "root";
		String pw = "1234";
		if(id.equals(dto.getId()) && pw.equals(dto.getPw())) {
			result = 1; //id pw 일치
		}
		return result;
			
	}

	public void insert(MemberDTO dto) {
		System.out.println("dao에서 받은 dto내용\n" + dto); // \n 엔터 넣기
	}

	

}

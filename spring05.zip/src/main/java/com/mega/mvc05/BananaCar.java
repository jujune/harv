package com.mega.mvc05;

public class BananaCar implements Car {
	Window w;
		
	public BananaCar(Window w) {
		//super(); //부모의 기본 생성자를 호출
		this.w = w; //전역변수 초기화
	}
//	public BananaCar(Window w2) { //참고하기
//		//super(); //부모의 기본 생성자를 호출
//		w = w2; //전역변수 초기화
//	}

	@Override
	public void run() {
		System.out.println("Banana 달리다");
		//w = new LGWindow();
		w.open(); //주소값
		//Car는 Window에 의존적이다. (dependency, 의존성이 있다.)
		//코드상으로는 해당 객체의 주소값만 있으면 됨.
		//필요할 때 창문 클래스를 복사해서 객체를 사용함.
	}

	@Override
	public void stop() {
		System.out.println("Banana 멈추다");
		w.close();
	}
}

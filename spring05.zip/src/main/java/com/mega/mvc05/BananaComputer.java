package com.mega.mvc05;

public class BananaComputer implements Computer {
	Mouse m;
		
	@Override
	public void start() {
		System.out.println("BananaComputer 실행");
		m = new MiniMouse();
		m.click();
	}

	@Override
	public void off() {
		System.out.println("BananaComputer 종료");
	}

}

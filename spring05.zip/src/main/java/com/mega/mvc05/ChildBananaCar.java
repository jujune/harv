package com.mega.mvc05;

public class ChildBananaCar extends BananaCar {

		public void up() {
			System.out.println("속도를 up시키다");
			Car b = new ChildBananaCar();
			b.run();
			b.stop();
			
		}
}

package com.mega.mvc05;

public class AppleComputer implements Computer {

	@Override
	public void start() {
		System.out.println("AppleComputer 실행");
		MickeyMouse mic = new MickeyMouse();
		mic.click();
	}

	@Override
	public void off() {
		System.out.println("AppleComputer 종료");
		
	}

}

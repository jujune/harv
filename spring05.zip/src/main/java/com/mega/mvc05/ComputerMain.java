
package com.mega.mvc05;

public class ComputerMain {

	public static void main(String[] args) {
		AppleComputer a = new AppleComputer();
		a.start();
		
		BananaComputer b = new BananaComputer();
		b.start();
	}

}

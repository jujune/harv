package com.mega.mvc05;

public class LGWindow implements Window {

	@Override
	public void open() {
		System.out.println("LG 창문이 열리다");
	}

	@Override
	public void close() {
		System.out.println("LG 창문이 닫히");
	}

}


package com.mega.mvc05;

import javax.swing.JOptionPane;

public class CarMain2 {
	public static Window w;
	
	public static void main(String[] args) {
		Factory factory = new Factory();
		
		String name = JOptionPane.showInputDialog("kcc, lg중  선택");
		
		w = (Window)factory.getBean("kcc"); //(Window)는 다운캐스팅
		
		Car b = new BananaCar(w); //Upcasting		
		b.run();
		b.stop();
		
	}

}

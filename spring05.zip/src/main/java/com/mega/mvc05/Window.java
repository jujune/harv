package com.mega.mvc05;

public interface Window {
	//인터페이스에는 일반변수를 넣지 않는다.
	//꼭 있어야하는 기능 중심으로 규격을 정의하는 문서역할
	public abstract void open();
	public abstract void close();
	
}

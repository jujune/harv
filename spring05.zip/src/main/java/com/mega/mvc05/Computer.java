package com.mega.mvc05;

public interface Computer {

	public abstract void start();
	public abstract void off();
	
}

package com.mega.mvc05;

public class MickeyMouse implements Mouse {

	@Override
	public void click() {
		System.out.println("미키마우스 실행");
		System.out.println("브라우저 실행");
	}

}

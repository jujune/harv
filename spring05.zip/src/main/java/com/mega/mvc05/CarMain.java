package com.mega.mvc05;

public class CarMain {

	public static void main(String[] args) {
		AppleCar apple = new AppleCar();
		apple.run();
		apple.stop();
		
		System.out.println();
		
		KCCWindow w = new KCCWindow();
		Car b = new BananaCar(w); //Upcasting
		
		b.run();
		b.stop();
		
	}

}

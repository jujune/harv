package com.mega.mvc05;

public class KCCWindow implements Window {

	@Override
	public void open() {
		System.out.println("KCC 창문이 열리다");
	}

	@Override
	public void close() {
		System.out.println("KCC 창문이 닫히다");
		
	}


}

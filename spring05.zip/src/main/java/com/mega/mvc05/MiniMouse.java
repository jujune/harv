package com.mega.mvc05;

public class MiniMouse implements Mouse {

	@Override
	public void click() {
		System.out.println("미니마우스 실행");
		System.out.println("브라우저 실행");


	}

}

package com.mega.mvc05;

public interface Mouse {

	public abstract void click();
}

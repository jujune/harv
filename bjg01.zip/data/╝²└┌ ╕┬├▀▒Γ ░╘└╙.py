import random

ran_num = random.randint(0, 10)
print(ran_num)
input_num = -1;

while ran_num != input_num:
    print("맞춰보세요")
    input_num = input("숫자를 입력하세요(0~10) ")
    if ran_num == int(input_num):
        print("ㅂ2ㅂ2")
        break
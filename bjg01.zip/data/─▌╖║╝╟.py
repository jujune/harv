# 콜렉션의 4가지
# 리스트, 튜플, 딕셔너리, 셋(Set)

# person = ('홍길동', 100, 'mega') => (db에서의) row(레코드, 튜플)

person = ('홍길동', 100, 'mega')
print(person)

# person[0] = '김길동'
# print(person) # 튜플은 컬렉션 내용을 바꿀 수 없다.

person2 = list(person)
person2[0] = '김길동'
print(person2)
print("person2 타입 " + str(type(person2))) # 타입을 알 수 있게 함

person3 = tuple(person2)
print("person3 타입 " + str(type(person3)))

food = {'커피', '커피', '라면', '우유', '라면'}
print("food 타입 " + str(type(food)))
food2 = set() # 셋을 만듦 food2 = {} 도 될려나?
food2.add('라떼')
print(food)
print(food2)
# print(food[0]) # set은 가방과 같은 형태라 인덱싱을 가지지 않음

me = dict()
me['name'] = 'hong'
me['age'] = 100
me['company'] = 'mega'

print(me)
print('이름은 ', me['name'])

del me['company']
print(me)

for x in me: # x는 key만 출력
    print(x) # 딕셔너리를 그냥 돌리면 key만 나옴
    print(me[x]) # value









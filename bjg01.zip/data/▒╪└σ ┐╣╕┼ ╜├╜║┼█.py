seat_x = [0] * 10

for _ in range (0,2):
    print(seat_x)
print('------------------------------')

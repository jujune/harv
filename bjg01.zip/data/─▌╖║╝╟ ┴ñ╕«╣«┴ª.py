# 1
list = []

for _ in range (0,5):
    data = input('신입 사원 이름을 입력하세요>> ')
    list.append(data)
print(list)
list2 = tuple(list) # 변경 불가
print(list2)

# 2 튜플 명단은 수정 불가

# list2[0] = '김다인'

# 3

list1 = []
dict1 = {'수강자id' : '100', '수강과목' : '파이썬', '강의실' : '708호', '강의료': 2000}
dict2 = {'수강자id' : '100', '수강과목' : '자바', '강의실' : '709호', '강의료': 3000}
dict3 = {'수강자id' : '200', '수강과목' : '소켓', '강의실' : '709호', '강의료': 5000}

list1.append(dict1)
list1.append(dict2)
list1.append(dict3)

print(list1)

sum = 0

for x in list1:
    print(x)
    if x['수강자id'] == '100':
       sum = sum + x['강의료']

print("수강자id가 100번인 사람의 총 강의료" + str(sum))


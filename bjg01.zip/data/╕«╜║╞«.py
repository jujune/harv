# 입력을 받아서 리스트에 넣어봅시다

data = [] # 할당 연산자
data.append(100)

print(data[0])

list = []

data1 = int(input("데이터를 입력하세요1 >>"))
data2 = int(input("데이터를 입력하세요2 >>"))
data3 = int(input("데이터를 입력하세요3 >>"))

list.append(data1)
list.append(data2)
list.append(data3)

print(list)
for i in list:
    print(i)
print('-----------------')

num = 0
for i in list:
    num = num + i
print(num)
print('-----------------')
for i in list: # for문에는 indent를 잘 넣어줘야 한다.
    if i % 2 == 0:
        print(i)
    else:
        pass

for _ in range (0,3): # i값을 활용하지 않을 때는 _로 대체
    data.append(int(input('숫자 입력>>> ')))

print(data) # 리스트 전체 내용 확인

for x in data: # for each인 셈
    print(x, end=' ')
print('\n------------ㅋ--')
# escape문자 ;  문자를 대체하는 요소. \n외에도 좀 있움.
for i in range (0,3):
    print(data[i], end=' ')

print('\n------------')

print() # 줄 띄우기


str = '가나다라마바사'

# 인덱싱과 슬라이싱이 된다.

print(str[0:3])
print(str[4:6])

str2 = '50,60,70,80,90'
str_list = str2.split(',')
print(type(str_list))
print(str_list)

str3 = '100:200:300:400:500'
# 전체 합계를 프린트

str3_list = str3.split(':')
print(str3_list)

sum = 0
for x in str3_list:
    sum = sum + int(x)
print(sum)

int_map = map(int, str3_list)
print(type(int_map))
print(list(int_map))
# 연산자 종류
# 산술 연산자, 비교 연산자, 논리 연산자

# 산술 연산자 : + - * / %(나머지) //(나머지 버려 정수화)
# 비교 연산자 : == != > <
# 논리 연산자 : and or

id = 'root'
pw = '1234'

id2 = input('id>> ')
pw2 = input('pw>> ')

if id == id2 and pw == pw2:
    print("로그인 성공")
else:
    print("로그인 실패")
import random

print(random.randint(0, 10)) #0~10
print(random.randrange(0, 10)) #0~9
print(random.choice(['가위', '바위', '보']))


person1 = list()
for x in range (0, 5):
    person1.append(random.randint(50, 100))

print(person1)


list1 = []
random.seed(100) # 정해진 랜덤 결과값의 셋?을 설정
for _ in range (0, 1000):
    person2 = list()
    for _ in range (0, 5):
        person2.append(random.randint(50, 100))
    list1.append(person2)

print(list1)
print(len(list1), "명") # length 함수

print('각 사람의 국어점수')
for x in list1:
    print(x[0], end=" ")

print("\n 평균 값")

sum = 0
for person in list1:
    sum = sum + person[0]

print(sum / len(list1))


############################
file = open('total.txt', 'w') # write 쓰기모드
for person in list1:
    file.write(str(person))
    file.write("\n")

file2 = open('total.txt', 'r')
# print(file2.readline())
row1 = file2.readline()
str1 = row1.split(", '\n']")
print(str1)
person2 = list(row1)
print(person2)
print(type(person2))
print(person2[2])
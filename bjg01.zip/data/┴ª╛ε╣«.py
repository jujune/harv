#순차문

#조건문

#반복문
num = 1
while num <= 10:
    print(num)
    num = num + 1 # num += 1 과 같음


# for , for-each # 리스트

foods = ["짬뽕", "우동", "김밥"]

for imsi in foods:
    print("내가 먹고 싶은 음식은 " + imsi)

# print(foods[0])
# print(foods[1])
# print(foods[2])

for i in range(0, 3, 1): #0,1,2.. 맨 뒤에 몇번째마다 불러올지 정하는것. 간격
    print(foods[i])
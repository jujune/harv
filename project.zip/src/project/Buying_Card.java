package project;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Buying_Card {
	private static JPasswordField pw3;
	private static JTextField textField_1;
	private static JPasswordField pw0;
	private static JPasswordField pw1;
	private static JPasswordField pw2;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(1000,800);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("구매 곡 정보");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(12, 32, 406, 57);
		f.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(34, 88, 387, 555);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("커버");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 10, 43, 42);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("커버");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(12, 63, 43, 42);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2.setBounds(67, 10, 210, 42);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2_1.setBounds(67, 63, 210, 42);
		panel.add(lblNewLabel_2_1);
		
		JLabel l3 = new JLabel("총 10곡 X 800원 = 합계 8,000원");
		l3.setOpaque(true); //Opaque값을 true로 미리 설정해 주어야 배경색이 적용된다.
		l3.setBackground(Color.WHITE);
		l3.setHorizontalAlignment(SwingConstants.CENTER);
		l3.setBounds(34, 668, 384, 57);
		f.getContentPane().add(l3);
		
		
		JLabel lblNewLabel_4 = new JLabel("결제방식");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(465, 32, 142, 86);
		f.getContentPane().add(lblNewLabel_4);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(478, 159, 462, 379);
		panel_1.setLayout(null);

		f.getContentPane().add(panel_1);
		
		JButton btnNewButton = new JButton("카드");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		btnNewButton.setBounds(630, 32, 142, 86);
		f.getContentPane().add(btnNewButton);
		
		/////////////////////////////
		
		panel_1.removeAll();
		
		JLabel lblNewLabel_7 = new JLabel("카드사 선택");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(12, 10, 102, 29);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_7_1 = new JLabel("카드번호 입력");
		lblNewLabel_7_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_1.setBounds(12, 60, 102, 23);
		panel_1.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_7_2 = new JLabel("유효기간");
		lblNewLabel_7_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_2.setBounds(12, 99, 102, 29);
		panel_1.add(lblNewLabel_7_2);
		
		JLabel lblNewLabel_7_3 = new JLabel("CVC");
		lblNewLabel_7_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_3.setBounds(271, 99, 102, 29);
		panel_1.add(lblNewLabel_7_3);
		
		JLabel lblNewLabel_7_4 = new JLabel("비밀번호");
		lblNewLabel_7_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_4.setBounds(12, 141, 102, 29);
		panel_1.add(lblNewLabel_7_4);
		
		JTextField t0 = new JTextField();
		t0.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (t0.getText().length() == 5) {
					t0.setEditable(false);
					JOptionPane.showMessageDialog(null, "5자리 이상 입력할 수 없습니다.");
					t0.setText(null);
					t0.setEditable(true);
				}
			}
		});
		t0.setBounds(137, 60, 65, 23);
		panel_1.add(t0);
		t0.setColumns(10);
		
		JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(368, 60, 65, 23);
		panel_1.add(textField_3);
		
		JTextField textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(137, 103, 27, 21);
		panel_1.add(textField_4);
		
		String card[] = {"현대카드", "신한카드", "BC카드", "KB국민카드", "삼성카드", "우리카드", "카카오뱅크", "NH채움카드", "롯데카드", "하나카드"};
		JComboBox comboBox = new JComboBox(card);
		comboBox.setBounds(137, 14, 142, 23);
		panel_1.add(comboBox);
		
		JLabel lblNewLabel_8 = new JLabel("**");
		lblNewLabel_8.setBounds(175, 145, 27, 25);
		panel_1.add(lblNewLabel_8);
		
		pw3 = new JPasswordField(); //jtextfield 정규식 검색
		pw3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (pw3.getText().length() == 3) { /////////////////////////
					pw3.setEditable(false);
					System.out.println(pw3.getText());
					JOptionPane.showMessageDialog(null, "3자리 이상 입력할 수 없습니다.");
					pw3.setText(null);
					pw3.setEditable(true);
				}
			}
		});
		pw3.setBounds(137, 145, 36, 21);
		panel_1.add(pw3);
		
		JLabel lblNewLabel_7_4_1 = new JLabel("할부 ");
		lblNewLabel_7_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7_4_1.setBounds(12, 180, 102, 29);
		panel_1.add(lblNewLabel_7_4_1);
		
		String installment[] = {"일시불", "2개월", "3개월", "4개월", "5개월", "6개월", "9개월", "12개월"};
		JComboBox comboBox_1 = new JComboBox(installment);
		comboBox_1.setBounds(137, 184, 102, 23);
		panel_1.add(comboBox_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(176, 103, 27, 21);
		panel_1.add(textField_1);
		
		JLabel lblNewLabel_8_1 = new JLabel("/");
		lblNewLabel_8_1.setFont(new Font("굴림", Font.PLAIN, 14));
		lblNewLabel_8_1.setBounds(166, 102, 20, 23);
		panel_1.add(lblNewLabel_8_1);
		
		pw0 = new JPasswordField();
		pw0.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (pw0.getText().length() == 5) { 
					pw0.setEditable(false);
					System.out.println(pw0.getText());
					JOptionPane.showMessageDialog(null, "5자리 이상 입력할 수 없습니다.");
					pw0.setText(null);
					pw0.setEditable(true);
			}
			}
		});
		pw0.setBounds(214, 60, 65, 23);
		panel_1.add(pw0);
		
		pw1 = new JPasswordField();
		pw1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (pw1.getText().length() == 5) { 
					pw1.setEditable(false);
					System.out.println(pw1.getText());
					JOptionPane.showMessageDialog(null, "5자리 이상 입력할 수 없습니다.");
					pw1.setText(null);
					pw1.setEditable(true);
			}
			}
		});
		pw1.setBounds(291, 61, 65, 23);
		panel_1.add(pw1);
		
		pw2 = new JPasswordField();
		pw2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (pw2.getText().length() == 4) { 
					pw2.setEditable(false);
					System.out.println(pw2.getText());
					JOptionPane.showMessageDialog(null, "4자리 이상 입력할 수 없습니다.");
					pw2.setText(null);
					pw2.setEditable(true);
			}
			}
		});
		pw2.setBounds(368, 102, 65, 23);
		panel_1.add(pw2);
		
		panel_1.revalidate(); //다시 일깨우는, 불러일으키는 역할
		panel_1.repaint(); //위와 같음.. 
		
		/////////////////////////////
		
		JButton btnNewButton_1 = new JButton("무통장 입금");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(798, 32, 142, 86);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("결제 시도");
		btnNewButton_2.setBounds(478, 575, 462, 68);
		f.getContentPane().add(btnNewButton_2);
		
		JLabel l6 = new JLabel("결제 결과");
		l6.setOpaque(true);
		l6.setBackground(Color.WHITE);
		l6.setHorizontalAlignment(SwingConstants.CENTER);
		l6.setBounds(478, 668, 462, 57);
		f.getContentPane().add(l6);
		
		
		
		f.setVisible(true);
		
	}
}

package project;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class asd extends JFrame { //JFrame에서 쓸 수 있는 함수를 다 쓸 수 있게 함. 상속! 
	GridBagLayout gbl; // 그리드백 레이아웃을 사용하기 위한 변수 선언
	GridBagConstraints gbc; // 그리드백 레이아웃에 넣을 요소 변수 선언
	static String logId = null; // 로그인이 되면 로그인된 아이디로 바꿔줄 전역변수

	public asd() {
		gbl = new GridBagLayout();
		gbc = new GridBagConstraints(); 
		setLayout(gbl); // 레이아웃을 그리드백 레이아웃으로 설정
		gbc.fill = GridBagConstraints.BOTH; // 빈 공간 없이 채워줌

		JPanel chartPanel = new JPanel(); // 실시간 차트를 올릴 패널
		chartPanel.setBackground(new Color(50, 205, 50));
		chartPanel.setPreferredSize(new Dimension(900, 900)); // 패널의 크기 설정
		// 전체 곡 리스트의 크기 만큼만 패널의 크기를 설정해줌

		JScrollPane js = new JScrollPane(chartPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // 차트를 넣은 패널에 스크롤을 붙여줌
		// 세로스크롤은 필요할때만 표시하고, 가로스크롤은 표시하지 않는다.
		js.setPreferredSize(new Dimension(900, 900)); // 스크롤의 크기 설정, 차트의 크기만큼
		gbc.weightx = 0.1;
		gbc.weighty = 0.1;
		JLabel melonLbl = new JLabel();
		melonLbl.setIcon(new ImageIcon("logo_melon142x99.png"));

		gbAdd(melonLbl, 0, 0, 1, 1);
		JButton logInBtn = new JButton("로그인");
		gbAdd(logInBtn, 1, 0, 1, 1);
		gbAdd(new JButton("곡 구매"), 2, 0, 1, 1);
		gbAdd(new JButton("나만의 앨범"), 3, 0, 1, 1);
		// 실시간 차트 제목 라벨
		gbAdd(new JLabel("실시간 차트"), 0, 1, 4, 1);

		// 실시간차트를 나머지 요소보다 세로길이를 길게 해줌
		gbc.weighty = 20.0;
		// 실시간차트를 넣은 패널
		gbAdd(js, 0, 2, 4, 1);

		setSize(1000, 800);
		setVisible(true);
	}

	private void gbAdd(Component c, int x, int y, int w, int h) {
		gbc.gridx = x; // 그리드백 요소의 x좌표
		gbc.gridy = y; // 그리드백 요소의 y좌표
		gbc.gridwidth = w; // 그리드백 요소의 가로길이
		gbc.gridheight = h; // 그리드백 요소의 세로 길이
		gbl.setConstraints(c, gbc); // 해당요소를 그리드백 레이아웃에 띄워줌
		add(c);

	}

	public static void main(String[] args) {
		new asd(); // 메인창 호출
	}
}
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ProjectDAO {
	String url = "jdbc:mysql://localhost:3708/project";
	String user = "root";
	String password = "1234";
	
	public ArrayList<Cart_DTO> all() { //전체 검색하기, DTO에 담아내는 과정, 리스트가 반환됨
		ArrayList<Cart_DTO> list = new ArrayList<>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select song_id, song_title, artist, album_cover from cart";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery(); 
			
			while (rs.next()) {
				Cart_DTO dto = new Cart_DTO();
				
				int song_id = rs.getInt(1);
				String song_title = rs.getString(2);
				String artist = rs.getString(3);
				String album_cover = rs.getString(4);
				
				dto.setSong_id(song_id);
				dto.setSong_title(song_title);
				dto.setArtist(artist);
				dto.setAlbum_cover(album_cover);
				
				list.add(dto);  //DTO에 데이터에 각 행을 담음
			}
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	

}

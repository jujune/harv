# 자판기 만들기

# 포카리, 코카콜라, 레쓰비, 초코송이, 빼빼로, 다이제, 자일리톨
# 800, 800, 600, 900, 1000, 1500, 1000
# 7, 6, 4, 5, 7, 0, 8

# 자판기 메뉴, 가격, 재고수량 리스트 작성
menu = ['포카리', '코카콜라', '레쓰비', '초코송이', '빼빼로', '다이제', '자일리톨']
price = [800, 800, 600, 900, 1000, 1500, 1000]
stock = [7, 6, 4, 5, 7, 0, 8]
total = 0


while True:

    while True:
        print('-------------------------------------------------')
        for x in menu:
            print(x, end=" ")
        print()
        for x in stock:
            print(" ", x, end="    ")
        print()
        print('-------------------------------------------------')
        choice = input('메뉴를 선택하세요>> ')
        index = menu.index(choice)
        if menu[index] == choice and stock[index] > 0:
            print(price[index], '원을 지불하세요')
            break
        elif menu[index] == choice and stock[index] == 0:
            print('품절입니다. 다시 선택해주세요.')

    pay = input('결제 수단을 결정하세요. 카드 or 현금>> ')

    if pay == '카드':
        card = input('카드를 태그하시겠습니까? (Y/N)')
        total = total + price[index]
        if card == 'y' or card == 'Y':
            pass
        else:
            print('결제가 취소되었습니다. 다시 진행해주세요.')
            print()
            continue
    elif pay == '현금':
        while True:
            if total < price[index]:
                cash = input('현금을 넣어주세요. 취소는 X : ')
                if cash == 'x' or cash == 'X':
                    print()
                    break
                else:
                    total = total + int(cash)
                    print('현재금액: ', total, '원')
            elif total >= price[index]:
                break

    print('-----------------------------------')
    print('구매 상품 ', menu[index], price[index], '원')
    print('지불 금액 ', total, '원')
    print('거스름돈', total - price[index], '원')
    print('-----------------------------------')
    stock[index] = stock[index] - 1

# 극장 예매 시스템
# 1. 화면을 만든다.
# --0이 10개 들어간 리스트 필요!

#print(seat) #확인용
seat = [0] * 10 # 요러면 0이 리스트에 10개 들어감
count = 0
pay = 0
name = input('성함을 입력해주세요: ')

while True:
    #자리 번호 프린트
    print('--------------------------------------')
    # Alt + 화살표 = 해당 줄 위치 바꾸기
    # Ctrl + Alt + 아래 화살표 = 해당 줄 아래로 복사
    for x in range(1, len(seat)+1):
        print(x, end=" ")
    print('\n--------------------------------------') # 역슬러시 + n = 줄바꿈
    # 자리 예약 상태 프린트 (0=예약x, 1=예약o)
    for x in seat:
        print(x, end=" ")
    print('\n--------------------------------------')
    choice = int(input('원하는 좌석 번호 입력(종료: 0)>> '))-1
    if choice == -1:
        print()
        print("예매 프로그램을 종료합니다.")
        break
    # 입력값은 리스트의 index로 사용될 예정
    # index = 좌석번호
    print(choice, '를 선택하셨군요!')
    print()

    # 이미 예매처리가 된 경우, 불가능하다고 처리
    if seat[choice] == 1:
        print('이미 예매가 완료된 좌석입니다.')
        print('다른 좌석을 선택해주세요')
    else:
        # 예매처리가 안된 경우
        # 입력 받은 좌석 번호로 예매처리
        seat[choice] = 1
        count = count + 1  # for문이나 count함수로 가능

print('예매 처리를 완료하였습니다.')
print(name, '님의 예매 확인 영수증입니다.')
print('--------------------------------')
print('예매된 좌석 번호는')
for x in range(0, len(seat)):
    if seat[x] == 1:
        print(x + 1, '번', end=" ")
print()
print('전체 예매된 좌석 수는', count, '좌석')
print('결제 금액은', count * 10000, '원')
print()

class TV:
    channel = 0
    volume = 0


    def watch(self):
        print('tv를 보다')

    def sound(self):
        print('볼륨을 높이다')

    def __str__(self):
        return str(self.channel) + ', ' + str(self.volume)

if __name__ == '__main__':

    tv = TV()
    tv.channel = 22
    tv.volume = 7

    tv.watch()
    tv.sound()
    print(tv)
from tkinter.messagebox import *
from tkinter import *

#showinfo("반가워용") #다이얼로그 박스

def check():
    #입력값 가지고 오기
    #회원가입 시의 데이터와 비교 인증
    get_id = id_text.get()
    get_pw = pw_text.get()
    showinfo('당신이 입력한 id는 ', get_id)
    showinfo('당신이 입력한 pw는 ', get_pw)

w = Tk()
w.geometry('500x400')
w.config(bg='lime')

id_label = Label(w, text='사용자id입력', font=('맑은 고딕', 30), bg='lime', fg='blue')
pw_label = Label(w, text='사용자pw입력', font=('맑은 고딕', 30), bg='lime', fg='blue')
id_text = Entry(w, font=('맑은 고딕', 30), bg='yellow', fg='red')
pw_text = Entry(w, font=('맑은 고딕', 30), bg='yellow', fg='red')

icon = PhotoImage(file='naver.png')
button = Button(w, image=icon, command=check)


id_label.pack() # 알아서 위치 잡으라는 의미
id_text.pack()
pw_label.pack()
pw_text.pack()
button.pack()


w.mainloop()

def call1(x, y):
    print(x + y)

call1(x=200, y=100)

def call2(x=200, y=100):
    print(x + y)

call2(x=222) # y값은 정의해준 그대로 100 사용
call2(333) # x값만 들어왓다고 받아들임

def call3(x, y=100):
    print(x + y)
call3(333)

#def call4(x=10, y):
#    print(x + y)
# call4(444) #기본값을 주려면 무조건 뒷쪽에 둬야 컴퓨터가 받아들임
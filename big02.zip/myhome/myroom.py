from person.woman import *
from device.tool import *

girl = Girl()
tv = TV()

girl.age = 10
girl.name = '호호'

girl.seat()
girl.tv()
print(girl)

tv.channel = 27
tv.volume = 12

tv.watch()
tv.sound()
print(tv)

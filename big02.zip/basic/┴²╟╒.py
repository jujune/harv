#a = ['1', '2', '3', '4', '5']
#b = ['3', '4', '5', '6', '7']
a = [1, 2, 3, 4, 5]
b = [3, 4, 5, 6, 7]

# 교집합 합집합 차집합

aa = set(a) #집합의 특징 사용하고 싶을 때 set으로 바꿈
bb = set(b)

print(aa.intersection(bb)) # 교집합
print(aa.union(bb)) # 합집합
print(max(a)) # 최대값
print(sum(a)) # 총합
eval("print('aaa')") # "" 안의 문자열이 코드라고 가정하고 실행함
print(sorted(b)) # 오름차순 정렬
print(len(b)) # 리스트의 개수
print(list(zip(a,b)))

names = ['홍길동', '박길동', '정길동']
ages = [100, 200, 300]
company = ['더조은', '메가', '스터디']
print(list(zip(names, ages, company)))

print(str(100) + '안녕') # 타입이 동일해야지만 프린트 가능


#1
if 13 %2 == 1:
    print('홀수입니다')
else:
    print("짝수입니다")


#2
j = '881120-1068234'
j1 = j.split('-')
j2 = j1[1][0:1]

if j2 == 1 or 3:
    print("남성입니다")
elif j2 == 2 or 4:
    print("여성입니다")

#3
c = [22, 44, 66, 11, 99]
print(max(c))


#4
score  = (99,11,55,22,88)
examtime=list(score)
examtime[0]=100
print(examtime)

#4
score = [99,11,55,22,88]
print("시험 성적: ", tuple(score))
score[0]= 100
print("변경한 성적: ", score)

#5
member= { 'id':'root' , 'pw':'1234','name':'홍길동','tel':'888-1234' }
print(member['name'])
for key, value in member.items():
    print(key, ':', value)

#6
c1 = {22,99,11,23}
c2 = {44,99,24,55}
c3 = set(c1)
c4 = set(c2)

print(c3.union(c4))
print(c3.intersection(c4))




def add(summ, waterr):
    result = summ + waterr
    return result

def mul(price, count):
    result = price * count
    return result

# return이 없는 함수는 프린트 할 수 없다.

if __name__ == '__main__': # 메인이 있으면 실행시켜줘 (import 시켰을 때 실행되지 않게 하려고.) 외부에서 호출 안됨.
    print(add(100, 1000))
    print(add(1000,5))
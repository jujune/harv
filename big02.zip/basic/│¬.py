def todo1():
    input("오늘 학원에서 할 일은?")


def todo2():
    input("오늘 집에서 할 일은?")


def todo3():
    act = input("오늘 할 운동은?")
    return act
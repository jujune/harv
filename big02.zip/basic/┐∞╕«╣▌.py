from basic.나 import *
import basic.친구 as friend

todo1()
todo2()
result = todo3()
print(result)

friend.together('호호', '거난이')

def together(x, y):
    print("%s와 %s랑 함께 놀러가자!" %(x, y))
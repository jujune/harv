def call1(x, y): #입력값을 표현해주기 위한 괄호
    # print(x , '+', y, '=', x + y)
    result = x + y
    print('%d + %d = %d' %(x, y, result))
    # %d : 정수(decimal)가 들어갈 자리. 뒤에 %에 순서대로 적어줌. 튜플 형대로 묶어줌

def call2(x):
    print("입력한 하나의 값은 %d" %x)

def call3(x):
    print("입력한 하나의 값은 %s" %x)
    # %s : 문자(String)가 들어갈 자리.

def call4(x):
    print("입력한 하나의 값은 %f" %x)
    print("입력한 하나의 값은 %10.2f" %x) # 뒤에 소수점 몇째 자리까지 나타낼지 (0.2f)로 표현

def call5(x):
    print(type(x))
    for item in x:
        print(item, end=" ")
    print()

def call6(x):
    for item in x:
        # print(item, end=" ") # key만 출력
        print(x[item], end=" ") # value 가져옴
    print('\n--------------------------')
    print(x.items()) # items : 튜플의 리스트를 만들어 주는 아이
    for key, value in x.items(): # 딕셔너리(x)에 items함수를 적용하면 키, 밸류 형태로 가져올 수 있음
        print(key, ':', value)
    print('--------------------------')
    for key in x.keys(): # key만 가져옴
        print(key, end=" ")
    print('\n--------------------------')
    for value in x.values(): # value만 가져옴
        print(value, end=' ')

def call7(x):
    print('\n\n내 점수는 {0}'.format(x)) # string에서 제공하는 함수

def call8(x):
    print('\n나의 취미는 {0}, {1}, {2}'.format(x[0], x[1], x[2]))

call1(200, 100)
call2(10)
call3('하이')
call4(125.6666)
print()
food = ['감자', '고구마', '양파']
call5(food)
print()
me = {'이름':'홍길동' , '나이':'100', '소속':'메가'}
call6(me)
call7(100)
hobby = ['운동', '독서', '맛집']
call8(hobby)
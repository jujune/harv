#import basic.계산기 as cal               #import 방법 1
from basic.계산기 import *                #import 방법 2

coffee_price = 3700 # 언더바를 snake 표기법이라 함
tea_price = 4000

choice = int(input("뭐 드실래요 1)커피, 2)차"))
count = int(input('몇 잔 주문하시겠어요? '))
price = 0

if choice == 1:
    price = coffee_price
if choice == 2:
    price = tea_price

sum1 = mul(price, count) # sum1 <- result
#sum1 = basic.계산기.mul(price, count) # sum1 <- result
#sum1 = cal.mul(price, count) # sum1 <- result
print('당신의 지금까지 주문금액은 ', sum1, '원')
extra = int(input('물을 추가 주문하시겠습니까? 1)네, 2)아니요'))
water = 1500
if extra == 2:
    water == 0

sum2 = add(sum1, water) # 자동 import ; 커서 갖다놓고 alt + enter
print(sum2, "원")

print("당신의 지금까지의 총 금액은 ", sum2, '원')
if sum2 >= 20000:
    print(sum2 - 5000, '원을 지불하시면 됩니다.')
else:
    print(sum2, '원을 지불하시면 됩니다.')
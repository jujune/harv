#1

name = []
for _ in range (0, 5) :
    name_input = input("이름을 입력하세요")
    name.append(name_input)

for x in range (0, 5):
    print(name[x], end=" ")

print()

for x in name:
    print(x, end=" ")

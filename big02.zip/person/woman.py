class Mom:
    doing = ''
    like = ''

    def tour(self):
        print('여행을 간다')

    def free(self):
        print('자유 시간을 즐긴다')

    def __str__(self):
        return self.doing + ', ' + self.like


class Girl: # 파이썬에서는 파일 이름과 클래스 명이 달라도 됨. 1개의 파일 안에 객체를 여러개 정의할 수 있음.
    name = ''
    age = 0

    def seat(self): # 자기 자신을 말함. Java의 this와 비슷.
        print("앉아 있음ㅋ")

    def tv(self):
        print('tv를 보고 있음ㅋ')

    def __str__(self): # toString과 같음
        return self.name + ', ' + str(self.age)

if __name__ == '__main__':
    girl1 = Girl()
    girl1.age = 10
    girl1.name = '도봉순'

    print(girl1)
    girl1.seat()
    girl1.tv()

    mom = Mom()
    mom.doing = '운동'
    mom.like = '음식'
    print(mom)
    mom.free()
    mom.tour()


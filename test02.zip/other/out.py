#계산기 세부 기능
def plus(): #def = definition
    print('더하기 기능 처리')
    # 두 수를 입력 받아서 더하기 처리
    a = input('더하고 싶은 첫 번째 수? ')
    b = input('더하고 싶은 두 번째 수? ')
    a1 = int(a)
    b1 = int(b)
    print(a1+b1)

def minus():
    print("빼기 기능 처리")
    # 두 수를 입력 받아서 빼기 처리

def mul():
    print('곱하기 기능 처리')
    d1 = input('숫자입력1 ')
    d2 = input('숫자입력1 ')
    d11 = int(d1)
    d22 = int(d2)
    print(d11*d22)
def info():
    a = input('같이 보는 사람 이름은?')
    b = input('어떤 관계인가요?')
    print("이름은 " + a + "이고, 관계는 " + b + "입니다")

def pay():
    price = 10000
    a = input('관람객이 몇 명인가요?')
    a1 = int(a)
    b = price*a1
    print("지불할 총액은 " + str(b) + "원 입니다")
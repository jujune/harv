id = "root" #정확한 id값 지정
id2 = input("로그인할 id를 입력>> ") #입력되는 id값 변수화

if id == id2 : #입력된 id가 true일 경우
    print("로그인 되었습니다") #표기 메세지
else : #False일 경우
    print("로그인되지 않았습니다.") #표기 메세지
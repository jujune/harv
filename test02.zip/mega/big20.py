While은 반복문
while True: #파이썬에서는 T/F 첫글자는 대문자
    print('1시간 남았어요.')

a = 10
while a > 0:
    print(a, end=" ")
    a = a - 1

# 1. 0부터 99까지 찍어보세요
# 2. 1부터 100까지 찍어보세요

b = 0
while b < 100:
    print(b)
    b = b + 1

c = 1
while c < 101:
    print(c)
    c = c + 1

# 1부터 100까지 중 짝수만 찍어보세요
d = 0
while d <= 100:
    if(d % 2 == 0):
        print(d)
    d = d + 1

#'집에 가요' 5번 나오게 하세요
start = 0 #시작
while start < 5: #조건
    print('집에 가요.')
    start = start + 1 #증감식

# 0~99 중 5의 배수의 개수를 구해보세요
start = 0
count = 0
while start < 100:
    if start % 5 == 0:
        count = count + 1
    start = start + 1
print('5의 배수는 ', count, '개')

# Shift + Tab / Backspace 들여쓰기
# Tab 내어쓰기

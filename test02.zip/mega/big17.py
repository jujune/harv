#계산기 모듈을 여기에 쓰겠다라고 표현해야함

from other import out #other 패키지의 out파일 사용!

out.plus() #.온점은 안으로 더 들어가는 개념
out.minus()

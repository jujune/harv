time = input('지금은 몇 시 입니까?') #시간 입력 + 변수 지정
time = int(time) #변수의 정수화
if time < 12 : #True일 경우 조건
    print("점심 전입니다. 맛있게 드세요!") #True 시 표기 문구
else : #False일 경우
    print("점심 후입니다") #False표기문구
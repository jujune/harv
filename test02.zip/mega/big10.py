english = int(input("영어점수 입력: ")) #영어점수 입력 + 정수화 + 변수 지정
math = int(input("수학점수 입력: ")) #수학점수 입력 + 정수화 + 변수 지정
korean = int(input("국어점수 입력: ")) #국어점수 입력 + 정수화 + 변수 지정
print('------------------')  #--------프린트
sum = english + math + korean #총점 구하기
print('세 과목의 합은', sum, '점') #총점 표시
print('세 과목의 평균은', int(sum/3), '점') #평균 점수 표시 + 소수점 아랫자리 생략

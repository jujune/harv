name = input("당신의 이름은: ")
job = input("당신의 직업은: ")
print("--------------------------")
print("*", name, "은", job, "입니다", "*")

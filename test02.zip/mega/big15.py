# 콘솔에서 당신의 짝이름을 입력 받으세요.
# 콘솔에서 당신의 짝관심사를 입력 받으세요.
# 메세지 박스로 당신의 짝이름과 관심사를 확인하여 출력
# 관심사가 파이썬이라고 한다면, "프로그래머가 되실 거군요"
# 아니라면, "데이터 분석가가 되실 거군요" 출력

name = input("당신의 짝이름은?")
good = input("당신 짝의 관심사는?")

from tkinter import messagebox

messagebox.showinfo('이름 확인', "이름 : " + name + "/ 관심사 : " + good)

if good == '파이썬' :
    messagebox.showinfo('결과', '프로그래머가 되실 거군요')
else :
    messagebox.showinfo('결과', '데이터 분석가가 되실거군요')




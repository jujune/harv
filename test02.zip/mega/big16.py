from tkinter import messagebox

result = messagebox.askquestion('질문','파이썬이 확실한가요?')

if result == 'yes' :
    messagebox.showinfo('답안', '열심히 하세요!')
else:
    messagebox.showinfo('답안', '그럼 생각중이시군요!')

num1 = 33 #숫자
num2 = 4 #int로 인식

print('나누기 / >>', num1 / num2)
print('나누기 / >>', num1 // num2)
print('나누기 %  (나머지)>> ', num1 % num2)

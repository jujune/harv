number1 = input("숫자1: ")
number2 = input("숫자2: ")
a = int(number1)
b = int(number2)
print("----------")
print(a, "과 ", b, "의 합은 ", a+b, "입니다.")
print(a, "과 ", b, "의 뺄셈은 ", a-b, "입니다.")
print(a, "과 ", b, "의 곱은 ", a*b, "입니다.")
print(a, "과 ", b, "의 나눔은 ", a/b, "입니다.")
print(a, "과 ", b, "의 나머지는 ", a%b , "입니다.")



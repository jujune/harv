price = input("커피값 입력") #커피값을 price로 지정
count = input("커피 인원 수") #인원 수를 count로 지정

p = int(price) #price를 정수값 변환
c = int(count) #count를 정수값 변환

sum = p*c #가격의 총합 구하기

if p*c >= 20000 : #if 사용해 총 가격이 20000 이상일 경우 확인
    print("2000원을 할인해드립니다.") #해당일 때 표현 문구
    print(sum-2000, "원입니다") #총 가격에서 할인된 가격과 해당일 때 표현 문구
else :
    print("계산값을 다 지불하셔야 합니다") #아닐 경우 표현 문구
    print(sum, "원입니다") #할인되지 않은 총 가격과 표현 문구


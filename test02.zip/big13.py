
price_stic = 1000
price_bookmark = 2500
# 가격은 고정값이기에 변수선언을 한다.

print("안녕하세요 교보문고입니다.") # 그냥 인사문구
print("---------------------------------")

stic_count = int(input("스키터는 몇개 구매하실 것인가요?  : "))
bookmark_count = int(input("책갈피는 몇개 구매하실 것인가요? : "))
# 구매량은 입력값이기에 input을 사용하여 변수선언을 해준다.

sum = (price_stic * stic_count) + \
      (price_bookmark * bookmark_count)
# 총 금액을 가격과 구매량을 곱하여 더해준 양을 변수선언 해준다.

prime = input("우수회원입니까?(Y/N로 대답) : ")
# 우수회원 여부를 묻되 답을 고정하기 위해 Y와 N으로 설정해준다.

if prime == "Y":
    print("총 금액은", sum*0.9)
else:
    print("총 금액은", sum)

# 우수회원일 경우와 아닐 경우이기 때문에 조건문을 사용해서
# 우수회원일 경우 sum에서 10%할인한 금액을 프린트
# 아니면 그대로 프린트해준다.
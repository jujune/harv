package 클래스만들기;

public class 계산기 {
	//사칙연산
	public int mul(int count) {
		//매개변수, 지역변수, 값을 전달(call by value)
		System.out.println("곱하기 처리");
		int price = 5000;
		int sum = price * count;
		//System.out.println("당신이 지불할 금액 총액은 " + sum + "원");
		return sum; //반환할 변수를 지정
	}
	
	//void: '없는' 라는 뜻. 리턴이 없다.
	public int add(int waffle, int coffee) {
		System.out.println("더하기 처리");
		int count = coffee + waffle;
		System.out.println("총 주문 개수: " + count + "개");
		return count; //그렇지만 void를 해당 타입으로 (int로) 바꾸면 return할 수 있음. 값을 남겨 가진다는 의미
	}
	
	
	
	
}

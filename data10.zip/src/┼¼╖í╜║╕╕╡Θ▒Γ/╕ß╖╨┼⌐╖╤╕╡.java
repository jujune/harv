package 클래스만들기;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class 멜론크롤링 {

	public static void main(String[] args) {
		try {
			Connection con = Jsoup.connect("https://www.melon.com/chart/index.htm");
			//멜론 코드 불러오기, con에는 연결하는 주소값이 들어가 있음
			Document doc = con.get();
//			con주소값으로 접근하여 코드 전체를 문서(document)로 가져오기 -> doc 변수로 정의
			Elements list = doc.select(".ellipsis.rank01 span a"); //.은 클래스 안에 있는 내용을 검색 . "" 안에
			Elements list2 = doc.select(".rank02 span a"); // ".클래스이름 하위태그앞글자 하위태그앞글자" 이렇게 위치 탐색
			Elements list3 = doc.select(".image_typeAll img");
			Elements list4 = doc.select(".rank03 a");

			//TOP100 노래제목, 가수, 커버 이미지, 앨범명 추출
			System.out.println(list.size());   //100 나옴!
			System.out.println(list2.size());   //100 나옴!
			System.out.println("-----------------------");
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).text());
			//<a>와 </a> 사이에 있는 텍스트 추출하여 프린트
			}
			System.out.println("-----------------------");
			System.out.println(list2);
			for (int i = 0; i < list2.size(); i++) {
				System.out.println(list2.get(i).text());
			}
			System.out.println("-----------------------");
			for (int i = 0; i < list3.size(); i++) {
				System.out.println(list3.get(i).attr("src"));
			}
			System.out.println("-----------------------");
			for (int i = 0; i < list4.size(); i++) {
				System.out.println(list4.get(i).text());
			}
		
			
		} catch (Exception e) {
		}
	}

}

package 클래스만들기;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class 멜론크롤링2 {

	public static void main(String[] args) {
		try {
			Connection con = Jsoup.connect("https://www.melon.com/chart/age/index.htm?chartType=YE&chartGenre=KPOP&chartDate=2016");
			Document doc = con.get();
			Elements list = doc.select(".rank01 span a "); //.은 클래스 안에 있는 내용을 검색 "" 안에
//			System.out.println(list.size());   //100 나옴!
			System.out.println(list);
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).text());
			}
			
		} catch (Exception e) {
		}
	}

}

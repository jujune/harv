package 클래스만들기;

import java.util.Iterator;

public class 값전달 {
	public void add(int x) { //값 전달 = call-by-value 라고 부름
		System.out.println("전달 받음 " + x);
	}
//call-by-value:
//	메소드를 호출할 때 입력값으로 기본형이 들어가는 경우  //기본형 변수 : 정수 실수 문자 부울렌
//	메모리 상으로는 기본형의 "값"이 복사됨
//call-by-reference:
//	메소드를 호출할 때 입력값으로 참조형이 들어가는 변수
//	메모리 상으로는 참조형의 "주소"가 복사됨
//	(배열인 경우 얇은 복사)
//
//add("홍길동", 1)
//	__1__  __2__ : 1(주소전달), 2(값전달) //스트링은 주소로 전달됨 //홍길동은 val ? ref?
	
	public void add(int[] x) { //주소 전달 = call-by-reference 라고 부름
		System.out.println("전달 받음 ");
		for (int a : x) {
			System.out.print(a + " ");
		}
	}
}

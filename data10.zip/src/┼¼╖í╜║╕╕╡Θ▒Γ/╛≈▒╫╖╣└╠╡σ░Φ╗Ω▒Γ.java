package 클래스만들기;

public class 업그레이드계산기 {
	public int add(int x, int y) {
		return x + y;
	}
	
	public double add(int x, double y) { //메소드 이름이 같아도 됨. int int면 위에 것이, int double이면 아래 것이 호출 됨. 파이썬은 이름 다르게 만들어야함.
		return x + y;
	}
	
	public double add(double x, double y) { //void 말고 변수 타입 지정해놓고 return 안하면 에러 발생함. 무조건 리턴해줘야함. 
		return x + y;
	}
	
	public String add(String firstName, String lastName) {
		return firstName + lastName;
	}
	public String add(String company, int field) { //하나라도 스트링이면 전체는 스트링
		return company + field;
	}
	public int[] add() { //리턴할 배열 타입을 지정
		int[] jumsu = {100, 99, 88};
		return jumsu;
	}
	
	
	
}

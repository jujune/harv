package 클래스만들기;

public class 배열의복사 {

	public static void main(String[] args) {
		int a = 100;
		int b = a;// 변수의 복사
		System.out.println("a: " + a);
		System.out.println("b: " + b);
		a = 200;
		System.out.println("--------");
		System.out.println("a: " + a);
		System.out.println("b: " + b);
		System.out.println();
		
		int[] x = {1,2,3,4,5};
		int[] y = x; //배열의 복사
		
		for (int i : x) {
			System.out.print(i + " ");
		}
		System.out.println();
	
		for (int i : y) {
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println("-----------");
		
		x[0] = 9; //배열은 변수와 달리 완전한 복사가 됨. 이는 주소값을 복사했기 때문임. = 얕은 복사
		
		for (int i : x) {
			System.out.print(i + " ");
		}
		System.out.println();
	
		for (int i : y) {
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println("-----------");
		System.out.println();
  
		
		int[] z = x.clone(); //깊은 복사
		
		x[0] = 8;
		
		for (int i : x) {
			System.out.print(i + " ");
		}
		System.out.println();
	
		for (int i : z) {
			System.out.print(i + " ");
		}
		System.out.println();
		System.out.println("-----------");
		System.out.println();
		
		System.out.println(x);
		System.out.println(y); //주소값만 가져온 얕은 복사
		System.out.println(z); //주소값이 다른걸 확인할 수 있음, 깊은 복사

		
	}

}

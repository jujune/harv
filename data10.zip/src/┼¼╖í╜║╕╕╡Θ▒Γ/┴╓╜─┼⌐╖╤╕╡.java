package 클래스만들기;

import javax.swing.JFrame;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 주식크롤링 {

	public static void main(String[] args) {
	
		try {
			Connection con = Jsoup.connect("https://finance.naver.com/sise/lastsearch2.nhn");
			Document doc = con.get();
			Elements list = doc.select("tr td a"); 

			System.out.println(list);

			
			System.out.println("-----------------------");
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).text());
			}
			
			JFrame f = new JFrame();
			f.setSize(649, 508);
			f.getContentPane().setLayout(null);
			
			JButton t0 = new JButton("국내증시 인기 검색 종목");
			t0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				
				}
			});
			t0.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
			t0.setBounds(12, 10, 281, 66);
			f.getContentPane().add(t0);
			
			JButton t1 = new JButton("");
			t1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					
				}
			});
			t1.setBounds(12, 98, 281, 50);
			f.getContentPane().add(t1);
			
			JButton t2 = new JButton("New button");
			t2.setBounds(12, 158, 281, 50);
			f.getContentPane().add(t2);
			
			
			f.setVisible(true);
			
				
			}catch (Exception e) {
			}
		
	}
}


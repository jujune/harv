package bean;

public class asd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (String i : args) {
			
		}
	}

}

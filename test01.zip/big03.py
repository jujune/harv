# 기본 입력 처리
# = 에서 오른쪽은 왼쪽이다 라고 읽어야함
# name, age는 ram의 저장공간

name = input("이름 입력: ")
age = input("나이 입력: ")
print(name, "님 환영합니다.")
print("당신의 나이는 ", age, "세")
print("name : juyeup")
print("아이디:     ", "garden");print("패스워드:  ", "1234");
print("asd")
print("나의 좌우명: ", "파이팅!!!!", end=" ")
print("그리고, " + "계속 전진!!")
print("그리고, " + "계속 전진!!")
# comment(주석)
# end=라는 속성을 주면 print하고 엔터 대신에 대체

# 기본 입력 처리
# = 에서 오른쪽은 왼쪽이다 라고 읽어야함
name = input("이름 입력: ")
age = input("나이 입력: ")
print(name, "님 환영합니다.")
print("당신의 나이는 ", age, "세")


print("hi")
print("hello")

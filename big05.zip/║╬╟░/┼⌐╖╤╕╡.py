import requests
from bs4 import BeautifulSoup

# 클래스 있는 것과 없는 것의 차이는? 객체로 쓸 수 있나? #


#class Crawling:
# requests 모듈과 bs4의 BeautifulSoup을 임포트

source = requests.get("https://search.shopping.naver.com/best100v2/main.nhn").text
# 입력한 주소에 요청을 해서 html소스들을 문자열(text)로 바꿔서 source 변수에 집어 넣음
soup = BeautifulSoup(source, "html.parser")
# 데이터를 예쁘게 가져오기 위해 BeautifulSoup을 이용. 요청해서 받은 source변수를 가지고
# BeautifulSoup에 html 소스로 파싱해야 한다고 옵션을 정하고, 파싱한 결과 값을 soup변수에 집어 넣음.

# result = soup.select("li div span em")
# print(result)

# rank
list_rank = [] #7개
for rank in range (1,8):
    result1 = soup.find_all(name="em", attrs={'class':'num%d' %rank})
    list_rank.append(result1[1].get_text())
print(list_rank)

# category
list_category = [] #9개
result2 = soup.find_all(name="img", attrs={'height':'15'})
for img in result2:
    list_category.append(img.get('alt'))
print(list_category)


# title
list_title = []
list_titles = []
for x in range (0,9):
    result3 = soup.select("#cateProductListArea5000000%d ul li p a" %x)
    for y in range (0,7):
        list_title.append(result3[y].attrs['title'])
        list_titles.append(list_title)
print(list_titles)


# price
list_price = []
list_prices = []
for x in range (0,9):
    result4 = soup.select("#cateProductListArea5000000%d strong .num" %x)
    list_price.append(result4[y].text)
    list_prices.append(list_price)
print(list_prices)


# list_test = []
# list_test.append(list_title)
# list_test.append(list_category)
# print(list_test)


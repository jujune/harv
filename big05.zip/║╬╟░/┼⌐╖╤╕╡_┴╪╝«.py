from bs4 import BeautifulSoup
import requests


class Crawling:

    def crawling(self):

        # 넘길 총 데이터
        c_date = []

        req = requests.get('https://search.shopping.naver.com/best100v2/main.nhn')
        soup = BeautifulSoup(req.content, 'html.parser')

        cate_list = list(soup.select('.h_tit img'))
        cates = []
        cate = []
        for i in cate_list:
            if 'src' in i.attrs:
                cates.append(i.attrs['alt'])
        # for w in cates:
        #     cate.append()
        # print(cate)
        c_date.append(cates)

        rank_list = list(soup.select('.best_rnk em'))
        ranks = []
        rank = []
        for j in rank_list:
            ranks.append(j.text)
        for x in range(0, len(ranks), 7):
            rank.append(ranks[x:x + 7])
        # print(rank)
        c_date.append(rank)

        title_list = list(soup.select('.goods_lst li p a'))
        titles = []
        title = []
        for k in title_list:
            if 'href' in k.attrs:
                titles.append(k.attrs['title'])
        for y in range(0, len(titles), 7):
            title.append(titles[y:y + 7])
        # print(title)
        c_date.append(title)

        price_list = list(soup.select('.goods_lst .price .num'))
        prices = []
        price = []
        for m in price_list:
            prices.append(m.text)
        for z in range(0, len(prices), 7):
            price.append(prices[z:z + 7])
        # print(price)
        c_date.append(price)

        print(c_date)
        return c_date


if __name__ == '__main__':
    crl = Crawling()
    crl.crawling()

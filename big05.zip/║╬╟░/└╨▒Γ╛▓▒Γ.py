class WR:

    # noinspection PyMethodMayBeStatic
    def writing(self, c_data):
        fi = open('best.txt', 'w')

        for i in range(0, 9):
            fi.write(c_data[0][i])
            fi.write('\n')
            for j in range(0, 7):
                fi.write(str(c_data[1][i][j]))
                fi.write('\n')
                fi.write(str(c_data[2][i][j]))
                fi.write('\n')
                fi.write(str(c_data[3][i][j]))
                fi.write('\n')
            fi.write('\n')
        fi.close()

    # noinspection PyMethodMayBeStatic
    def read(self):
        fi = open('best.txt', 'r')
        reads = fi.readlines()
        read_list = []
        print(reads)
        for i in reads:
            read_list.append(i.strip('\n'))
        a = True
        while a:
            if '' in read_list:
                read_list.remove('')
            else:
                a = False
        print(read_list)




        fi.close()

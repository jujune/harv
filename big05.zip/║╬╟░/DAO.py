import pymysql


class DAO:

    # noinspection PyMethodMayBeStatic
    def insert(self, data):
        conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='virus',
                               charset='utf8')
        try:
            with conn.cursor() as curs:
                sql = 'insert into best values (%s, %s, %s, %s)'
                curs.execute(sql, (data[0], data[1], data[2], data[3]))
                conn.commit()
        finally:
            conn.close()

    # noinspection PyMethodMayBeStatic
    def select(self):
        conn = pymysql.connect(host='localhost', port=3708, user='root', password='1234', db='virus',
                               charset='utf8')
        try:
            with conn.cursor() as curs:
                sql = 'select * from best'
                curs.execute(sql)
                result = curs.fetchall()
                return result
        finally:
            conn.close()

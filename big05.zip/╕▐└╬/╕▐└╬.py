from 부품.DAO import *
from 부품.읽기쓰기 import *
from 부품.크롤링_준석 import *
from tkinter import *


def cw():
    cr = Crawling()
    c_data = cr.crawling()
    wr = WR()
    wr.writing(c_data)


def ri():
    rd = WR()
    r_data = rd.read()
    # dao = DAO()
    # dao.insert(r_data)
    # print(r_data)


def sel():
    dao = DAO()
    dao.select()


tk = Tk()
tk.geometry('500x500')

cw_b = Button(tk, text='내려받기', font=('굴림', 20), command=cw)
ri_b = Button(tk, text='저장하기', font=('굴림', 20), command=ri)
sel_b = Button(tk, text='읽어오기', font=('굴림', 20), command=sel)

sel_ent = Entry(tk, font=('굴림', 30), state='readonly')
sel_ent.setvar()

cw_b.place(x=20, y=20)
ri_b.place(x=190, y=20)
sel_b.place(x=360, y=20)
sel_ent.place(x=20, y=100)

tk.mainloop()

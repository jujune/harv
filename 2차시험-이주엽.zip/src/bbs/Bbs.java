package bbs;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Font;

public class Bbs extends JFrame{
	private static int count = 0;
	
	public Bbs() {
		setSize(600, 357);
		getContentPane().setLayout(null);
		setVisible(true);
		
		JButton btnNewButton = new JButton("게시물 추가하기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num1 = JOptionPane.showInputDialog("게시물 번호를 입력하시오.");
				String title1 = JOptionPane.showInputDialog("게시물 제목을 입력하시오.");
				String content1 = JOptionPane.showInputDialog("게시물 내용을 입력하시오.");
				String writer1 = JOptionPane.showInputDialog("게시물 작성자를 입력하시오.");
				String team1 = JOptionPane.showInputDialog("게시물 작성자 소속을 입력하시오.");
				
				JLabel num = new JLabel("");
				num.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
				num.setBounds(12, 71, 43, 32);
				getContentPane().add(num);
				num.setText(num1);
				
				JLabel title = new JLabel("");
				title.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
				title.setBounds(55, 71, 406, 32);
				getContentPane().add(title);
				title.setText(title1);
				
				JLabel writer = new JLabel("");
				writer.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
				writer.setBounds(459, 71, 57, 32);
				getContentPane().add(writer);
				writer.setText(writer1);
				
				JLabel team = new JLabel("");
				team.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
				team.setBounds(515, 71, 57, 32);
				getContentPane().add(team);
				team.setText(team1);
				
				JTextArea textArea = new JTextArea();
				textArea.setFont(new Font("맑은 고딕", Font.PLAIN, 13));
				textArea.setBounds(12, 113, 560, 168);
				getContentPane().add(textArea);
				textArea.setText(content1);
				textArea.revalidate();
				textArea.repaint();
			}
		});
		btnNewButton.setBounds(12, 10, 560, 51);
		getContentPane().add(btnNewButton);
		
	}
	public static void main(String[] args) {
		Bbs ui = new Bbs();
	}
}

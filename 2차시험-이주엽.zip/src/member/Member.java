package member;

import java.util.Scanner;

import javax.management.StringValueExp;

public class Member {
	private String name;
	private String id;
	private String pw;
	private int bday;
	private String gender;
	private String address;
	private	String tel;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public int getBday() {
		return bday;
	}
	public void setBday(int bday) {
		this.bday = bday;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	
	@Override
	public String toString() {
		return "Member [name=" + name + ", id=" + id + ", pw=" + pw + ", bday=" + bday + ", gender=" + gender
				+ ", address=" + address + ", tel=" + tel + "]";
	}
	
	public Member() {
		Scanner sc = new Scanner(System.in);
		System.out.print ("이름을 입력하세요 ");	setName(sc.next());
		System.out.print ("아이디를 입력하세요 ");	setId(sc.next());
		System.out.print ("비밀번호를 입력하세요 ");	setPw(sc.next());
		System.out.print ("생일을 입력하세요 ");	setBday(Integer.valueOf((sc.next())));
		System.out.print ("성별을 입력하세요 ");	setGender(sc.next());
		System.out.print ("주소를 입력하세요 ");	setAddress(sc.next());
		System.out.print ("전화번호를 입력하세요 ");	setTel(String.valueOf((sc.next())));
		
	}
	
	public Member(String name, String id, String pw, int bday, String gender, String address, String tel) {
		setName(name);
		setId(id);
		setPw(pw);
		setBday(bday);
		setGender(gender);
		setAddress(address);
		setTel(tel);
		
		System.out.println(getName());
		System.out.println(getId());
		System.out.println(getPw());
		System.out.println(getBday());
		System.out.println(getGender());
		System.out.println(getAddress());
		System.out.println(getTel());
		
	}
	
}

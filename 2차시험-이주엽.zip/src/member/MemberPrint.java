package member;

public class MemberPrint {

	public static void main(String[] args) {
		Member dto = new Member();
		System.out.println(dto);
		Member dto2 = new Member();
		System.out.println(dto);
		
		
		String name = "이주엽";
		String id = "ljy";
		String pw = "qwer";
		int bday = 910604;
		String gender = "man";
		String address = "Gunpo-si";
		String tel = "010-2905-3180";
		
		Member dto3 = new Member(name, id, pw, bday, gender, address, tel);
		System.out.println(dto2);
	}

}

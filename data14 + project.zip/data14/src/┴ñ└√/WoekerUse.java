package 정적;

public class WoekerUse {

	public static void main(String[] args) {
		Worker w1 = new Worker("임아무개", '남', 24);
		Worker w2 = new Worker("김아무개", '여', 23);
		Worker w3 = new Worker("박아무개", '남', 25);
		
		System.out.println("전체 직원 수는 " + Worker.count_worker);
		System.out.println("전체 평균 나이는 " + Worker.count_age/Worker.count_worker);
		System.out.println("첫번째 직원의 이름은 " + w1.name);
	}

}

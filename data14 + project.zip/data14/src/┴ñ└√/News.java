package 정적;

import javax.swing.JOptionPane;

public class News {

	public void news() {
		JOptionPane.showMessageDialog(null,"뉴스: " + LoginCheck.logId + "님 환영합니다");
		
		
		
	}

}

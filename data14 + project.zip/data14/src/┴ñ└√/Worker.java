package 정적;

public class Worker {
	String name;
	char gender;
	int age;
	static int count_age;
	static int count_worker;
	
	public Worker(String name, char gender, int age) {
		this.name = name;
		this.gender = gender;
		this.age = age;
		count_age = count_age + age;
		count_worker++;
	}
	
	
	
	
}

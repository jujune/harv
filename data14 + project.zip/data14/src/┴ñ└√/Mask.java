package 정적;import java.io.ObjectInputStream.GetField;

public class Mask {
	//인스턴스 변수 // ; 객체가 생성되어야만 쓸 수 있음
	String color;
	int price;
	int count;
	
	static int total; //마스크 객체 생성 개수 // ; 객체 생성하지 않아도 사용 가능
	static final String COMPANY = "웰킵스"; //절대 못바꾸는 변수로 지정. 두둥 
	//상수 표현은 일반적으로 대문자. 꼭 그래야 하는건 아님
	
	public static int getTotal() {
		return total;
		//static메소드를 사용하는 경우, 멤버변수는 static 변수여야 한다.
		//객체 생성과 상관없이 접근하는 메소드와 멤버변수를 사용해야함.
	}
	
//	public static int getTotal() { // <--- 불가능!!!!!
//		return count;
//	//인스턴스 변수는 객체 생성 후 주소로만 접근 가능
//	}

	
	public Mask() {
		
	}
	
	public Mask(String color, int price, int count) {
		this.color = color;
		this.price = price;
		this.count = count;
		total++;
	}

	//전체 멤버변수 값 출력
	@Override
	public String toString() {
		return "Mask [color=" + color + ", price=" + price + ", count=" + count + "]";
	}
	
	
	
}

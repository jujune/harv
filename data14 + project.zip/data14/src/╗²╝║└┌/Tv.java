package 생성자;

public class Tv {
	String color; //null
	int size; //0

	//default(기본 생성자)
	//파라메터를 가진 생성자가 없는 경우는 자동으로 만들어줌.
	//파라메터를 가진 생성자가 있는 경우는 자동으로 만들어주지 않음.
	
	
	
	public Tv() {
	}
	//source-> Generate Constructor using fields로 생성자 만들 수 있음
	

	//생성자 : 객체 생성시 자동 호출되는 메소드
	
	//파라메터 생성자
	//멤버변수 초기화  // 첫값(빨강,50) 넣어주는 것을 초기화라고 부름
	public Tv(String color, int size) {//생성자는 무조건 void다. 반환값이 없음. 
		//메소드에 입력값을 넣어주고 싶을때 생성자 사용 //생성자를 만들면 무조건 입력값을 요구하게 됨.
		System.out.println("클래스 이름과 동일한 내가 호출됨");
		this.color = color; //컬러를 입력값 컬러로
		//color = color 할 경우 메소드와 가까운 지역변수를 인식하기 때문에, 전역변수인 color를 가져오려면 this사용
		this.size = size; //사이즈를 입력값 size로
	}
	
	//Tv로 생성된 객체의 멤버변수 값 프린트 
	@Override //생성된 객체를  sysout하면 
	public String toString() { //일일이 출력해도 되지만 귀찮으니까. DTO에도 만들어두면 편하다.
		return "Tv [color=" + color + ", size=" + size + "]";
	
	
	}

	
	
}

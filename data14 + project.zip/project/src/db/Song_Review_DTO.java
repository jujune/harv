package db;

public class Song_Review_DTO {
	String nick_name;
	String date;
	String content;
	String album_id;

	
	
	

	

}

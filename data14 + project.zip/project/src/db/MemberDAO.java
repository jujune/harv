package db;

public class MemberDAO {
	String url = "jdbc:mysql://localhost:3708/project";
	String user = "root";
	String password = "1234";
	
public void name() {
	

}
	
	
	

}

package db;

public class Item_Info_DTO {
	String nick_name;
	String date;
	String content;
	String album_id;

	
	
	

	

}

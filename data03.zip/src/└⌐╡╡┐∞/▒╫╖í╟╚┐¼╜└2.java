package ������;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class �׷��ȿ���2 {

	public static void main(String[] args) {
		//1, �����ӿ� �ش��Ѵ� Ŭ���� �ʿ�
		JFrame f = new JFrame();
		f.setSize(695, 547);
		f.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(31, 57, 119, 54);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.setBounds(171, 57, 119, 54);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("New button");
		btnNewButton_1_1.setBounds(318, 57, 119, 54);
		f.getContentPane().add(btnNewButton_1_1);
		
		
		
	
		
		f.setVisible(true);
	}
}

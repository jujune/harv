package ������;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class �׷��ȿ��� {

	public static void main(String[] args) {
		//1, �����ӿ� �ش��Ѵ� Ŭ���� �ʿ�
		JFrame f = new JFrame();
		f.setSize(500, 500);
		
		JButton btnNewButton = new JButton("\uB098\uB97C \uB20C\uB7EC\uC694");
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("���� ����", Font.ITALIC, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		f.getContentPane().add(btnNewButton, BorderLayout.CENTER);
		
		JButton btnNewButton_1 = new JButton("\uB098\uB294 \uC704\uC5D0 \uC788\uB294 \uBC84\uD2BC");
		btnNewButton_1.setBackground(Color.ORANGE);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("���� ����", Font.ITALIC, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		f.getContentPane().add(btnNewButton_1, BorderLayout.NORTH);
		
		JButton btnNewButton_2 = new JButton("\uB098\uB294 \uC67C\uCABD \uBC9D\uC774\uC57C");
		btnNewButton_2.setBackground(Color.ORANGE);
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("���� ����", Font.ITALIC, 15));
		f.getContentPane().add(btnNewButton_2, BorderLayout.WEST);
		
		JButton btnNewButton_3 = new JButton("\uB098\uB294 \uC624\uB978\uCABD \uBC9D\uC774\uC57C");
		btnNewButton_3.setBackground(Color.ORANGE);
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("���� ����", Font.ITALIC, 15));
		f.getContentPane().add(btnNewButton_3, BorderLayout.EAST);
		
		JButton btnNewButton_4 = new JButton("Bottom button");
		btnNewButton_4.setBackground(Color.ORANGE);
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setFont(new Font("���� ����", Font.ITALIC, 15));
		f.getContentPane().add(btnNewButton_4, BorderLayout.SOUTH);
		
		
	
		
		f.setVisible(true);
	}

}

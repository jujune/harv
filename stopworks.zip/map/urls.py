from django.contrib import admin
from django.urls import path, include

from map.views import MapDetail

urlpatterns = [
    path('detail/<int:pk>', MapDetail.as_view(), name="detail1")
]

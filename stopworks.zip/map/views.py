from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy, reverse
from django.views.generic import DetailView, DeleteView, UpdateView, CreateView, ListView

from map.models import Map


class MapDetail(DetailView):
    model = Map
    template_name_suffix = '_detail1'

class MapDelete(DeleteView):
    model = Map
    template_name_suffix = '_delete1'
    success_url = reverse_lazy('list1')

class MapUpdate(UpdateView):
    model = Map
    fields = ['store', 'address']
    template_name_suffix = '_update1'
    success_url = reverse_lazy('list1')

class MapCreate(CreateView):
    model = Map
    fields = ['store', 'address']
    template_name_field = '_create1'
    success_url = reverse_lazy('list1')

class MapList(ListView):
    model = Map
    template_name_suffix = '_list1'

def main(request):
    return render(request, "../templates/main.html")

from django.db import models

# Create your models here.
from django.urls import reverse


class Map(models.Model):
    store = models.CharField(max_length=100)
    address = models.CharField(max_length=100)

    def __str__(self):
        return "스토어 명 : " + self.store + " / 주소 : " + self.address

        # models.py에서 model을 소환하면 실행됨. success_url을 설정 안해주면 이걸로 기본 넘어감.
    def get_absolute_url(self): # id가 있나? db의 id값인가....
        return reverse('detail1', args=[str(self.id)]) # 파라메터 유무에 따라서 reverse를 쓸 수도, render를 쓸 수도 있음.
                                 # detail/<int:pk>의 int값이 parameter인 셈?

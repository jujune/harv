from django.db import models

# Create your models here.
from member.models import Member

class Payment(models.Model):
    m_id = models.ForeignKey(Member, on_delete=models.CASCADE)
    p_method = models.CharField(max_length=100, null=False)
    totalprice = models.IntegerField(null=False)
    menulist = models.CharField(max_length=100, null=False)
    today = models.CharField(max_length=100, null=False)

class Prepaid(models.Model):
    m_id = models.ForeignKey(Member, on_delete=models.CASCADE)
    card_name = models.CharField(max_length=100, null=False)
    balance = models.IntegerField(null=False)
    card_num = models.IntegerField(primary_key=True, null=False)
    pin = models.IntegerField(null=False)
from django.urls import path

from map.views import MapDetail

urlpattern = [

]
from django.db import models

# Create your models here.
class Member(models.Model):
    id = models.CharField(max_length=100, primary_key=True)
    pw = models.CharField(max_length=100, null=False)
    name = models.CharField(max_length=100, null=False)
    tel = models.CharField(max_length=100, null=False)
    e_mail = models.CharField(max_length=100, null=False)
    e_coupon = models.CharField(max_length=100, null=True)

    def __str__(self):
        return '아이디= ' + self.id + ' / 비밀번호= ' + self.pw + ' / 이름= ' + self.name + \
               ' / 전화번호= ' + self.tel + ' / 이메일= ' + self.e_mail + ' / 쿠폰= ' + self.e_coupon
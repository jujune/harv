package bean;

public class chosunDTO {

	private String title;
	private String author;
	private String pubdate;
	
	
	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getPubdate() {
		return pubdate;
	}


	public void setPubdate(String pubdate) {
		this.pubdate = pubdate;
	}


	@Override
	public String toString() {
		return "chosunDTO [title=" + title + ", author=" + author + ", pubdate=" + pubdate + "]";
	}

	
}

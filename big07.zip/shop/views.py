from django.http import HttpResponse
from django.shortcuts import render

def buy(request):
    return HttpResponse('샀다 bought')

def sell(request):
    return HttpResponse('팔았다 sold')
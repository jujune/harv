movies = ['정직한 후보', '작은 아씨들', '클로젯', '기생충', '슈퍼소닉']
# 리스트에 있는 변수들 확인하기

#for-each문 : movies에서 1 데이터가 있니 2 있니 해서 돌면서 뽑아옴
for data in movies:
    print(data)

for index in range(0,len(movies)): # for문 : 이 안에 있는 범위에 값이 있나 있으면 돌아
    print(movies[index])

print(movies) #리스트, 딕셔너리 등과 같은 collection계열 내용 확인

file = open('movie.txt', 'w') #강물(stream, 스트림)을 연다 # r; read, w;write, rw; read and write
# finance.naver.com site로 연결
# 사이트, 네트워크, db, file 연결 등 외부 자원을 연결 => stream을 만들어야 한다.

file.write('내용이 들어갑니다')
for data2 in movies:
    file.write(data2 + '\n')


#Process finished with exit code 0 =>  아무 문제 없이 실행됨
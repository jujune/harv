star = []
vote = []

print('인기투표 시스템입니다.')
print('----------------------------')

for _ in range(0,4):
    data = input('인기투표 대상자 입력>> ')
    star.append(data)
    vote.append(0)

print(star)

for x in range(0,7):
    data2 = input('인기투표 시작>> ')
    if data2 in star:
        index = star.index(data2)
        vote[index] = vote[index] + 1
print('----------------------------')


print(star)
print(vote)


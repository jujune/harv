from tkinter import *

window = Tk()
window.geometry('500x800')
window.configure(bg='white')

def insert():
    # 입력한 값 가지고 오기
    id = id_text.get()
    pw = pw_text.get()
    name = name_text.get()
    tel = tel_text.get()

    print('당신이 넣은 데이터 확인============')
    print('당신이 입력한 id: ', id)
    print('당신이 입력한 pw: ', pw)
    print('당신이 입력한 id: ', name)
    print('당신이 입력한 id: ', tel)

    # 가지고 온 값 파일을 생성해서 저장

    file = open(id + ' account' + '.txt', 'w')
    file.write(id + '\n')
    file.write(pw + '\n')
    file.write(name + '\n')
    file.write(tel + '\n')
    file.close() #stream을 닫아주어야 한다

    print('회원가입이 완료되었습니다.')


logo = PhotoImage(file='naver_logo.png')
label = Label(window, image = logo)
label.pack()

id_label = Label(window,
           text='아이디 입력',
           font=('맑은 고딕', 30),
           bg='white',
           fg='blue'
           )
id_label.pack()
id_text = Entry(window,
                font=('맑은 고딕', 30),
                bg='yellow',
                fg='red',
                )
id_text.pack()

pw_label = Label(window,
           text='패스워드 입력',
           font=('맑은 고딕', 30),
           bg='white',
           fg='blue'
           )
pw_label.pack()
pw_text = Entry(window,
                font=('맑은 고딕', 30),
                bg='yellow',
                fg='red',
                )
pw_text.pack()

name_label = Label(window,
           text='이름 입력',
           font=('맑은 고딕', 30),
           bg='white',
           fg='blue'
           )
name_label.pack()
name_text = Entry(window,
                font=('맑은 고딕', 30),
                bg='yellow',
                fg='red',
                )
name_text.pack()


tel_label = Label(window,
           text='전화번호 입력',
           font=('맑은 고딕', 30),
           bg='white',
           fg='blue'
           )
tel_label.pack()
tel_text = Entry(window,
                font=('맑은 고딕', 30),
                bg='yellow',
                fg='red',
                )
tel_text.pack()

icon = PhotoImage(file='naver.png')
button = Button(window, image=icon, command=insert)
button.pack()

window.mainloop()
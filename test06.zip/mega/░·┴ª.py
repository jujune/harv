from tkinter import *

# 1
def subject():
    subject = []
    for _ in range(0, 4):
        sub = input('배우고 싶은 과목 입력>>')
        subject.append(sub)
    print(subject)

# 2
def plus():
    original = [50, 40, 30, 20]
    plus = []
    for x in range(0,4):
        data = original[x] + 10
        plus.append(data)
    print(plus)

# 3
def hongbo():
    items = ['광고', '마케팅', '그로스해킹']
    file = open('hongbo.txt', 'w')
    for data in items:
        file.write(data + '\n')
    file.close()

    file2 = open('hongbo.txt', 'r')
    for index in range(0,3):
        data = file2.readline()
        data2 = data.strip()
        print(data2, end=" ")
    file2.close()

# 4
def zzang():
    file = open('hongbo.txt', 'r')
    for x in range(0,3):
        data = file.readline()
        data2 = data.strip()
        print(data2, end="짱 ")
    file.close()


# 5
def product1():
    product = ['노트북', '갤럭시탭', '휴대폰']
    price = [150, 130, 120]
    for index in range(0,3):
        print(product[index] + '은 ' + str(price[index]) + '만원 입니다.')

    file = open('product.txt', 'w')
    for data in product:
        file.write(data + '\n')
    file.close()
    file2 = open('last_price.txt', 'w')
    for data in price:
        file2.write(str(data) + '\n')
    file2.close()

    print('----------------------------------------')

    file3 = open('product.txt', 'r')
    file4 = open('last_price.txt', 'r')
    for _ in range(0,len(product)):
        data = file3.readline().strip()
        data2 = file4.readline().strip()
        print(data + '은 ' + str(int(data2)+10) + '만원 입니다.')
    file3.close()
    file4.close()


w = Tk()
w.geometry('300x500')
w.configure(bg='black')
button = Button(w, text='SUBJECT', font=('맑은 고딕',30), bg='white', fg='black', command=subject)
button.pack()
button1 = Button(w, text='PLUS+', font=('맑은 고딕',30), bg='white', fg='black', command=plus)
button1.pack()
button2 = Button(w, text='HONGBO', font=('맑은 고딕',30), bg='white', fg='black', command=hongbo)
button2.pack()
button3 = Button(w, text='ZZANG', font=('맑은 고딕',30), bg='white', fg='black', command=zzang)
button3.pack()
button4 = Button(w, text='PRODUCT', font=('맑은 고딕',30), bg='white', fg='black', command=product1)
button4.pack()

w.mainloop()
from tkinter import *

win = Tk()
win.geometry('500x600')
win.configure(bg='pink')

def file_write():
    fruit = ['사과', '바나나', '배']
    # 파일에 저장

def file_read():
    print()
    # 파일에 저장했던 것 읽어서 프린트
    pass # 파이썬은 def에서 아무것도 없을 때 pass안하면 에러남

in_label = Label(win, text="원하는 과일을 입력해주세요", font=("맑은 고딕", 30), bg='white', fg='pink')
in_label.pack()
in_text = Entry(win, font=("맑은 고딕", 30), bg='white', fg='pink')
in_text.pack()

button = Button(win, text='저ㄱ장ㄴ', font=('맑은 고딕', 20))
button.pack()

win.mainloop()
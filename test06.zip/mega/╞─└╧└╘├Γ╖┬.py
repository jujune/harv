from tkinter import *

def file_write(): # 함수는 보통 맨 위에 만듦
    print('파일에 쓰기 호출')
    fruit = ['바나나', '사과', '메론']
    # 파일을 저장하기 위해서는 저장용 스트림을 만들어야 한다.
    file = open('fruit.txt', 'w')

    #리스트를 읽어서 파일에 한 줄씩 저장
    for data in fruit:
        file.write(data + '\n')
    file.close

def file_read():
    print('파일에 읽기 호출')
    # 파일을 읽기 위해서는 읽기 전용 stream을 만들어야한다.
    # 자동완성: Ctrl + Spacebar
    file2 = open('fruit.txt', 'r')
    for index in range(0,3):
        data = file2.readline()
        data2 = data.strip()
        print(data2, end=" ")
    file2.close

w = Tk() #프레임을 만들어주는 함수
w.geometry('300x150')
w.configure(bg='pink')
write = Button(w, text="파일에 저장", bg='white', fg='black', font=('궁서', 30), command=file_write)
# 이것은 참조형 변수.
# 변수의 종류
# - 기본형 변수 : 숫자, 문자열, 논리(bool). 그 해당 '값'이 변수에 저장
# - 참조형 변수 : 나머지 전부 (리스트, 부품(class), 객체), 주소가 변수에 저장, name=['홍길동', '박길동']
write.pack()
read = Button(w, text="파일에 쓰기", bg='white', fg='black', font=('궁서', 30), command=file_read)
read.pack()


w.mainloop()

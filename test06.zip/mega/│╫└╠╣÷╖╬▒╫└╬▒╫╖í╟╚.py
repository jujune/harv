from tkinter import * # * 다 import시켜버려!
from tkinter.messagebox import *

# 자동 import = alt + Enter #ctrl #ctrl + d 한 줄 삭제


#함수 = function(기능)
def login2(): #특정한 객체(부품)에 함수를 연결(bind)
    print('login2함수 호출됨')
    # 1. 입력한 id, pw를 가지고 온다.
    id = id_text.get()
    pw = pw_text.get()

    # 2. 입력한 id에 해당하는 파일을 읽기 전용으로 스트림을 만든다.
    file_name = id + ' account' + '.txt'
    file = open(file_name, 'r')

    # 3. 파일에서 id, pw를 차례대로 읽어온다.
    id_saved = file.readline()
    pw_saved = file.readline()
    #    스트림을 닫아줌
    file.close()

    # 4. 읽어온 후, 비교하기 전에 데이터에 문제가 있으면 미리 처리해 줄 것. (전처리 pre-processing)

    id_saved2 = id_saved.strip()
    pw_saved2 = pw_saved.strip()
    print(len(id_saved), ' ', len(id_saved2)) # 스트립(필요 없는 빈칸, 엔터 잘라내기) 확인


    # 5. 비교 처리하여 결과 출력
    if (id == id_saved2 and pw == pw_saved2):
        showinfo('로그인 결과', 'Logged In')
    else:
        showinfo('로그인 결과', 'Login failed')


def login():
    print('login함수 호출됨.')
    id = id_text.get() #get/set
    pw = pw_text.get()
    if (id == 'root' and pw =='1234'):
        showinfo('로그인 결과', 'Logged In')
    else:
        showinfo('로그인 결과', 'Cannot login')

w = Tk() # 입력창 열어줌. 객체지향의 부품을 만들때 쓰는 명령은 Tk 대문자로 시작?한다.
w.geometry('500x400') #부품을 쓸때는 사용 설명서를 보듯이 써야함. 다 다름. 가로x세로 크기
w.configure(bg='lime') #background  #configure:(컴퓨터의) 환경을 설정하다
id_label = Label(w,
                 text='사용자 ID입력',
                 font=('맑은 고딕', 30),
                 bg='lime',
                 fg='blue' #foreground
                 )
id_label.pack() #pack:알아서 가운데 들어가라 #라벨을 다 만들고 난 후에 pack함수를 써야함

id_text = Entry(w,
                font=('맑은 고딕', 30),
                bg='yellow',
                fg='red'
                )
id_text.pack()

pw_label = Label(w,
                 text='사용자 PW입력',
                 font=('맑은 고딕', 30),
                 bg='lime',
                 fg='blue'
                 )
pw_label.pack()

pw_text = Entry(w,
                font=('맑은 고딕', 30),
                bg='yellow',
                fg='red'
                )
pw_text.pack()


# button = Button(w, text = 'me')
# 이미지로 부품화(객체화)시켜줌
icon = PhotoImage(file='naver.png')
button = Button(w, image = icon, command=login2)
button.pack()

w.mainloop() #요 안에 들어있는게 계속 떠있으렴 -> 그래서 맨 끝으로 간다?

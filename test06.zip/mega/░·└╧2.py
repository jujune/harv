fruit2 = []

# 5개의 파일을 입력 받아서, 리스트에 넣고
# 리스트의 내용을 프린트

for _ in range(0,5):
    data = input('과일 입력>> ')
    fruit2.append(data)

for index in range(0,5):
    print(fruit2[index], end=' ')


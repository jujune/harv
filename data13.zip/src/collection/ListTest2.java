package collection;

import java.util.ArrayList;

public class ListTest2 {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("김연아");
		list.add("송연아");
		list.add("정연아");
		System.out.println(list.get(0)); //DB가 아니면 모든 인덱스는 0번 부터 시작한다.
		System.out.println(list.get(2));
		System.out.println(list.size()); //배열은 .length arraylist는 .size사용
		
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));	
		}
		for (int i = 0; i < list.size(); i++) {
			System.out.println(i+1 + "등 : " + list.get(i));
		}
		
		list.remove(1);
		System.out.println(list); //삭제하고 인덱싱이 바뀌는 것이 배열과의 차이점
		list.set(1, "정연우"); //11번 변수를 바꿈
		System.out.println(list);
		list.add(1, "박연우"); //1번 이전(앞에) add
		System.out.println(list);
		
		
	}

}

package collection;

import java.util.ArrayList;

public class ListTest4 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>(); //<E> 엘리먼트.
		//리스트의 엘리먼트를 지정해주면,리스트에 변수를 넣고 빼는 과정에서 변수 형태가 지정되어 있기 때문에 프로세스를 간략히 할 수 있음. object분류과정 생략?
		
		list.add("홍길동");
		list.add("박길동");
		list.add("정길동");
		String name = list.get(0);
//		String name = (String)list.get(0); 엘리먼트 지정 안해주면 이렇게 써야함
		System.out.println(name);
		
	}

}

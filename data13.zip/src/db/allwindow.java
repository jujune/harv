package db;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.mysql.fabric.xmlrpc.base.Member;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class allwindow {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(29, 106, 421, 287);
		f.getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("전체 목록 가지고 오기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MemberDAO dao = new MemberDAO();
				ArrayList<MemberDTO> list = dao.all();
				System.out.println("목록의 갯수는  " + list.size());
				for (int i = 0; i < list.size(); i++) {
					MemberDTO dto = list.get(i);
					textArea.append(dto.getId() + " " + 
									dto.getPw() + " " +
									dto.getName() + " " +
									dto.getTel() + "\n");
					
				}
			}
		});
		btnNewButton.setBounds(29, 25, 421, 62);
		f.getContentPane().add(btnNewButton);
		
		
		
		f.setVisible(true);
		
		
	}
}

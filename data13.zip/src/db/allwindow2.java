package db;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.mysql.fabric.xmlrpc.base.Member;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTable;
import java.awt.Color;

public class allwindow2 {
	private static JTable table;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("전체 목록 가지고 오기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MemberDAO dao = new MemberDAO();
				ArrayList<MemberDTO> list = dao.all(); //메소드를 사용하려면 호출해야함.
				System.out.println("목록의 갯수는 " + list.size());
				Object[] title = {"id","pw","name","tel"};
				Object[][] contents = new Object[list.size()][]; 
				for (int i = 0; i < list.size(); i++) {
					MemberDTO dto = list.get(i); // 주는걸 받아서 그대로 쓰는 경우는 단순 '변수형태 + 변수명' 지정
					Object[] row = new Object[4];
					row[0] = dto.getId();
					row[1] = dto.getPw();
					row[2] = dto.getName();
					row[3] = dto.getTel();
					contents[i] = row;
				}
				
				table = new JTable(contents, title);
				table.setBackground(Color.YELLOW);
				table.setBounds(29, 130, 421, 254);
				f.getContentPane().add(table);
				f.setVisible(true);
				
				
			}
		});
		btnNewButton.setBounds(29, 25, 421, 62);
		f.getContentPane().add(btnNewButton);
		
		
		f.setVisible(true);
		
		
	}
}

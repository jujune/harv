package bean;

public class Main {

	public static void main(String[] args) {
		ConManager m = ConManager.getInstance(); //ConManager객체 생성을 getInstance를 거쳐야만 되게함..?
		System.out.println("주소는: " + m); //bean.ConManager@15db9742 (static으로 만들어둔 con 주소값)
		System.out.println(m.getElement(2));
	}
}

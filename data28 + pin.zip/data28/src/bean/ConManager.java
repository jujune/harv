package bean;

import java.util.ArrayList;

public class ConManager {
	static ArrayList<String> list = null; 
	static ConManager con = null; //bean.ConManager@15db9742 (static으로 만들어둔 con 주소값)
	
	
	private ConManager() { //ctrl+space로 생성자 만들기 -> //밖에서 객체 생성 할 수 없게 private으로 막음
		list = new ArrayList<String>();
		list.add("admin");
		list.add("root");
		list.add("manager");
	}
	
	public static ConManager getInstance() {
		if(con == null)	{ 
			con = new ConManager();
		}
		return con;
	}
	
	public String getElement(int i) {
		return list.get(i);
	}
}

package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class BbsDAO {
	String url = "jdbc:mysql://localhost:3708/virus";
	String user = "root";
	String password = "1234";

	public ArrayList<BbsDTO> list() { //리턴시켜주기 위한 앞의 MemberDTO
		ArrayList<BbsDTO> list = new ArrayList<>();
		BbsDTO dto2 = null; // try를 벗어나면 무용지물이라 밖에 만들어줌. 주소값으로서의 MemberDTO dto2. 아직 선언을 안해서 그저 클래스, 변수명 이름일 뿐. null.
		try {
			//1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");
			
			//2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");
			
			//3) sql문 결정
			
			String sql = "select * from bbs";
			PreparedStatement ps = con.prepareStatement(sql);
			System.out.println("3. sql문 결정 ok..");
			
			//4) sql문 전송
			ResultSet rs = ps.executeQuery(); 
			System.out.println("4. sql문 전송 ok..");
			
			while (rs.next()) { //검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				dto2 = new BbsDTO();
				int no = rs.getInt(1);
				String title = rs.getString(2);
				String content = rs.getString(3);
				String writer = rs.getString(4);
				dto2.setNo(no);
				dto2.setTitle(title);
				dto2.setContent(content);
				dto2.setWriter(writer);
				list.add(dto2);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//4.검색을 할 예정. 
		public BbsDTO select(BbsDTO dto) { //리턴시켜주기 위한 앞의 MemberDTO
			BbsDTO dto2 = null; // try를 벗어나면 무용지물이라 밖에 만들어줌. 주소값으로서의 MemberDTO dto2. 아직 선언을 안해서 그저 클래스, 변수명 이름일 뿐. null.
			try {
				//1) 커넥터 설정
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("1. 커넥터 설정 ok..");
				
				//2) db연결
				Connection con = DriverManager.getConnection(url, user, password);
				System.out.println("2. db연결 ok..");
				
				//3) sql문 결정
				
				String sql = "select * from bbs where no = ?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setInt(1, dto.getNo());
				System.out.println("3. sql문 결정 ok..");
				
				//4) sql문 전송
				ResultSet rs = ps.executeQuery(); 
				System.out.println("4. sql문 전송 ok..");
				
				if(rs.next()) { //검색 결과가 있는지 체크해주는 메서드
					System.out.println("검색 결과가 있어요.!!");
					dto2 = new BbsDTO();
					int no = rs.getInt(1);
					String title = rs.getString(2);
					String content = rs.getString(3);
					String writer = rs.getString(4);
					dto2.setNo(no);
					dto2.setTitle(title);
					dto2.setContent(content);
					dto2.setWriter(writer);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return dto2;
		}
	
	public int idOver(MemberDTO dto) { //id중복체크!
		int result = 0; //없을 때
		MemberDTO dto2 = null;			
		try {
			//1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");
			
			//2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");
			
			//3) sql문 결정
			String sql = "select id from member where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, dto.getId());
			System.out.println("3. sql문 결정 ok..");
			
			//4) sql문 전송
			ResultSet rs = ps.executeQuery();
			System.out.println("4. sql문 전송 ok..");
			
			if(rs.next()) { //검색 결과가 있는지 체크해주는 메서드
				System.out.println("검색 결과가 있어요.!!");
				result = 1;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	//4.검색을 할 예정. 
		public int idCheck(MemberDTO dto) {
			int result = 0;
			MemberDTO dto2 = null;			
			try {
				//1) 커넥터 설정
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("1. 커넥터 설정 ok..");
				
				//2) db연결
				Connection con = DriverManager.getConnection(url, user, password);
				System.out.println("2. db연결 ok..");
				
				//3) sql문 결정
				String sql = "select * from member where id = ? and pw = ?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, dto.getId());
				ps.setString(2, dto.getPw());
				System.out.println("3. sql문 결정 ok..");
				
				//4) sql문 전송
				ResultSet rs = ps.executeQuery();
				System.out.println("4. sql문 전송 ok..");
				
				if(rs.next()) { //검색 결과가 있는지 체크해주는 메서드
					System.out.println("검색 결과가 있어요.!!");
					result = 1;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}
	
	public void update() {
		System.out.println("회원수정 처리하다.");
		try {
			//1) 커넥터 설정
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok..");
			
			//2) db연결
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok..");
			
			//3) sql문 결정
			String id = JOptionPane.showInputDialog("삽입할 id입력");
			String tel = JOptionPane.showInputDialog("삽입할 tel입력");
			
			String sql = "update member set tel = ? where id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, tel);
			ps.setString(2, id);

			
			//4) sql문 전송
			ps.executeUpdate();
			System.out.println("4. sql문 전송 ok..");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
}

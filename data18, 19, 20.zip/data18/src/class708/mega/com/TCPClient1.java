package class708.mega.com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class TCPClient1 {

	public static void main(String[] args) throws Exception { //IOException ; 들어고 나가는거 다 잡는..
		//1. 전화기로 전화를 걸어보자!
		Socket socket = new Socket("localhost", 9100);
		System.out.println("client1 : TCP서버와 연결 성공");
//		InputStreamReader is = new InputStreamReader();
		//임시 저장공간에 모든 문자를 다 집어넣어놨다가 한줄씩 처리하는 것이 편리하다.
		BufferedReader buffer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		String result = buffer.readLine();
		System.out.println("받은 데이터: " + result);
		socket.close();
	}

}

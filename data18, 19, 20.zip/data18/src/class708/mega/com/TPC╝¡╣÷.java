package class708.mega.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class TPC서버 {

	public static void main(String[] args) throws Exception { //통신할 때는 exception 있어야함 (외부자원 사용)
		//1.승인만 하는 소켓이 있어야 한다.
		ServerSocket server = new ServerSocket(9100);
		System.out.println("TCP서버 소켓 시작됨");
		System.out.println("클라이언트의 연결을 기다리는 중...");
		int i = 0; //클라이언트 수. 지역변수라서 자동 초기화가 되지 않아서 int i; 로 쓰면 안됨.
		while (true) {
			//2.승인이 떨어지면, 통신할 수 있는 별도의 소켓 객체 생성
			Socket socket = server.accept();
			System.out.println("port: " + socket.getPort());
			// ip를 가지고 와서, 
			// 210.125.88.130으로부터 연결 요청이 들어왔습니다.
			InetAddress ip = socket.getInetAddress();
			System.out.println(ip + "으로 부터 연결 요청이 들어왔음");
			String ip2 = ip.toString();
			System.out.println("클라이언트와 연결 성공!");
			System.out.println("연결된 client수: " + ++i); //++을 앞에 써주면 먼저 더한 다음에 프린트하게 한다. 뒤에 붙이는건 가장 나중에 수행.
			if (ip2.equals("/127.0.0.1")) {
				System.out.println("내 자리입니다.");
				String data = "I am a java programmer!!!";
				PrintWriter print = new PrintWriter(socket.getOutputStream(), true);
				print.print(data); //줄단위로 읽어오기 때문에 print 말고 println으로 해야함.
				System.out.print("전송 완료.");
			} else {
				System.out.println("외부에서는 전송을 할 수 없음");
				socket.close();
			}
		}
		
		
		
	}

}

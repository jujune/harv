package class708.mega.com;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class MessengerA extends JFrame {
	private JTextField input;
	JTextArea list;
	DatagramSocket socket; 
	
	public MessengerA( ) throws Exception {
		socket = new DatagramSocket(6600); //받는 소캣
		setTitle("메신저 A");
		setSize(430, 600);
		
		
		list = new JTextArea();
		list.setEditable(false);
		list.setBackground(Color.ORANGE);
		list.setForeground(Color.WHITE);
		list.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		getContentPane().add(list, BorderLayout.CENTER);
		
		input = new JTextField();
		input.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String data = input.getText();
				System.out.println("입력데이터: " + data);
				list.append("나>> " + data + "\n");
				input.setText("");
				
				//보내자
				try {
					DatagramSocket socket = new DatagramSocket(); //선언 또 필요한가?
					byte[] data2 = data.getBytes();
					InetAddress ip = InetAddress.getByName("192.168.1.179"); //상대방 ip를 입력
					
					DatagramPacket packet = new DatagramPacket(data2, data2.length, ip, 9000); //보내는 패킷
					socket.send(packet);
					System.out.println("전송 완료");
					socket.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		input.setBackground(new Color(102, 51, 0));
		input.setForeground(Color.WHITE);
		input.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		getContentPane().add(input, BorderLayout.SOUTH);
		input.setColumns(10);
		setVisible(true);
	}
	
	public void process() {
		while (true) {
			try {
//				socket = new DatagramSocket(5000); //받는 소켓
				byte[] buf = new byte[256];
				DatagramPacket packet = new DatagramPacket(buf, buf.length); 
				socket.receive(packet);
				System.out.println("데이터 받음");
				list.append("너>>" + new String(buf));
			} catch (Exception e) {
				e.printStackTrace();
			} 
			
		}
	}
	
	public static void main(String[] args) throws Exception {
		MessengerA m = new MessengerA();
		m.process(); // 보내기 전에 받을 준비를 먼저 해야한다. 계속 받아야하기 때문에 무한 루프!
		
	}

}

package class708.mega.com;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.awt.event.ActionEvent;

public class MessengerB extends JFrame {
	private JTextField input;
	JTextArea list;
	DatagramSocket socket;
	
	public MessengerB( ) throws Exception { //메신저 b를 호출한 곳으로 던짐
		socket = new DatagramSocket(6000);
		setTitle("메신저 B");
		setSize(430, 600);
		
		list = new JTextArea();
		list.setEditable(false);
		list.setBackground(Color.PINK);
		list.setForeground(Color.WHITE);
		list.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		getContentPane().add(list, BorderLayout.CENTER);
		
		input = new JTextField();
		input.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String data = input.getText();
				System.out.println("입력데이터: " + data);
				list.append("나>> " + data + "\n");
				input.setText("");
				
				//보내자
				try {
					DatagramSocket socket = new DatagramSocket(); //선언 또 필요한가?
					byte[] data2 = data.getBytes();
					InetAddress ip = InetAddress.getByName("127.0.0.1"); //자기 자신 ip로 연결됨
					
					DatagramPacket packet = new DatagramPacket(data2, data2.length, ip, 5000);
					socket.send(packet);
					System.out.println("전송 완료");
					socket.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		input.setBackground(new Color(102, 51, 0));
		input.setForeground(Color.WHITE);
		input.setFont(new Font("맑은 고딕", Font.PLAIN, 18));
		getContentPane().add(input, BorderLayout.SOUTH);
		input.setColumns(10);
		setVisible(true);
	}
	
	public void process() {
		while (true) {
			try {
//				socket = new DatagramSocket(5000); //받는 소켓
				byte[] buf = new byte[256];
				DatagramPacket packet = new DatagramPacket(buf, buf.length); 
				socket.receive(packet);
				System.out.println("데이터 받음");
				list.append("너>>" + new String(buf));
			} catch (Exception e) {
				e.printStackTrace();
			} 
			
		}
	}
	
	public static void main(String[] args) throws Exception { //메신저b를 호출한 곳. 다시 또 던져버림
		MessengerB m = new MessengerB();
		m.process(); // 보내기 전에 받을 준비를 먼저 해야한다. 계속 받아야하기 때문에 무한 루프!
		
	}

}

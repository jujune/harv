#import 상속.동물 as ani
from 상속.동물 import *

class Tiger(Dog):
    def hunt(self):
        print("사냥하다")
    def __str__(self):
        return self.color + ", " + self.field

if __name__ == '__main__':
    tiger = Tiger()
    tiger.field = '백두산'
    tiger.color = "갈색"
    print(tiger)
    
    tiger.hunt()
    tiger.tail()
    tiger.bark()

from 자동차.car import *

class Truck(Car):
    driver : ""
    def luggage(self):
        print("짐을 싣다")
    def __str__(self):
        return "truck : " + self.driver + " Car : " + self.product + " " + self.color

if __name__ == '__main__':
    car = Car("black", "genesis")
    truck = Truck("blue", "porter")

    truck.driver = "주엽"

    print(car)
    print(truck)
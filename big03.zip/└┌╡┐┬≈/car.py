class Car:

    product = ""
    color = ""

    def __init__(self, product, color):
        self.product = product
        self.color = color

    def drive(self):
        print("운전하다")
    def park(self):
        print("주차하다")
    def __str__(self):
        return "차종 : " + self.product + " / 컬러 : " + self.color



if __name__ == '__main__':
    car = Car("Black", "Genesis")
    print(car)

    car.drive()
    car.park()



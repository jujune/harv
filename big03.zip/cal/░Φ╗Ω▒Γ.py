# 예금 만기시 만기 지급액은 원금과 이자를 합하여 지급한다.

def add(money, interests):
    print(money + interests)
    return money + interests
# 계산 값을 return 해줘야함

# 이자는 원금에 이자율을 곱하여 계산한다.

def mul(money, rates):
    print(money, rates)
    return money * rates
# 계산 값을 return 해줘야함





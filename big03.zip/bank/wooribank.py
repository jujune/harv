import cal.계산기 as c
# import cal.계산기 에 as로 함수 호출을 할 수 있게 하거나, from cal.계산기 import *로 수정해야함.
from cal.계산기 import  *

이자율 = 0.2
# 이자 아닌 이자율로 수정
money = int(input('예금액을 입력하세요'))
# 입력값을 int로 바꿔줌
이자 = mul(money, 이자율)
# 이자율 아닌 이자로 수정
total_money = add(money, 이자)
print("예금 최종 지불 금액은 %d " %total_money)
from django.contrib import admin

# Register your models here.

from .models import BookMark

# 관리자 모드에서 관리할 테이블을 등록
admin.site.register(BookMark)
from django.db import models

# Create your models here.
class BookMark(models.Model): #ORM 역할의 클래스. 컬럼은 2개야.
    site_name = models.CharField(max_length=100)
    url = models.URLField('site URL')

    def __str__(self):
        return '이름: ' + self.site_name + ', 주소: ' + self.url


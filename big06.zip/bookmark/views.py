from django.http import HttpResponse
from django.shortcuts import render
# Create your views here.

#파이썬에서의 views.py는 Controller의 역할
#app/package마다 view를 만들어준다. (기능별로 만들어줌)

from django.views.generic import ListView
from bookmark.models import BookMark

# view는 요청에 따른 controller 역할을 하는데, 기본적으로는 함수로 정의. 부가적으로는 클래스로 정의.

class BookmarkListView(ListView): #ListView를 상속받음. 어레이리스트처럼 리스트 만들어줌
    model = BookMark #BookMark를 활용할거야~

def index(request):
    return HttpResponse('Welcome Django!!!') # import는 alt + enter

def index2(request2):
    site = '<a href=/admin>관리자모드로!</a><br>' \
           '<a href=/bookmark>북마크로!</a>' \
            '<a href=/bookmark3>북마크3로</a>'
    return HttpResponse(site)

from django.apps import AppConfig


class Bookmark2Config(AppConfig):
    name = 'bookmark2'

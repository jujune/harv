package com.mega.mvc02;
//평범한 자바 차일 : POJO(Plain Old Java Object)

public class MemberDAO {

	public void insert(MemberDTO dto) {
		System.out.println("dao에서 받은 dto내용\n" + dto); // \n 엔터 넣기
	}

}

package com.mega.mvc02;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BbsController {

	@RequestMapping("insert2.do")
	public void insert(BbsDTO bbsDTO) {
		System.out.println("입력된 dto는 " + bbsDTO);
	}
}

package com.mega.mvc02;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@RequestMapping("check.do")
	public void check(String id, String pw, @RequestParam("etc") String etc2) { 
		//@RequestParam("etc") String etc2 -> etc 받아온걸 String etc2라는 새로운 변수로 지정. String etc2는 안써도 됨.
		System.out.println("로그인한 id " + id);
		System.out.println("로그인한 pw " + pw);
		System.out.println("로그인한 etc " + etc2);
		//로그인 처리(DAO)
	}
}

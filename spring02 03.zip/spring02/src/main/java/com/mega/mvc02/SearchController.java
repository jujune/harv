package com.mega.mvc02;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//POJO(포조)파일. 일반적인 java파일을 일케 부름

@Controller //Controller를 상속한다는 의미. @ = Annotation(표시) //컨트롤러 역할을 하게 하려면 넣어주면 됨 controller
public class SearchController {
	
	@RequestMapping("find.mega") //find.mega와 맵핑이 되면 이 메소드를 호출해주렴
	public void find(String search) { //메소드이름(find)는 뭐가 되든 노상관
		System.out.println("find()함수 호출됨");
		System.out.println("검색할 데이터는 " + search);
	}

}

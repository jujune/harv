package com.mega.mvc03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Hello extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("GET요청 들어왔음");
		PrintWriter out = response.getWriter();
		out.println("GET received!!!");
		String id = request.getParameter("id");
		out.print("Your ID : " + id);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("post요청 들어왔음");
		PrintWriter out = response.getWriter();
		out.println("POST received!!!");
		String id = request.getParameter("id");
		out.print("Your ID : " + id);
	}
	
	@Override //서블렛은 파라메터 생성자를 가질 수 없어서 따로 만들어줌
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init() 호출됨");
		String driver = config.getInitParameter("driver");
		if (driver.equals("com.mysql.jdbc.Driver")) {
			System.out.println("mySQL서버에 연결함");
		} else {
			System.out.println("오라클 서버에 연결함");
		
		}
	}
	
	public Hello() {
		System.out.println("기본 생성자 Hello() 호출됨");
		
	}
	

}

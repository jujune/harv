package com.mega.mvc03;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class Me extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("GET요청 들어옴");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("GET Received!!!");
		String age = request.getParameter("age");
		out.println("<br><br>나의 나이는 " + age);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("POST요청 들어옴");
		response.setContentType("text/html; charset=UTF-8"); //한글로 받고 싶을 때 사용
		request.setCharacterEncoding("UTF-8"); //한글로 보내고 싶을 때 사용
		PrintWriter out = response.getWriter();
		out.print("POST Received!!!");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		out.println("<br><br>나의 이름은 " + name);
		out.println("<br><br>나의 주소는 " + address);
	}

}

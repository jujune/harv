#
#

jumsu = [] # 빈 리스트
i = 0 # 인덱스 값 지정
sum = 0 # 점수 총합 변수 값 지정
while i < 3: # 인덱스가 3보다 작을 경우 while문 반복
    data = input('점수 입력>> ') #입력된 점수를 data 변수로
    jumsu.append(int(data)) #입력된 문자변수를 정수로 변환하여, 리스트에 추가
    sum = sum + jumsu[i] #추가된 점수 변수를 더해 점수 총합 구하기
    i = i + 1 #다음 리스트 값을 추가하기 위한 인덱스 값+1
print(sum)
print('합계: ', sum) #합계
print('평균:', sum / i) #평균

print(jumsu)
print(jumsu.count(200)) #리스트 안에 200이 몇 개나 들어있는가

# print(jumsu.sort()) #sort만 수행하는 함수라서 프린트가 불가능

jumsu.sort() #원본을 건드렸나요? 네 -> 파괴적 함수
print(jumsu) #비파괴적 함수
print(jumsu[0])

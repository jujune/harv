# 한 줄 삭제 : ctrl + d

name = ['홍길동', '박길동', '송길동']

print(name[0]) #index가 증가
print(name[1])
print(name[2])
print('--------------------')

index = 0 # start값
while index < 3: # 조건식
    print(name[index])
    index = index + 1 #증감식 # =기호 연산은 가장 마지막에 해줌

print('------------------')
print(name)
print('---------------------')
# 팀원의 나이의 리스트를 만들어서, 반복문으로 찍어보고, 리스트의 전체 목록 확인
# 모든 프로그래밍 언어에서, 숫자를 쓸 때는 따옴표
# 무자인 경우는 따옴표 씀

age = [30, 28, 26]

index1 = 0
while index1 < 3:
or
length = len(age)
while index1 < length
or
while index1 < len(age)
    print(age[index1])
    index1 = index1 + 1

print('---------------')
print(age)
print(len(age)) # 리스트의 개수를 구하는 length 함수 : len(리스트명)
print(age[len(age)-1]) # 리스트 마지막 변수 구하기

import datetime

now = datetime.datetime.now()
month = now.month


if month < 2:
    print('아직은 조금 춥겠군요')
elif month == 2:
    print('조금있으면 봄이 오겠군요')
else:
    print('새해의 시작이 되겠군요')


if 3 <= month <= 5:
    print('봄')
elif 6 <= month <= 8:
    print('여름')
else:
    print('겨울')




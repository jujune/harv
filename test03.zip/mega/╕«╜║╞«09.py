import datetime #모듈명

now = datetime.datetime.now() #현재 시각과 날짜
print('현재는: ', now)
hour = now.hour
print('현재 시간은: ', hour, '시')

if hour <= 11:
    print('굿모닝')
elif hour <= 17:
    print('굿애프터눈')
elif hour <= 22:
    print('굿이브닝')
else :
    print('굿나잇')
print('----------------')
print('올해는 ', now.year , '년')
print('현재 달은 ', now.month , '월')
print('오늘은 ', now.day , '일') #이외에도 now.minute now.second


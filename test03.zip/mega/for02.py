# 3번 반복하고 싶은 경우
for x in range (0, 3):

# 별 10개를 1줄로 찍은 것!
for x in range(0, 10): #range(0, 10, 2혹은3)하면 2혹은 3 씩 점프하면서 x 넣음.
    print(x)
    # print('★', end=" ")

for y in range(0, 10):
    for x in range(0, 10):
        # print(x)
        print('★', end=" ")
    print()
    print() #한 줄 더 띄우고 싶을 떄
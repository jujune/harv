food = ['라면', '커피', '아이스크림', '라떼' , '팥빙수']

#인덱싱
print(food[0])
print(food[-1])
print(food[-2])

#슬라이싱
print(food[0:2]) #0~1 인덱스까지 리스트 가져오기, 뒤에건 원하는 값보다 +1해서 써준다
print(food[2:5])
print(food[2:]) #입력 안하면 끝까지
print(food[:3]) #0~2
print('------------------')

drink = ['물', '아메리카노', '맥주']
all = food + drink
print(all)
print('------------------')


drink3 = drink * 3 #반복의 의미
print(drink3)
print('------------------')

drink.insert(0, '라떼') #넣고 싶은 인덱스에 넣어줌, 파괴형함수!
print(drink)

print(drink.index('라떼')) #위치값을 알려줌

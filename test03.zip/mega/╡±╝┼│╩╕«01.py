dic = {'apple':'사과', 'banana':'바나나', 'melon':'멜론'} #'key:value'
print(dic)

print(dic.get('apple'))


ski = ['박스키', '송스키', '김스키', '정스키']
del(ski[1])
print(ski)


dic = {'엄마':'1', '아빠':'2', '친구':'3', '동생':'4'}
print(dic.get('아빠'))


movies = [] #빈 리스트

#삽입(중간에!), 추가(끝에!)
movies.append(100) #리스트 안에서만 제공하는 함수이기 때문에 .을 사용
print(movies)
movies.append(200)
print(movies)
movies.append(300)
print(movies)
print(len(movies))

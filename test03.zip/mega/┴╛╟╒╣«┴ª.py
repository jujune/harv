# 리스트, 집합, 사전, 튜플 => 모음(collection)

team = {'디자이너', '프로그래머', 'DB관리사'}
print(team)
team.add('디자이너')
print(team)

ski = ['박스키', '송스키', '김스키', '정스키']
del ski[1] #del(ski[1])
print(ski)

phone = {1:'엄마', 2:'아빠', 3:'친구', 4:'동생'} # 숫자여도 스트링이여도 상관 없음
print(phone.get('아빠'))
print(len(phone))
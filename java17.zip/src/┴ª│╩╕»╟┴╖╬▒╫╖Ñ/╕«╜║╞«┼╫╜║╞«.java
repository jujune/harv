package 제너릭프로그램;

import java.util.ArrayList;

public class 리스트테스트 {

	public static void main(String[] args) {
		//제너릭 프로그램
		//ArrayList를 만들때는  제너릭하게 만들어둔다.
		//ArrayList 타입은 객체 생성시 결정!
		//객체 생성시 타입을 정해두면 그에 맞는 타입으로 arraylist의 타입을 정해주는 프로그램을 제너릭 프로그램이라고 함.
		ArrayList<String> list = new ArrayList<>(); //꺽새에 데이터 타입을 설정해주면 형변환 하지 않아두 됨
		list.add("하이");
		list.add("헬로우");
		System.out.println(list); //toString이 적용된 상태.
		
		ArrayList<Integer> list2 = new ArrayList<Integer>(); //Object의 자식만 써야하기 때문에 int 못쓰고 포장형 클래스인 Integer써줌
		list2.add(100);
		list2.add(200);
		System.out.println(list2);
	}

}

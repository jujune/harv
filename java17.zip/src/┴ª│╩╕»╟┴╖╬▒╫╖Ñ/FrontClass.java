package 제너릭프로그램;

import java.util.ArrayList;

public class FrontClass {

	public static void main(String[] args) {
		Our708 our = new Our708(); //클래스 사용을 위한 객체 생성
//		our.call(); //MemberDTO가 들어간 arraylist를 입력값으로 받음
		ArrayList<MemberDTO> list = our.call(); //리턴된 arraylist를 받아줌
		System.out.println(list.size() + "명");
	}

}

package 제너릭프로그램;

// ArrayList<T>
public class Car<T> {
	T size; //타입을 정하지 않고 객체 생성시 정할 수 있게 열어둠
	//T = 데이터 타입, size = 매개변수 
	//ex) Integer 100
	
	public Car(T size) { //CarTest에서 int 100 혹은 String 큰거가 입력됨
		this.size = size; //입력된 100이 곧 이 클래스의 100이다!
	}


	public T getSize() {
		return size; //입력된 100을 리턴하는 메소드
	}
	
}

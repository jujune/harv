package 제너릭프로그램;

import java.util.ArrayList;

public class Our708 {

	public ArrayList<MemberDTO> call() { //반환되는 값이 ArrayList<MemberDTO>이고 call 메소드는 입력값이 필요 없음
		ArrayList<MemberDTO> list = new ArrayList<>();
//		MemberDTO m1 = new MemberDTO(); //이렇게 쓰면 입력값이 없어서 해당 메소드가 없다고 인식해서 에러뜸
		MemberDTO m1 = new MemberDTO("박상도", 27, 0.1, true, '남');
		MemberDTO m2 = new MemberDTO("박현정", 30, 1.0, true, '여');
		MemberDTO m3 = new MemberDTO("이주엽", 30, 0.2, true, '남');
		
		list.add(m1);
		list.add(m2);
		list.add(m3);
		
		System.out.println(list);
		
		for (MemberDTO m : list) {
			System.out.println(m.getName());
		}
		//제너릭이라서 다운캐스팅 안해도 괜찮다 (입력값을 DTO로 받기로 설정)
		
		for (int i = 0; i < list.size(); i++) {
			MemberDTO member = list.get(i);
			System.out.println("당신의 이름은 " + member);
		}
		return list;
	}

}

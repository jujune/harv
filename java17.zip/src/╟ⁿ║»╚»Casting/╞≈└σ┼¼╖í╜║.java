package 형변환Casting;

public class 포장클래스 {

	public static void main(String[] args) {
		//wrapper class
		//무엇을 포장하나? 
		//!기본형!과 관련된 기능을 추가하여 만든 클래스 : 포장클래스
		String data = "100";
		int data2 = Integer.parseInt(data); //인티저가 포장클래스
		System.out.println(data2+1);
	
		String data3 = "11.11";
		double data4 = Double.parseDouble(data3);
		System.out.println(data4+1);
				
		
	}

}

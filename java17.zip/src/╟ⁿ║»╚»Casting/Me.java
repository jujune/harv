package 형변환Casting;

import java.util.ArrayList;

public class Me {

	public static void main(String[] args) {
		//1. 나에 대한 정보 리스트를 만드세요.
		ArrayList list = new ArrayList(); //데이터 타입이 정해지지 않은 ArrayList 생성
		
		list.add("주엽");
		list.add(30);
		list.add(0.3);
		list.add(true);
		list.add('M');
		
		//2. list에 들어있는 나에 대한 전체 내용을 프린트
		System.out.println(list);
		
		for (Object o : list) {
			System.out.print(o + " ");
		}
		float a = 100;
		//3. list에 들어있는 나에 대한 정보를 꺼내서 다음과 같이 출력

		String name = (String) list.get(0);
		int age = (int) list.get(1);
		double eye = (double) list.get(2);
		boolean food = (boolean)list.get(3);
		char gender = (char)list.get(4);
		
		System.out.println("");
		System.out.println("");
		System.out.println("나에 대한 정보");
		System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
		System.out.println("나의 이름은 " + (String)list.get(0) + "입니다.");
		System.out.println("나의 시력이 조금 더 좋아지면" + ((double)list.get(2)+0.2) + "입니다.");
		System.out.printf("내 나이는 %d살 입니다. \n", 10); //십진수 %d, %.소수점자리수f는 실수, %s스트링
		System.out.println("나는 아침을 " + (boolean)list.get(3) + "했습니다");
		System.out.println("나는 " + (char)list.get(4) + "입니다.");
		
		//Math.round Math.floor Math.ceil String.format 각각 반올림 관련 메소드..
		
	}

}

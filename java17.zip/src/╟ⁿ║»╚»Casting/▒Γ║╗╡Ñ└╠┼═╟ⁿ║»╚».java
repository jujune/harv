package 형변환Casting;

public class 기본데이터형변환 {

	//형(유형)->type
	//형변환->casting(캐스팅)
	public static void main(String[] args) {
		//정수: byte(1) -> short(2) -> int(4) -> long(8) ; 괄호 안에는 각각 용량 1바이트, 2바이트..
		//	  ~127~127     +-3만              +-21억
		//실수: float(4) -> double(8) -> 
		//문자
		//논리
		
		byte a = 100; 
		int b = 120; //1200이 안되는 이유는 잘라서 넣고자 하는 타입이 127까지만을 허용하고 있기 때문. (강제형변환을 할 수 없다)
		b = a; // 큰<-작 (자동 형 변환)
		a = (byte)b; // 작<-큰 (강제 형 변환)
		
		int c = 1200;
		double d = 1200;
		d = c;
		
		
	}

}

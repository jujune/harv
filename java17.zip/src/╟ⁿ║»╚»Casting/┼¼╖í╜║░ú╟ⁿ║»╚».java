package 형변환Casting;

import java.util.ArrayList;
import java.util.Iterator;

public class 클래스간형변환 {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("수요일입니다."); //Object <- String, 업캐스팅  
		//Object이 들어갈 자리에 스트링을 넣어줌
		DTO dto = new DTO();
		dto.setId("park");
		dto.setPw("park");
		list.add(dto); //Object <- DTO, 업캐스팅
		
		list.add(100); //int 
		//Object <-(업캐스팅) <- Integer <- (오토박싱) <- int 
		//Object의 자식 클래스는 Integer, Double, Boolean...
		//Object의 자식 클래스는 곧 포장 클래스. int는 기본형데이터라 바로 Object로 들어갈 수 없어서, 
		//포장클래스(Object의 자식클래스)를 통해, 기본형데이터를 클래스화 시켜줘야함!
		
		list.add(true);
		//Object <- boolean <- boolean
		
		System.out.println(list.size());
		for (int i = 0; i < list.size(); i++) {
			list.get(i);
		}
		
		for (Object o : list) {
			System.out.println(o);
		}
		//리스트에 들어있는 타입이 모두 다 Object이다.
		
		//첫번째 index 요소(element)를 꺼내오자.
		String hi = (String)list.get(0); //String<-Object
		//강제형변환, 다운캐스팅
		
		DTO dto2 = (DTO)list.get(1); //DTO <- Object
		//강제형변환, 다운캐스팅
		System.out.println(dto2.getId());
		System.out.println(dto2.getPw());
		
		int i = (int)list.get(2); //int<-Object
		//int <- 오토언박싱 <- Integer <- 다운캐스팅 <- Object
		
		boolean b = (boolean)list.get(3); //boolean <-Object
	}

}

package 형변환Casting;

public class 포장클래스2 {

	public static void main(String[] args) {
		Integer i = new Integer(100); //객체로 만들고 싶을떄 이렇게 쓸 수 있음
		
		int i2 = i; //기본형 <- 포장클래스 //auto un-boxing
		i = i2; //포장클래스 <- 기본형 //auto boxing
		//자기들끼리는 왓다갔다(?)할 수 있다.
		
	}

}

package �׷���;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class ��ȭ�ٹ� {
	private static JTextField t2;
	private static JTextField t1;
	static int start = 5; // ó���� �������� �� ������ �ε���

	public static void main(String[] args) {
		String[] movies = { "1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg", "7.jpg", "8.jpg", "9.jpg", "10.jpg" };
		String[] names = { "1917", "�����", "����� ������", "���� �Ҵ�", "���� �ƾ���", 
				"������ �ĺ�", "���� ����", "��Ǫ���� ��� ���� ���µ�", "Ŭ����", "���� ����" };
		double[] rate = {18.46, 1.98, 1.11, 1.46, 1.11, 20.26, 0.87, 34.13, 3.34, 1.41};

		"+"
		
		JFrame f = new JFrame();
		f.setTitle("\uC601\uD654\uC568\uBC94");
		f.setSize(500, 500);
		JButton img = new JButton("");

		
		JButton btnNewButton = new JButton("<<");
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (start == 0) {
					start = 9;
				} else {
					start--;
				}
				t1.setText(names[start]);
				ImageIcon icon = new ImageIcon(movies[start]);
				img.setIcon(icon);
				t2.setText("������ : " + rate[start]);
			}
		});
		btnNewButton.setBackground(new Color(148, 0, 211));
		f.getContentPane().add(btnNewButton, BorderLayout.WEST);

		JButton btnNewButton_1 = new JButton(">>");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (start == 9) {
					start = 0;
				} else {
					start++;
				}
				t1.setText(names[start]);
				ImageIcon icon = new ImageIcon(movies[start]);
				img.setIcon(icon);
				t2.setText("������ : " + rate[start]);
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(148, 0, 211));
		f.getContentPane().add(btnNewButton_1, BorderLayout.EAST);

		t2 = new JTextField();
		t2.setText("������ : " + rate[start]);
		t2.setBackground(Color.ORANGE);
		f.getContentPane().add(t2, BorderLayout.SOUTH);
		t2.setColumns(10);

		t1 = new JTextField();
		t1.setFont(new Font("���� ����", Font.BOLD, 18));
		t1.setText(names[start]);
		t1.setForeground(Color.WHITE);
		t1.setBackground(Color.ORANGE);
		f.getContentPane().add(t1, BorderLayout.NORTH);
		t1.setColumns(10);

		ImageIcon icon = new ImageIcon(movies[start]);
		img.setIcon(icon);
		img.setForeground(Color.WHITE);
		f.getContentPane().add(img, BorderLayout.CENTER);

		f.setVisible(true);
	}

}

package ���;

public class ifTest1 {

	public static void main(String[] args) {
			//if
			//if else
			// if else if else
			int jumsu = 77;
			if (jumsu >= 90) {
				System.out.println("A");
			} else if (jumsu >= 80) {
				System.out.println("B");
			} else if (jumsu >= 70) {
				System.out.println("c");
			} else
			
		
		
	}

}

package ���;

import java.util.Scanner;

public class whileTest3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("���۰�: "); //2
		int num1 = sc.nextInt();		
		
		System.out.println("���ᰪ: "); //20	
		int num2 = sc.nextInt();

		int start = num1;
		int sum = 0;
		
		while (start <= num2) {
			sum = sum + start;
			start++;
		}
		System.out.println("������ " + sum);
		
	}

}

package ���;


public class TEST5 {

	public static void main(String[] args) {
		String id = "A100"
		char c = id.charAt(0);
		
		
		switch (c) {
		case "A":
			
			break;

		default:
			break;
		}
		
		
					
					
	}

}

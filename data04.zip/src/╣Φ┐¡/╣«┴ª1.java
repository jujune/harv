package �迭;

public class ����1 {

	public static void main(String[] args) {
		//1-1
		char[] weekend = new char[5];
		weekend[0] = 'a';
		weekend[1] = 'b';
		weekend[2] = 'c';
		weekend[3] = 'd';
		weekend[4] = 'e';
		
		//1-2
		for (int i = 0; i < weekend.length; i++) {
			System.out.print(weekend[i] + " ");			
		}
		
		System.out.println();
		System.out.println("-------------------------");
		
		//1-3
		int count = 0;
		for (int i = 0; i < weekend.length; i++) {
			if (weekend[i] == 'a') {
				count = count + 1;
				System.out.println(count);
			}
		}
		
		//2-1
		String[] happy = new String[4];
		happy[0] = "red";
		happy[1] = "orange";
		happy[2] = "yellow";
		happy[3] = "green";
	
		//2-2
		for (int i = 0; i < happy.length; i++) {
			System.out.print(happy[i] + " ");
		}
		System.out.println();
		System.out.println("-------------------------");
		
		
		//3-1
		double[] friday = new double[10];
		for (int i = 0; i < friday.length; i++) {
			friday[i] = 0.1 + i;
		}
	
		
		//3-2
		double total = 0;
		for (int i = 0; i < friday.length; i++) {
			total = total + friday[i];
		}
		System.out.println(total);
		
		//3-3
		System.out.println(total/friday.length);

		
		
		
		
		
	}

}

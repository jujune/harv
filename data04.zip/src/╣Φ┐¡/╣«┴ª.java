package �迭;

public class ���� {

	public static void main(String[] args) {
		int[] friday = new int[20];
		
		System.out.println(friday.length);
		System.out.println("------------------------");
		friday[0] = 100;
		System.out.println(friday[0]);
		System.out.println("------------------------");
		friday[2] = 200;
		System.out.println(friday[2]);
		System.out.println("------------------------");
		friday[19] = 300;
		System.out.println(friday[19]);
		System.out.println("------------------------");
		System.out.println(friday[9]);
		System.out.println("------------------------");
		System.out.println(friday[12]);
		System.out.println("------------------------");
		for (int i = 0; i < friday.length; i++) {
			System.out.println(friday[i]);
		}

		
	}

}

package ������;

import java.awt.Color; // java = �ڹ� ó�� ������ ������ �־��� ��Ű��
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.print.DocFlavor.STRING; //javax = �ڹ� ����Ʈ��, ���߿� �߰��� ��Ű��
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class �׷����׽�Ʈ {
	private static JTextField t1;
	private static JTextField t2;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.ORANGE);
		f.setSize(478, 407);
		f.getContentPane().setLayout(null);

		JButton btnNewButton = new JButton("PUSH");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(null, "��ħ�� �Ծ�����?");
				if (result == 0) {
					JOptionPane.showMessageDialog(null, "�谡 �θ��ðڱ���.");
				} else if (result == 1) {
					JOptionPane.showMessageDialog(null, "�谡 �����ðڱ���.");
				} else {
					JOptionPane.showMessageDialog(null, "�������ñ���.");
				}

			}
		});
		btnNewButton.setBounds(59, 49, 127, 117);
		f.getContentPane().add(btnNewButton);

		JLabel lblNewLabel = new JLabel("\uD64D\uAE38\uB3D9\uC758 \uC708\uB3C4\uC6B0");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 18));
		lblNewLabel.setBounds(200, 24, 169, 64);
		f.getContentPane().add(lblNewLabel);

		JButton btnNewButton_1 = new JButton("\uB098\uB97C \uB20C\uB7EC");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = t1.getText();
				String pw = t2.getText();
				if (id.equals("root") && pw.equals("1234")) {
					JOptionPane.showMessageDialog(null, "�α��� OK");
				} else {
					JOptionPane.showMessageDialog(null, "�α��� NOT");
				}
				t1.setText("");
				t2.setText("");
			}
		});
		btnNewButton_1.setBounds(59, 194, 345, 83);
		f.getContentPane().add(btnNewButton_1);
		
		t1 = new JTextField();
		t1.setBounds(198, 82, 176, 32);
		f.getContentPane().add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setBounds(198, 134, 176, 32);
		f.getContentPane().add(t2);
		t2.setColumns(10);

		f.setVisible(true);
	}
}

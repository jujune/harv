package ������;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ��ȭ���� {
	private static JTextField t1;
	private static JTextField t2;

	static int jprg = 12000;	
	static int jjh = 8000;	
	static int ilgu = 10000;	
	static int small = 7000;	
	
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.DARK_GRAY);
		f.setSize(651, 475);
		f.getContentPane().setLayout(null);

		JLabel img = new JLabel("");
		img.setBackground(new Color(255, 255, 255));
		img.setIcon(new ImageIcon("E:\\jy\\java_project\\data04\\CJ_CGV_logo.jpg"));

		JButton btnNewButton = new JButton(
				"\uC9C0\uD478\uB77C\uAE30\uB77C\uB3C4 \uC7A1\uACE0 \uC2F6\uC740 \uC9D0\uC2B9\uB4E4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("jprg_.jpg");
				img.setIcon(icon);
				t1.setText("30.40%");
				t2.setText(jprg + "��");
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton.setBackground(Color.DARK_GRAY);
		btnNewButton.setBounds(12, 363, 132, 63);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uC815\uC9C1\uD55C \uD6C4\uBCF4");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("jjh_.jpg");
				img.setIcon(icon);
				t1.setText("21.62%");
				t2.setText(jjh + "��");
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton_1.setBackground(Color.DARK_GRAY);
		btnNewButton_1.setBounds(170, 363, 132, 63);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("1917");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("1917_.jpg");
				img.setIcon(icon);
				t1.setText("15.50%");
				t2.setText(ilgu + "��");
			}
		});
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton_2.setBackground(Color.DARK_GRAY);
		btnNewButton_2.setBounds(331, 363, 132, 63);
		f.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("\uC791\uC740 \uC544\uC528\uB4E4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("small_.jpg");
				img.setIcon(icon);
				t1.setText("15.34%");
				t2.setText(small + "��");
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("����", Font.BOLD, 12));
		btnNewButton_3.setBackground(Color.DARK_GRAY);
		btnNewButton_3.setBounds(491, 363, 132, 63);
		f.getContentPane().add(btnNewButton_3);

		img.setBounds(45, 11, 290, 342);
		f.getContentPane().add(img);

		JLabel lblNewLabel = new JLabel("CGV \uC0C1\uC601\uC791");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 27));
		lblNewLabel.setBounds(406, 0, 265, 79);
		f.getContentPane().add(lblNewLabel);

		t1 = new JTextField();
		t1.setColumns(10);
		t1.setBounds(486, 129, 117, 52);
		f.getContentPane().add(t1);

		JLabel lblNewLabel_1 = new JLabel("\uC608\uB9E4\uC728");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 14));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(362, 122, 85, 63);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uAC00\uACA9");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("����", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(362, 222, 85, 63);
		f.getContentPane().add(lblNewLabel_1_1);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(487, 229, 117, 52);
		f.getContentPane().add(t2);

		f.setVisible(true);

	}
}

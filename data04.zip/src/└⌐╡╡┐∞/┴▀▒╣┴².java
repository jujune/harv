package ������;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class �߱��� {
	private static JTextField t1;
	private static JTextField t2;

	static int count = 0;
	static int price_jp = 5000;
	static int price_wd = 6000;
	static int price_jj = 7000;
	static int total = 0;
	
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.RED);
		f.getContentPane().setForeground(Color.WHITE);
		f.setSize(706, 540);
		f.getContentPane().setLayout(null);

		JLabel img = new JLabel("");

		JButton btnNewButton = new JButton("\uC9DC\uC7A5");
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("jj.jpg");
				img.setIcon(icon);
				count++; // ����������
				t1.setText(count + "��"); // '��' ���� count�� ������ string�Լ��� int�� ���� ������ ��
				// string -> int : Integer.parseInt()
				// int -> string : String.valueOf() //t1.setText(String.valueOf(count))
				// int sum = count * price; // ��ü �ݾ� ���
				total = total + price_jj;
				t2.setText(total + "��");
			}
		});
		btnNewButton.setBounds(12, 28, 133, 93);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uC9EC\uBF55");
		btnNewButton_1.setBackground(Color.ORANGE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("jp.jpg");
				img.setIcon(icon);
				count++;
				t1.setText(count + "��");
				total = total + price_jp;
				t2.setText(total + "��");
			}
		});
		btnNewButton_1.setBounds(158, 28, 133, 93);
		f.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\uC6B0\uB3D9");
		btnNewButton_2.setBackground(Color.ORANGE);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon icon = new ImageIcon("wd.jpg");
				img.setIcon(icon);
				count++;
				t1.setText(count + "��");
				total = total + price_wd;
				t2.setText(total + "��");
			}
		});
		btnNewButton_2.setBounds(303, 28, 133, 93);
		f.getContentPane().add(btnNewButton_2);

		t1 = new JTextField();
		t1.setBounds(504, 49, 153, 51);
		f.getContentPane().add(t1);
		t1.setColumns(10);

		t2 = new JTextField();
		t2.setBounds(510, 407, 147, 70);
		f.getContentPane().add(t2);
		t2.setColumns(10);

		JLabel lblNewLabel = new JLabel("\uAC1C\uC218");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 16));
		lblNewLabel.setBounds(457, 47, 90, 51);
		f.getContentPane().add(lblNewLabel);

		img.setIcon(new ImageIcon("E:\\jy\\java_project\\data04\\chinese restaurant.jpg"));
		img.setBounds(22, 133, 450, 286);
		f.getContentPane().add(img);

		JLabel lblNewLabel_2 = new JLabel("\uC9C0\uBD88\uD560 \uCD1D \uAE08\uC561");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("���� ����", Font.BOLD, 24));
		lblNewLabel_2.setBounds(510, 357, 335, 40);
		f.getContentPane().add(lblNewLabel_2);

		f.setVisible(true);
	}

}

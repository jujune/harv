print(0 in range(0, 5)) # 읽기 전용 목록인 튜플임을 증명
for x in range(0, 5):
    pass

# 20-1

location = []

for x in range(0,5): #0,1,2,3,4
    location.append(input('장소: '))

print(location)

# 20-2

if '강남' in location:
    print('강남있음.')
    #인덱스가 필요!
    index = location.index('강남')
    #인덱스를 가지고 del
    del location[index]

print(location)

#or

for x in range(0, len(location)):
    if(location[x] == '강남')
        del location[x] #파괴함수
        print('강남을 삭제했습니다')
        break


# 20-3


import math

name = '홍길동'
age = 100.222
print(int(age))
print(math.floor(age)) #floor 버림
print(round(age, 1)) #round 반올림
print('나의 이름은 %s이다' %(name)) #%s는 스트링. 이 자리에 들어올거야
print('나의 이름은 %s이고 나이는 %d' %(name,age)) # %d는 십진수
print('나의 이름은 {0}이고 나이는 {1:0.1f}'.format(name, age))
#{0}는 index부여, 0.1f는 소수 첫째자리까지. # 0번, 1번 , f는 실수 float. #괄호 숫자로 입력 순서 지정
import random

jumsu = []

random.seed(20) #난수 값 안바뀌게 고정?
for x in range (0,10):
    jumsu.append(random.randint(1, 10))

print(jumsu)

count = jumsu.count(516) # 리스트 안에 516이 몇 개나 들어있는가
print(count)


count2 = 0
for x in jumsu:
    if x == 5:
        count2 = count2 + 1
print(count2)


for x in range(0, len(jumsu)):
    if jumsu[x] == 5: # 455가 들어가는 위치, 인덱스값
        print('위치는: ', x)
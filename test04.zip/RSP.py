# 가위바위보 게임

import random

while True:
    me = input("무엇을 내시겠습니까? (종료는 x) ")
    com = random.choice(['가위', '바위', '보'])

    print('컴퓨터 왈:', com)
    if me == com:
        print('비겼습니다')
    elif (me == '가위' and com == '보') or (me == "바위" and com == '가위') or (me == '보' and com =='바위'):
        print('이겼습니다!!!')
    elif me == 'x' or me == 'X': # me in ['x','X']
        print('게임을 종료합니다')
        break
    else:
        print('졌습니다ㅠㅠ')

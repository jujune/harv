import random
target = random.randint(1, 100) #1~100 중 하나를 생성

count = 0 #초기화 변수는 반복문 안에 넣으면 안된다
while True:
    count = count + 1
    data = int(input('정답을 입력하시오: '))
    if data == target:
        print('정답입니다.')
        print('당신의 시도 횟수: ', count, '회')
        break
    else:
        print('정답이 아닙니다')
        if data < target:
            print('너무 작아요')
        if data > target:
            print('너무 커용')




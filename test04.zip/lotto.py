
import random
roddo = []
count = 0


while True:
    value = int(random.randint(1, 45))
    print("값:",value)
    if value in roddo:
        print('중복.')
        continue
    roddo.append(value)
    print(len(roddo))
    if 6 <= len(roddo) : break


print(roddo)
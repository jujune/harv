package 클래스만들기;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class 멜론 {
	public static void main(String[] args) {
		try {
			Connection con = Jsoup.connect("https://www.genie.co.kr/chart/musicHistory?year=2016&category=0&pg=1");
			Document doc = con.get();
			
			Elements list = doc.select(".albumtitle.ellipsis"); 
			
			System.out.println(list.size());
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).text());
			}
//			System.out.println(list.size());   
		
//			System.out.println("-----------------------");
//			for (int i = 0; i < list.size(); i++) {
//				System.out.println(list.get(i).text());
//			}
//			System.out.println("-----------------------");
	
			
		
			
		} catch (Exception e) {
		}
}
}



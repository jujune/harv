package 스레드;

import javax.swing.JOptionPane;

//ctrl + f11 : compile (javac Error2.java) --> Error2.class --> run(java Error2)

//컴파일이 되고 클래스가 생기고, 실행 결과가 보여짐
public class ErrorTest2 {

	public static void main(String[] args) {
		int[] num = {1, 2, 3};
		
		//에러가 발생한 경우에, 이 에러가 발생한 메소드 내에서 에러가 발생했을때 , 바로 처리할 내용을 넣어서 처리. 이럴 때 try-catch 
		

		try { // try-catch는 에러가 생길만한 부분에 설정해둠. 에러가 생겨도 그 다음 단계로 넘어가게함. 
			// ex)웹페이지 같은 경우 일부가 구동 안되도 나머지가 구동되게함
			num[3] = 4;  //실행시에 생기는 에러. runtime error
		} catch (ArrayIndexOutOfBoundsException e) { //수 많은 Exception중 더 상세한 Array~부터 먼저 catch하겠다!
			e.printStackTrace(); //에러 정보가 무엇인지 프린트
		} catch (Exception e) { //에러 정보를 담고 있는 객체
			JOptionPane.showMessageDialog(null, "에러 발생, 확인요청!");
			e.printStackTrace(); //에러 정보가 무엇인지 프린트
		} finally {
			System.out.println("에러가 발생하지 않아도 꼭 실행시키고 싶은 부분");
			//파일 close 시키는 부분
			//db관련된 객체 close부분
		}
		
		System.out.println(num[0]); 
	}

}

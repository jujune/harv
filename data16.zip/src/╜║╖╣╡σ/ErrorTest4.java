package 스레드;

public class ErrorTest4 {

	public void call() throws Exception { //에러가 나면 
		//Error! --> Exception!
		int x = 100;
		
		int y = x / 0;
		
		System.out.println(x);
	}

}

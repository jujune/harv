package 스레드;

public class MainClass {

	public static void main(String[] args) {
		forTest1 f1 = new forTest1();
		forTest2 f2 = new forTest2();
		
		f1.start(); //cpu에 thread를 등록
		f2.start(); 
		
		
	}

}

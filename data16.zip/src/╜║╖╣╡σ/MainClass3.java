package 스레드;

import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MainClass3 extends JFrame{
	JLabel counter, img, time;
	
	public MainClass3() {
		getContentPane().setBackground(Color.GREEN);
		setTitle("스레드");
		setSize(754,467);
		getContentPane().setLayout(null);
		
		counter = new JLabel("count");
		counter.setForeground(Color.RED);
		counter.setFont(new Font("굴림", Font.PLAIN, 47));
		counter.setBounds(12, 23, 225, 58);
		getContentPane().add(counter);
		
		img = new JLabel("그림");
		img.setFont(new Font("굴림", Font.PLAIN, 15));
		img.setBounds(271, 147, 130, 134);
		getContentPane().add(img);
		
		time = new JLabel("시간");
		time.setForeground(Color.BLUE);
		time.setFont(new Font("굴림", Font.PLAIN, 25));
		time.setBounds(25, 281, 376, 58);
		getContentPane().add(time);
		
		Count c = new Count();
		Time t = new Time();
		Image i = new Image();
		c.start();
		t.start();
		i.start();
		
		setVisible(true);
	}
	
	//내부 클래스(inner class)
	//독립적으로 객체생성 불가
	//외부 클래스에 있는 멤버변수를 공유할 목적으로 사용
	public class Count extends Thread {
		@Override
		public void run() {
			for (int i = 10; i >= 0; i--) {
				//외부자원 연결 (cpu를 연결하는, 외부자원을 연결하는 작업에는 try catch를 사용)(sql문 연결하던지 할때도)
				try {
					Thread.sleep(1000); //1초 //sleep은 void형 static메소드, 입력값은 int인 셈
				} catch (Exception e) {
				}
				counter.setText("count: " + i); //1초 슬립한 이후에 카운트가 되게 하는 구조
				if (i == 0) System.exit(0); //0은 종료하라는 문법
			}
		}
	}
	
	public class Time extends Thread {
		@Override
		public void run() {
			for (int i = 0; i < 100; i++) {
				//외부자원 연결 (cpu를 연결하는, 외부자원을 연결하는 작업에는 try catch를 사용)
				try {
					Thread.sleep(1000); //1초
				} catch (Exception e) {
				}
//				Date date = new Date(); //나온지가 20년이 된 오래된 함수 //
				Calendar cal = Calendar.getInstance(); //new로 안하는건 객체생성을 1번만 하겠다는 뜻
				time.setText(cal.getTime() + "");
			}
		}
	}
	
	
	public class Image extends Thread {
		@Override
		public void run() {
			String[] list = {"r1.png", "r2.png", "r3.png", "r4.png", "r5.png", "r6.png", "r7.png", "r8.png"};
			for (int i = 0; i < 100; i++) {
				try {
					Thread.sleep(1000); //1초
				} catch (Exception e) {
				}
				ImageIcon icon = new ImageIcon(list[i]); // or list[i%8]
				img.setIcon(icon);
				if (i == 7) {
					 i = -1;
				}
			}
		}
	}

	
	public static void main(String[] args) { //우리의 코드는 스태틱을 최소화 해야한다.
		new MainClass3();
		
	}
}

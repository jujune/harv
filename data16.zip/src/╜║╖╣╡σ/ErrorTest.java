package 스레드;

public class ErrorTest {

	public static void main(String[] args) {
		System.out.println("test");
		int x;
		
		System.out.println(x); //문법 오류 //syntax(문법) error
		//컴파일 단계 (번역 단계) ------> 실행 단계
		//The local variable x may not have been initialized ; 로컬변수 x가 초기화가 안됨!
	}

}

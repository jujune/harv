package 스레드;

public class MainClass4 {

	public static void main(String[] args) throws Exception {
		ErrorTest4 e4 = new ErrorTest4();
		e4.call(); //호출
		
	}

}

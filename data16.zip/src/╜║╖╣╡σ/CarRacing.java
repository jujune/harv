package 스레드;

import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class CarRacing extends JFrame { //JFrame을 상속받음
	
	public CarRacing() { //CarRacing의 생성자 (constructor). main에서 CarRacing을 호출했을때 자동으로 실행됨.
		setTitle("자동차 경주");
		setSize(1000, 500);
		setLayout(null); //null 안하면 다 가운데 겹쳐버리거나? 규칙 이상해져
		
		Car car1 = new Car("car01.png", 100, 0); 
		Car car2 = new Car("car02.png", 100, 150);
		Car car3 = new Car("car03.png", 100, 300);
		
		car1.start(); //스레드(run)를 시작시키는 메소드 .start
		car2.start();  
		car3.start();
		
		setVisible(true);
	}
	public class Car extends Thread { //내부 클래스
		int x, y;
		JLabel label; //전역, 글로벌 변수로 빼줌. public 밖에서도 사용하기 위해.
		
		public Car (String file, int x, int y) { //Car의 생성자. Car가 호출되면서 자동으로 실행.
			ImageIcon icon = new ImageIcon(file);
			label = new JLabel(icon); //전역변수로 이미 선언되어서 다시 선언하지 않음. 여기서 JLabel label로 선언하면 아예 새로운 객체로 인식.
			this.x = x; //입력받은 x가 이 클래스의 x라는 의미
			this.y = y;
			label.setBounds(x, y, 150, 150); //라벨의 위치 지정 x y 그리고 이미지 크기 값
			add(label);
		}
		
		@Override //오버라이딩 : 상속받은 것 중에 기능을 재정의
		public void run() { //.start 메소드를 호출함으로써 자동으로 실행. //스레드 기능을 사용할 수 있는 객체명 run
			Random r = new Random(); //자동차 이동 거리를 랜덤하게 증가시켜줄 함수
			for (int i = 0; i < 200; i++) { 
				int move = r.nextInt(50); //0~49
				x = x + move; //i가 1 증가할 때마다,이미지가 x + move랜덤값 만큼 이동
				label.setBounds(x, y, 150, 150); //입력된 이미지의 출발 지점.
				try {
					Thread.sleep(500); //0.5초간 cpu를 멈춤
				} catch (Exception e) {
				}
			}
		}
	}	
	
	public static void main(String[] args) {
		new CarRacing(); // CarRacing 클래스를 호출 -> CarRacing 생성자  자동 실행
		
	}

}

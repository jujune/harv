package 스레드;

public class StarTelUse {

	public static void main(String[] args) {
		Star s = new Star();
		Tel t = new Tel();
		
		s.start();
		t.start();
		
	}

}

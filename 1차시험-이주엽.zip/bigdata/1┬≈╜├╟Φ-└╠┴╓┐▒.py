from tkinter import * # Tk모듈을 사용하기 위한 라이브러리 가져오기

name = []
deposit = []

def inputt(): # 새로운 함수 기능 정의
    for _ in range(0, 5):
        a = input('이름을 입력하세요.>> ')
        b = input('예금액을 입력하세요.>> ')
        name.append(a)
        deposit.append(b)

def outputt():
    print(name)
    print(deposit)

def revisee():
    c = input('입금액을 수정할 이름을 입력해주세요.>> ')
    for x in range(0,len(name)): # 입력 받은 변수를 리스트의 인덱스로 검색
        if c == name[x]:
            d = deposit[x] = input('새로운 입금액을 입력해주세요.>> ') # 인덱스와 일치하는 변수를, 새로 입력 받은 변수로 변경
    print(name)
    print(deposit)
    print(c + '의 수정된 입금액은 ' + d + '원 입니다')

def arrangee():
    x = 0
    sum = 0
    while True: # 반복문과 if문을 활용한 변수의 총합 구하기
        if x < len(deposit):
            sum = sum + int(deposit[x])
            x = x + 1
        else:
            average = sum / len(deposit) # 평균 구하기
            print('입금액의 합계는 %d원 이고, 평균은 %d원 입니다.' % (sum, average))
            break

def exitt():
    print('프로그램을 종료합니다')
    w.destroy()


w = Tk() # 창 띄우기, 창 크기, 배경색 설정
w.geometry('300x500')
w.configure(bg='skyblue')

# 버튼 설정과 함수 연결, 나타나게 하기(pack)
func1 = Button(w, text='입력', bg='white', fg='black', font=('맑은 고딕', 30), command = inputt)
func1.pack()
func2 = Button(w, text='출력', bg='white', fg='black', font=('맑은 고딕', 30), command = outputt)
func2.pack()
func3 = Button(w, text='수정', bg='white', fg='black', font=('맑은 고딕', 30), command = revisee)
func3.pack()
func4 = Button(w, text='정리', bg='white', fg='black', font=('맑은 고딕', 30), command = arrangee)
func4.pack()
func5 = Button(w, text='종료', bg='white', fg='black', font=('맑은 고딕', 30), command = exitt)
func5.pack()


w.mainloop() # 창이 띄워지도록 하는 함수

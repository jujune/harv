package com.mega.mvc08;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component //싱글톤으로 만들어줌. context에서 bean설정하는 것과 같음 
public class MemberDAO {

	@Autowired
	SqlSessionTemplate my;
	
	public int login(MemberDTO dto) {
		String id = "root";
		String pw = "1234";
		int result = 0;
		
		if (id.equals(dto.getId()) && pw.equals(dto.getPw())) {
			result = 1;
		} 
		
		return result;
	}
	
	public void insert(MemberDTO dto) {
		my.insert("member.insert", dto);
		
	}

	public void delete(MemberDTO dto) {
		my.delete("member.delete", dto);
	}
	
	public void update(MemberDTO dto) {
		my.delete("member.update", dto);
	}
	
	
	
}

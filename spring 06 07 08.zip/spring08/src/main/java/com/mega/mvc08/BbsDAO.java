package com.mega.mvc08;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component //싱글톤으로 만들어줌. context에서 bean설정하는 것과 같음 
public class BbsDAO {

	@Autowired
	SqlSessionTemplate my;
	
	public void insert(BbsDTO dto) {
		my.insert("bbs.insert", dto);
		
	}

	public void delete(BbsDTO dto) {
		my.delete("bbs.delete", dto);
	}
	
	public void update(BbsDTO dto) {
		my.delete("bbs.update", dto);
	}
	
	
	
}

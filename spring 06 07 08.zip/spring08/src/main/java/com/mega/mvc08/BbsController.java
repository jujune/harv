package com.mega.mvc08;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BbsController {

	@Autowired
	BbsDAO dao;
	
	@RequestMapping("insert2.do")
	public void insert(BbsDTO dto) {
		dao.insert(dto);
	}
	
	@RequestMapping("delete2.do")
	public void delete(BbsDTO dto) {
		dao.delete(dto);
	}
	
	@RequestMapping("update2.do")
	public void update(BbsDTO dto) {
		dao.update(dto);
	}
}

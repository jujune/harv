package 프로젝트;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Mypage {
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;
	private static JTextField textField_3;
	private static JTextField textField_4;

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(1000,800);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("내가 구입한 노래");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 10, 445, 79);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("회원정보");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(527, 10, 445, 79);
		f.getContentPane().add(lblNewLabel_1_1);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 99, 443, 623);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1_2 = new JLabel("커버");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setBounds(12, 10, 43, 42);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_2 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2.setBounds(67, 10, 210, 42);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("커버");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setBounds(12, 62, 43, 42);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_2_1 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2_1.setBounds(67, 62, 210, 42);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel = new JLabel("아이디");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(467, 99, 127, 56);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("이름");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(467, 165, 127, 56);
		f.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("번호");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(467, 231, 127, 56);
		f.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("이메일");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(467, 297, 127, 56);
		f.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("닉네임");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(467, 363, 127, 56);
		f.getContentPane().add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(640, 100, 263, 56);
		f.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(640, 165, 263, 56);
		f.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(640, 231, 263, 56);
		f.getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(640, 297, 263, 56);
		f.getContentPane().add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(640, 363, 263, 56);
		f.getContentPane().add(textField_4);
		
		JButton btnNewButton = new JButton("회원정보 수정");
		btnNewButton.setBounds(527, 477, 350, 72);
		f.getContentPane().add(btnNewButton);
		
		
		
		
		f.setVisible(true);
		
	}

}

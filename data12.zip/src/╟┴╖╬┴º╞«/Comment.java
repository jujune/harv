package 프로젝트;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Comment {
	private static JTextField textField;
	private static JLabel hate1;

	static int like_count = 0;
	static int hate_count = 0;
	
	public static void main(String[] args) {
		
		JFrame f = new JFrame();
		f.setSize(1000,800);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("총 댓글 000개");
		lblNewLabel_1.setBounds(40, 80, 165, 38);
		f.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("최신순");
		btnNewButton.setBounds(673, 99, 117, 38);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("추천순");
		btnNewButton_1.setBounds(801, 99, 117, 38);
		f.getContentPane().add(btnNewButton_1);
		
		textField = new JTextField();
		
		textField.setBounds(329, 415, 461, 160);
		f.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("닉네임");
		lblNewLabel_1_1.setBounds(40, 159, 165, 38);
		f.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("날짜");
		lblNewLabel_1_1_1.setBounds(234, 329, 82, 38);
		f.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel like1 = new JLabel();
		like1.setHorizontalAlignment(SwingConstants.CENTER);
		like1.setBounds(720, 339, 29, 38);
		f.getContentPane().add(like1);
		
		JButton like = new JButton("좋아요");
		like.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				like_count++;
				like1.setText(String.valueOf(like_count));
			}
		});
		like.setBounds(599, 339, 117, 38);
		f.getContentPane().add(like);
		
		JLabel hate1;
		hate1 = new JLabel();
		hate1.setHorizontalAlignment(SwingConstants.CENTER);
		hate1.setBounds(890, 339, 29, 38);
		f.getContentPane().add(hate1);
		
		JButton hate = new JButton("싫어요");
		hate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hate_count++;
				hate1.setText(String.valueOf(hate_count));
			}
		});
		hate.setBounds(769, 339, 117, 38);
		f.getContentPane().add(hate);
		
		
		JLabel lblNewLabel_3 = new JLabel("댓글 내용");
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setBackground(Color.WHITE);
		lblNewLabel_3.setBounds(233, 159, 685, 147);
		f.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("본인 닉네임");
		lblNewLabel_1_1_2.setBounds(40, 415, 165, 38);
		f.getContentPane().add(lblNewLabel_1_1_2);
		
		JButton btnNewButton_4 = new JButton("댓글 등록");
		btnNewButton_4.setBounds(801, 415, 117, 160);
		f.getContentPane().add(btnNewButton_4);
		
		
		f.setVisible(true);
		
		
		
	}
}

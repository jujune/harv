package 프로젝트;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;

public class Buying3 {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(1000,800);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("구매 곡 정보");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(12, 32, 406, 57);
		f.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(34, 88, 387, 555);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("커버");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 10, 43, 42);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("커버");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(12, 63, 43, 42);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2.setBounds(67, 10, 210, 42);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("아티스트 - 곡 명");
		lblNewLabel_2_1.setBounds(67, 63, 210, 42);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3 = new JLabel("총 10곡 X 800원 = 합계 8,000원");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(34, 668, 384, 57);
		f.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("결제방식");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(465, 32, 142, 86);
		f.getContentPane().add(lblNewLabel_4);
		

		
		JButton btnNewButton = new JButton("카드");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				JPanel panel_1 = new JPanel();
//				panel_1.setBackground(Color.GREEN);
//				panel_1.setBounds(478, 160, 462, 379);
//				panel_1.setLayout(null);
//
//				f.getContentPane().add(panel_1);
//				
				Payment c = new Payment();
				c.card();
//				
////				JPanel panel_1 = new JPanel();
////				panel_1.setBackground(Color.WHITE);
////				panel_1.setBounds(478, 160, 462, 379);
////				panel_1.setLayout(null);
//				
//				JLabel lblNewLabel_7 = new JLabel("카드사 선택");
//				lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
//				lblNewLabel_7.setBounds(12, 10, 102, 29);
//				panel_1.add(lblNewLabel_7);
//				
//				JLabel lblNewLabel_7_1 = new JLabel("카드번호 입력");
//				lblNewLabel_7_1.setHorizontalAlignment(SwingConstants.CENTER);
//				lblNewLabel_7_1.setBounds(12, 49, 102, 23);
//				panel_1.add(lblNewLabel_7_1);
//				
//				JLabel lblNewLabel_7_2 = new JLabel("유효기간");
//				lblNewLabel_7_2.setHorizontalAlignment(SwingConstants.CENTER);
//				lblNewLabel_7_2.setBounds(12, 88, 102, 29);
//				panel_1.add(lblNewLabel_7_2);
//				
//				JLabel lblNewLabel_7_3 = new JLabel("CVC");
//				lblNewLabel_7_3.setHorizontalAlignment(SwingConstants.CENTER);
//				lblNewLabel_7_3.setBounds(271, 88, 102, 29);
//				panel_1.add(lblNewLabel_7_3);
//				
//				JLabel lblNewLabel_7_4 = new JLabel("비밀번호");
//				lblNewLabel_7_4.setHorizontalAlignment(SwingConstants.CENTER);
//				lblNewLabel_7_4.setBounds(12, 127, 102, 29);
//				panel_1.add(lblNewLabel_7_4);
//			
//				JTextField textField = new JTextField();
//				textField.setBounds(137, 49, 65, 23);
//				panel_1.add(textField);
//				textField.setColumns(10);
//				
//				JTextField textField_1 = new JTextField();
//				textField_1.setColumns(10);
//				textField_1.setBounds(214, 49, 65, 23);
//				panel_1.add(textField_1);
//				
//				JTextField textField_2 = new JTextField();
//				textField_2.setColumns(10);
//				textField_2.setBounds(291, 49, 65, 23);
//				panel_1.add(textField_2);
//				
//				JTextField textField_3 = new JTextField();
//				textField_3.setColumns(10);
//				textField_3.setBounds(368, 49, 65, 23);
//				panel_1.add(textField_3);
//				
//				JTextField textField_4 = new JTextField();
//				textField_4.setColumns(10);
//				textField_4.setBounds(137, 92, 65, 21);
//				panel_1.add(textField_4);
//				
//				JTextField textField_5 = new JTextField();
//				textField_5.setColumns(10);
//				textField_5.setBounds(368, 92, 65, 21);
//				panel_1.add(textField_5);
//				
//				JPasswordField pw = new JPasswordField();
//				
//				JTextField textField_6 = new JTextField();
//				textField_6.setColumns(10);
//				textField_6.setBounds(137, 131, 33, 21);
//				panel_1.add(textField_6);
//				
//				String card[] = {"현대카드", "신한카드", "BC카드", "KB국민카드", "삼성카드", "우리카드", "카카오뱅크", "NH채움카드", "롯데카드", "하나카드"};
//				JComboBox comboBox = new JComboBox(card);
//				comboBox.setBounds(137, 14, 142, 23);
//				panel_1.add(comboBox);
//				
//				JLabel lblNewLabel_8 = new JLabel("**");
//				lblNewLabel_8.setBounds(175, 131, 27, 25);
//				panel_1.add(lblNewLabel_8);
//				
////				f.getContentPane().add(panel_1);
//				panel_1.revalidate();
//				panel_1.repaint();
			}
		});
		btnNewButton.setBounds(630, 32, 142, 86);
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("무통장 입금");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Payment c = new Payment();
				c.card();
			}
		});
		btnNewButton_1.setBounds(798, 32, 142, 86);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("결제 시도");
		btnNewButton_2.setBounds(478, 575, 462, 68);
		f.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel_6 = new JLabel("결제 결과");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(478, 668, 430, 57);
		f.getContentPane().add(lblNewLabel_6);
		
		
		
		f.setVisible(true);
		
	}
}
